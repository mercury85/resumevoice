'use client';
import Link from 'next/link';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';

export default function NotFound() {
  return (
    <>
      <Nav />
      <main style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 'calc(100vh - 64px)', background: 'var(--bg)', padding: '40px 24px', textAlign: 'center' }}>
        <div style={{ maxWidth: 560, animation: 'fadeUp .5s ease both' }}>
          {/* 404 big number */}
          <div style={{ fontSize: 'clamp(80px,15vw,140px)', fontWeight: 900, letterSpacing: '-6px', lineHeight: 1, background: 'linear-gradient(135deg,#7c3aed,#a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', marginBottom: 8 }}>
            404
          </div>

          {/* Icon */}
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'var(--purple-light)', border: '2px solid var(--purple-mid)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 28px', fontSize: 36 }}>
            🔍
          </div>

          <h1 style={{ fontSize: 'clamp(22px,4vw,32px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: 12, color: 'var(--text)' }}>
            Страница не найдена
          </h1>
          <p style={{ fontSize: 16, color: 'var(--text3)', lineHeight: 1.65, marginBottom: 36, maxWidth: 400, margin: '0 auto 36px' }}>
            Такой страницы не существует. Возможно адрес введён неверно или страница была удалена.
          </p>

          {/* Suggestions */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, maxWidth: 400, margin: '0 auto 32px' }}>
            {[
              ['mic','Создать резюме','/voice'],
              ['search','Найти вакансии','/vacancies'],
              ['📈','Улучшить резюме','/upgrade'],
              ['💼','Личный кабинет','/dashboard'],
            ].map(([icon, label, href]) => (
              <Link key={href} href={href} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', borderRadius: 14, border: '1.5px solid var(--border)', background: 'var(--bg)', textDecoration: 'none', color: 'var(--text2)', fontSize: 14, fontWeight: 500, transition: 'all .15s' }}>
                <span style={{ fontSize: 20 }}>{icon}</span>
                {label}
              </Link>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '13px 28px', borderRadius: 10, fontSize: 15, fontWeight: 700, background: '#7c3aed', color: '#fff', textDecoration: 'none', boxShadow: '0 6px 24px rgba(124,58,237,.35)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
              На главную
            </Link>
            <button onClick={() => history.back()} style={{ display: 'inline-flex', alignItems: 'center', padding: '13px 24px', borderRadius: 10, fontSize: 15, fontWeight: 500, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text2)', cursor: 'pointer', fontFamily: 'inherit' }}>
              Назад
            </button>
          </div>
        </div>
      </main>
      <Footer />
      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}`}</style>
    </>
  );
}
