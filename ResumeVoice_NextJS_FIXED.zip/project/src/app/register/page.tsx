'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

type Step = 1|2|3;
type Method = 'phone'|'email';

export default function RegisterPage() {
  const [step, setStep] = useState<Step>(1);
  const [method, setMethod] = useState<Method>('phone');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [pass, setPass] = useState('');
  const [code, setCode] = useState(['','','','','','']);
  const [pwdStr, setPwdStr] = useState(0);
  const router = useRouter();

  const calcPwd = (v:string) => {let s=0;if(v.length>=8)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;setPwdStr(s);};
  const pwdColors=['#ef4444','#f59e0b','#22c55e','#16a34a'];

  const goStep2=()=>{if(method==='phone'&&phone.length<10){alert('Введите номер телефона');return;}if(method==='email'&&!email.includes('@')){alert('Введите email');return;}setStep(2);};
  const verifyCode=()=>{const c=code.join('');if(c.length<6){alert('Введите 6-значный код');return;}setStep(3);};
  const finish=(goal:string)=>{localStorage.setItem('rvUser',JSON.stringify({id:'new',name:name||'Пользователь',email,phone,plan:'free'}));router.push(goal);};

  const codeChange=(i:number,v:string)=>{if(!/^\d?$/.test(v))return;const n=[...code];n[i]=v;setCode(n);if(v&&i<5)(document.getElementById(`rc${i+1}`)as HTMLInputElement)?.focus();if(n.every(c=>c)&&n.join('').length===6)setTimeout(verifyCode,300);};

  const inp:React.CSSProperties={width:'100%',padding:'11px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:15,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit',transition:'border-color .15s'};
  const btnP:React.CSSProperties={width:'100%',padding:13,borderRadius:10,fontSize:15,fontWeight:600,border:'none',background:'#7c3aed',color:'white',cursor:'pointer',fontFamily:'inherit'};
  const tabS=(on:boolean):React.CSSProperties=>({flex:1,padding:'9px',textAlign:'center',fontSize:13,fontWeight:on?700:500,color:on?'var(--text)':'var(--text3)',borderRadius:8,cursor:'pointer',transition:'all .2s',background:on?'white':'transparent',boxShadow:on?'0 1px 4px rgba(0,0,0,.08)':'none'});

  return (
    <div style={{minHeight:'100vh',background:'var(--bg2)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'40px 20px'}}>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:24,padding:40,width:'100%',maxWidth:480,boxShadow:'0 4px 24px rgba(0,0,0,.06)'}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
          <Link href="/" style={{display:'flex',alignItems:'center',gap:10,textDecoration:'none'}}>
            <img src="/logo.png" alt="RV" style={{height:36,objectFit:'contain'}}/>
            <span style={{fontSize:19,fontWeight:800,color:'var(--text)'}}>Resume<span style={{color:'#7c3aed'}}>Voice</span></span>
          </Link>
          <Link href="/" title="Назад на сайт" style={{width:32,height:32,borderRadius:8,border:'1.5px solid var(--border)',background:'var(--bg2)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--text3)',textDecoration:'none',flexShrink:0}}>
            <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </Link>
        </div>
        <p style={{fontSize:11,color:'var(--text4)',marginBottom:28}}>Создание резюме голосом и поиск работы в одном сервисе</p>
        <div style={{fontSize:22,fontWeight:800,letterSpacing:'-.5px',marginBottom:4,color:'var(--text)'}}>Начать бесплатно</div>
        <div style={{fontSize:14,color:'var(--text3)',marginBottom:16}}>Первое резюме — сразу. Без карты.</div>

        {/* Perks */}
        <div style={{background:'var(--purple-light)',border:'1.5px solid var(--purple-mid)',borderRadius:12,padding:'14px 16px',marginBottom:24}}>
          <ul style={{listStyle:'none',display:'flex',flexDirection:'column',gap:6}}>
            {['1 резюме голосом — бесплатно','1 сопроводительное письмо','Скачать PDF','Без доступа к вакансиям (доступно с тарифа Про)'].map(i=>(
              <li key={i} style={{display:'flex',alignItems:'flex-start',gap:8,fontSize:13,color:'var(--text2)'}}>
                <span style={{color:'#7c3aed',fontWeight:800,flexShrink:0}}>✓</span>{i}
              </li>
            ))}
          </ul>
        </div>

        {/* Steps indicator */}
        <div style={{display:'flex',gap:6,marginBottom:24,justifyContent:'center'}}>
          {[1,2,3].map(s=>(
            <div key={s} style={{width:28,height:4,borderRadius:2,background:step>s?'#c4b5fd':step===s?'#7c3aed':'var(--border)',transition:'background .2s'}}/>
          ))}
        </div>

        {/* STEP 1 */}
        {step===1 && (
          <div>
            <div style={{display:'flex',background:'var(--bg3)',borderRadius:10,padding:3,marginBottom:20,gap:0}}>
              <div style={tabS(method==='phone')} onClick={()=>setMethod('phone')}>По телефону</div>
              <div style={tabS(method==='email')} onClick={()=>setMethod('email')}>По email</div>
            </div>
            {method==='phone'?(
              <div>
                <label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Ваш телефон</label>
                <div style={{display:'flex',gap:0,marginBottom:14}}>
                  <div style={{...inp,width:'auto',padding:'11px 14px',borderRight:'none',borderRadius:'8px 0 0 8px',background:'var(--bg2)',color:'var(--text3)',flexShrink:0}}>+7</div>
                  <input value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/g,''))} placeholder="999 123-45-67" maxLength={10}
                    style={{...inp,borderRadius:'0 8px 8px 0'}} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
                </div>
                <button onClick={goStep2} style={btnP}>Получить код по СМС</button>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginTop:10}}>
                  {[['WhatsApp','#25d366'],['Telegram','#0088cc']].map(([l,c])=>(
                    <button key={l} onClick={goStep2} style={{padding:'10px',borderRadius:10,fontSize:13,fontWeight:600,border:'1.5px solid var(--border)',background:'var(--bg)',color:'var(--text2)',cursor:'pointer',fontFamily:'inherit',display:'flex',alignItems:'center',justifyContent:'center',gap:7}}>
                      <div style={{width:18,height:18,borderRadius:4,background:c,flexShrink:0}}/>{l}
                    </button>
                  ))}
                </div>
              </div>
            ):(
              <div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14}}>
                  <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Имя</label>
                    <input value={name} onChange={e=>setName(e.target.value)} placeholder="Иван" style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/></div>
                  <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Фамилия</label>
                    <input placeholder="Иванов" style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/></div>
                </div>
                <div style={{marginBottom:14}}><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Email</label>
                  <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="ivan@mail.ru" style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/></div>
                <div style={{marginBottom:20}}>
                  <label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Пароль</label>
                  <input type="password" value={pass} onChange={e=>{setPass(e.target.value);calcPwd(e.target.value);}} placeholder="Минимум 8 символов" style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
                  {pass && (<><div style={{height:4,background:'var(--bg3)',borderRadius:2,overflow:'hidden',marginTop:6}}><div style={{height:'100%',background:pwdColors[pwdStr-1]||'var(--bg3)',borderRadius:2,width:`${pwdStr/4*100}%`,transition:'width .3s,background .3s'}}/></div><div style={{fontSize:11,color:'var(--text3)',marginTop:3}}>{['Слабый','Средний','Хороший','Отличный'][pwdStr-1]||''}</div></>)}
                </div>
                <button onClick={()=>setStep(3)} style={btnP}>Создать аккаунт</button>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: code */}
        {step===2 && (
          <div>
            <div style={{textAlign:'center',marginBottom:20}}>
              <div style={{fontSize:36,marginBottom:10}}>📱</div>
              <div style={{fontSize:15,fontWeight:600,marginBottom:4,color:'var(--text)'}}>Введите код подтверждения</div>
              <div style={{fontSize:13,color:'var(--text3)'}}>Отправили на +7 {phone}</div>
            </div>
            <div style={{display:'flex',gap:8,justifyContent:'center',marginBottom:20}}>
              {code.map((c,i)=>(
                <input key={i} id={`rc${i}`} value={c} onChange={e=>codeChange(i,e.target.value)} maxLength={1}
                  style={{width:48,height:52,textAlign:'center',fontSize:22,fontWeight:700,border:'1.5px solid var(--border)',borderRadius:10,outline:'none',color:'var(--text)',background:'var(--bg)',fontFamily:'inherit',transition:'border-color .15s'}}
                  onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
              ))}
            </div>
            <button onClick={verifyCode} style={btnP}>Подтвердить</button>
            <div style={{textAlign:'center',marginTop:10}}><button onClick={()=>setStep(1)} style={{fontSize:13,color:'#7c3aed',background:'none',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Изменить номер</button></div>
          </div>
        )}

        {/* STEP 3: goal */}
        {step===3 && (
          <div>
            <div style={{fontSize:17,fontWeight:700,marginBottom:16,color:'var(--text)'}}>Что хотите сделать первым?</div>
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {[['Создать резюме голосом','2 минуты и резюме готово','/voice'],['Загрузить и улучшить резюме','Найдём и исправим слабые места','/upgrade'],['Посмотреть вакансии','Требуется тариф Про','/vacancies']].map(([title,desc,href])=>(
                <button key={href} onClick={()=>finish(href)} style={{display:'flex',alignItems:'center',gap:14,padding:'16px 18px',borderRadius:14,fontSize:15,border:'1.5px solid var(--border)',background:'var(--bg)',cursor:'pointer',fontFamily:'inherit',textAlign:'left',transition:'all .15s'}}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.borderColor='#7c3aed';(e.currentTarget as HTMLElement).style.background='var(--purple-light)';}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.borderColor='var(--border)';(e.currentTarget as HTMLElement).style.background='var(--bg)';}}>
                  <div style={{width:44,height:44,background:'var(--purple-light)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                    <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  </div>
                  <div><div style={{fontSize:15,fontWeight:700,color:'var(--text)'}}>{title}</div><div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>{desc}</div></div>
                </button>
              ))}
            </div>
          </div>
        )}

        <p style={{fontSize:12,color:'var(--text4)',textAlign:'center',marginTop:16,lineHeight:1.55}}>
          Регистрируясь, вы соглашаетесь с <Link href="/terms" target="_blank" style={{color:'#7c3aed'}}>условиями использования</Link> и <Link href="/privacy" target="_blank" style={{color:'#7c3aed'}}>политикой конфиденциальности</Link>
        </p>
        <div style={{fontSize:13,color:'var(--text3)',textAlign:'center',marginTop:10}}>
          Уже есть аккаунт? <Link href="/login" style={{color:'#7c3aed',fontWeight:600,textDecoration:'none'}}>Войти</Link>
        </div>
      </div>
    </div>
  );
}
