'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

type Method = 'phone' | 'email';
type PhoneStep = 'number' | 'code';

export default function LoginPage() {
  const [method, setMethod] = useState<Method>('phone');
  const [phoneStep, setPhoneStep] = useState<PhoneStep>('number');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState(['','','','','','']);
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const router = useRouter();

  const sendSMS = () => { if(phone.length < 10){alert('Введите номер телефона');return;} setPhoneStep('code'); };
  const verifyCode = () => {
    localStorage.setItem('rvUser', JSON.stringify({id:'demo',name:'Пользователь',email,phone,plan:'free'}));
    router.push('/dashboard');
  };
  const loginEmail = () => {
    localStorage.setItem('rvUser', JSON.stringify({id:'demo',name:email.split('@')[0],email,plan:'free'}));
    router.push('/dashboard');
  };

  const codeChange = (i: number, v: string) => {
    if (!/^\d?$/.test(v)) return;
    const next = [...code]; next[i] = v; setCode(next);
    if (v && i < 5) (document.getElementById(`ci${i+1}`) as HTMLInputElement)?.focus();
    if (next.every(c=>c) && next.join('').length === 6) setTimeout(verifyCode, 300);
  };

  const logoS: React.CSSProperties = { display:'flex', alignItems:'center', gap:10, textDecoration:'none', marginBottom:4 };
  const tabS = (on: boolean): React.CSSProperties => ({ flex:1, padding:'9px', textAlign:'center', fontSize:13, fontWeight: on?700:500, color: on?'var(--text)':'var(--text3)', borderRadius:8, cursor:'pointer', transition:'all .2s', background: on?'white':'transparent', boxShadow: on?'0 1px 4px rgba(0,0,0,.08)':'none' });
  const inp: React.CSSProperties = { width:'100%', padding:'11px 14px', border:'1.5px solid var(--border)', borderRadius:8, fontSize:15, color:'var(--text)', background:'var(--bg)', outline:'none', fontFamily:'inherit', transition:'border-color .15s' };
  const btnP: React.CSSProperties = { width:'100%', padding:13, borderRadius:10, fontSize:15, fontWeight:600, border:'none', background:'#7c3aed', color:'white', cursor:'pointer', fontFamily:'inherit' };

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg2)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'40px 20px' }}>
      <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:24, padding:40, width:'100%', maxWidth:440, boxShadow:'0 4px 24px rgba(0,0,0,.06)' }}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
          <Link href="/" style={{display:'flex',alignItems:'center',gap:10,textDecoration:'none'}}>
            <img src="/logo.png" alt="RV" style={{height:36,objectFit:'contain'}} />
            <span style={{fontSize:19,fontWeight:800,color:'var(--text)'}}>Resume<span style={{color:'#7c3aed'}}>Voice</span></span>
          </Link>
          <Link href="/" title="Назад на сайт" style={{width:32,height:32,borderRadius:8,border:'1.5px solid var(--border)',background:'var(--bg2)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--text3)',textDecoration:'none',flexShrink:0}}>
            <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </Link>
        </div>
        <p style={{fontSize:11,color:'var(--text4)',marginBottom:28}}>Создание резюме голосом и поиск работы в одном сервисе</p>
        <div style={{fontSize:22,fontWeight:800,letterSpacing:'-.5px',marginBottom:4,color:'var(--text)'}}>Войти в аккаунт</div>
        <div style={{fontSize:14,color:'var(--text3)',marginBottom:24}}>Войдите чтобы управлять резюме и вакансиями</div>

        <div style={{display:'flex',background:'var(--bg3)',borderRadius:10,padding:3,marginBottom:24,gap:0}}>
          <div style={tabS(method==='phone')} onClick={()=>{setMethod('phone');setPhoneStep('number');}}>По телефону</div>
          <div style={tabS(method==='email')} onClick={()=>setMethod('email')}>По email</div>
        </div>

        {method === 'phone' && phoneStep === 'number' && (
          <div>
            <label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Номер телефона</label>
            <div style={{display:'flex',gap:0,marginBottom:16}}>
              <div style={{...inp,width:'auto',padding:'11px 14px',borderRight:'none',borderRadius:'8px 0 0 8px',background:'var(--bg2)',color:'var(--text3)',flexShrink:0}}>+7</div>
              <input value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/g,''))} placeholder="999 123-45-67" maxLength={10}
                style={{...inp,borderRadius:'0 8px 8px 0'}} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
            </div>
            <button onClick={sendSMS} style={btnP}>Получить код по СМС</button>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginTop:10}}>
              <button onClick={sendSMS} style={{padding:'10px',borderRadius:10,fontSize:13,fontWeight:600,border:'1.5px solid #25d366',background:'#f0fdf4',color:'#15803d',cursor:'pointer',fontFamily:'inherit',display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="#25d366"><path fill="#25d366" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
              </button>
              <button onClick={sendSMS} style={{padding:'10px',borderRadius:10,fontSize:13,fontWeight:600,border:'1.5px solid #0088cc',background:'#eff9ff',color:'#0055a5',cursor:'pointer',fontFamily:'inherit',display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="#0088cc"><path fill="#0088cc" d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248l-1.97 9.289c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.932z"/></svg>
                Telegram
              </button>
            </div>
          </div>
        )}

        {method === 'phone' && phoneStep === 'code' && (
          <div>
            <div style={{textAlign:'center',marginBottom:20}}>
              <div style={{fontSize:15,fontWeight:600,marginBottom:4,color:'var(--text)'}}>Введите код из СМС</div>
              <div style={{fontSize:13,color:'var(--text3)'}}>Отправили на +7 {phone}</div>
            </div>
            <div style={{display:'flex',gap:8,justifyContent:'center',marginBottom:20}}>
              {code.map((c,i)=>(
                <input key={i} id={`ci${i}`} value={c} onChange={e=>codeChange(i,e.target.value)} maxLength={1}
                  style={{width:48,height:52,textAlign:'center',fontSize:22,fontWeight:700,border:'1.5px solid var(--border)',borderRadius:10,outline:'none',color:'var(--text)',background:'var(--bg)',fontFamily:'inherit',transition:'border-color .15s'}}
                  onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
              ))}
            </div>
            <button onClick={verifyCode} style={btnP}>Войти</button>
            <div style={{textAlign:'center',marginTop:10}}>
              <button onClick={()=>setPhoneStep('number')} style={{fontSize:13,color:'#7c3aed',background:'none',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Изменить номер</button>
            </div>
          </div>
        )}

        {method === 'email' && (
          <div>
            <div style={{marginBottom:16}}>
              <label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Email</label>
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="ivan@mail.ru"
                style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
            </div>
            <div style={{marginBottom:20}}>
              <label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Пароль</label>
              <input type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••"
                onKeyDown={e=>e.key==='Enter'&&loginEmail()}
                style={inp} onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
              <div style={{textAlign:'right',marginTop:6}}><button style={{fontSize:12,color:'#7c3aed',background:'none',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Забыли пароль?</button></div>
            </div>
            <button onClick={loginEmail} style={btnP}>Войти</button>
          </div>
        )}

        <div style={{fontSize:13,color:'var(--text3)',textAlign:'center',marginTop:20}}>
          Нет аккаунта? <Link href="/register" style={{color:'#7c3aed',fontWeight:600,textDecoration:'none'}}>Создать бесплатно</Link>
        </div>
      </div>
    </div>
  );
}
