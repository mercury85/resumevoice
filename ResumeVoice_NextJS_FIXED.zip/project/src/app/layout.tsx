import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import '@/styles/globals.css';
import { ThemeProvider } from '@/context/ThemeContext';
import { AuthProvider } from '@/context/AuthContext';

const inter = Inter({
  subsets: ['latin', 'cyrillic'],
  display: 'swap',
  variable: '--font-inter',
});

const SITE_URL  = 'https://resumevoice.ru';
const SITE_NAME = 'ResumeVoice';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),

  title: {
    default: 'ResumeVoice — создать резюме голосом бесплатно | Поиск работы в России',
    template: '%s | ResumeVoice',
  },
  description:
    'Расскажите о себе голосом — получите готовое профессиональное резюме за 30 секунд. Автоматический подбор вакансий каждый день. Бесплатно. Без регистрации формы.',

  keywords: [
    'создать резюме онлайн бесплатно',
    'резюме голосом',
    'составить резюме',
    'поиск работы Россия',
    'резюме онлайн',
    'бесплатное резюме',
    'создать резюме быстро',
    'голосовое резюме',
    'автоматическое резюме',
    'резюме за минуту',
    'подбор вакансий',
    'вакансии по резюме',
    'ResumeVoice',
  ],

  authors: [{ name: 'ResumeVoice', url: SITE_URL }],
  creator: 'ResumeVoice',
  publisher: 'ResumeVoice',

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },

  openGraph: {
    type: 'website',
    locale: 'ru_RU',
    url: SITE_URL,
    siteName: SITE_NAME,
    title: 'ResumeVoice — резюме голосом за 30 секунд',
    description:
      'Первый в России сервис создания резюме голосом. Расскажите о себе — получите готовое резюме и подходящие вакансии бесплатно.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'ResumeVoice — создать резюме голосом',
        type: 'image/png',
      },
    ],
  },

  twitter: {
    card: 'summary_large_image',
    title: 'ResumeVoice — резюме голосом за 30 секунд',
    description: 'Расскажите о себе голосом — получите резюме и вакансии бесплатно.',
    images: ['/og-image.png'],
  },

  alternates: {
    canonical: SITE_URL,
    languages: { 'ru-RU': SITE_URL },
  },

  icons: {
    icon: [
      { url: '/favicon.ico', sizes: 'any' },
      { url: '/icon.svg', type: 'image/svg+xml' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
    ],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
    other: [{ rel: 'mask-icon', url: '/safari-pinned-tab.svg', color: '#7c3aed' }],
  },

  manifest: '/site.webmanifest',

  verification: {
    // Добавьте ваши коды верификации:
    google: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION ?? '',
    yandex: process.env.NEXT_PUBLIC_YANDEX_VERIFICATION ?? '',
  },

  other: {
    'yandex-verification': process.env.NEXT_PUBLIC_YANDEX_VERIFICATION ?? '',
    'geo.region': 'RU',
    'geo.country': 'Russia',
    'og:locale': 'ru_RU',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)',  color: '#0f0e17' },
  ],
};

// JSON-LD структурированные данные
const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'WebSite',
      '@id': `${SITE_URL}/#website`,
      url: SITE_URL,
      name: SITE_NAME,
      description: 'Первый в России сервис создания резюме голосом',
      inLanguage: 'ru-RU',
      potentialAction: {
        '@type': 'SearchAction',
        target: {
          '@type': 'EntryPoint',
          urlTemplate: `${SITE_URL}/vacancies?text={search_term_string}`,
        },
        'query-input': 'required name=search_term_string',
      },
    },
    {
      '@type': 'Organization',
      '@id': `${SITE_URL}/#organization`,
      name: SITE_NAME,
      url: SITE_URL,
      logo: {
        '@type': 'ImageObject',
        url: `${SITE_URL}/logo.png`,
        width: 200,
        height: 60,
      },
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'customer support',
        email: 'support@resumevoice.ru',
        availableLanguage: 'Russian',
      },
    },
    {
      '@type': 'SoftwareApplication',
      name: SITE_NAME,
      operatingSystem: 'Web',
      applicationCategory: 'BusinessApplication',
      offers: [
        { '@type': 'Offer', name: 'Бесплатно', price: '0', priceCurrency: 'RUB' },
        { '@type': 'Offer', name: 'Про',       price: '699', priceCurrency: 'RUB', billingIncrement: 'P1M' },
        { '@type': 'Offer', name: 'Премиум',   price: '1490', priceCurrency: 'RUB', billingIncrement: 'P1M' },
      ],
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: '4.8',
        ratingCount: '1240',
        bestRating: '5',
        worstRating: '1',
      },
    },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        {/* Яндекс.Вебмастер */}
        {process.env.NEXT_PUBLIC_YANDEX_VERIFICATION && (
          <meta name="yandex-verification" content={process.env.NEXT_PUBLIC_YANDEX_VERIFICATION} />
        )}
        {/* Preconnect для быстрой загрузки */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://flagcdn.com" />
        {/* JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {/* Prevent dark mode flash */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('rvTheme');if(t==='dark'){document.documentElement.setAttribute('data-theme','dark');}}catch(e){}})();`,
          }}
        />
      </head>
      <body className={inter.variable} suppressHydrationWarning>
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
