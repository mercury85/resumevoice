'use client';
import { useState, useRef, useEffect } from 'react';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';

interface Msg { role:'bot'|'user'; text:string; time:string; }

const SYSTEM_PROMPTS = [
  'Помогаю создать резюме', 'Подбираю вакансии', 'Готовлю к собеседованию',
  'Пишу сопроводительные письма', 'Анализирую рынок труда',
];

const STARTER_QUESTIONS = [
  'Как создать резюме голосом?', 'Какие тарифы есть?',
  'Как подключить уведомления в Telegram?', 'Как найти вакансии?',
  'Как подготовиться к собеседованию?', 'Как улучшить моё резюме?',
  'Сколько стоит тариф Про?', 'Как отправить резюме работодателю?',
];

const KB: Array<{k:string[];a:string}> = [
  {k:['создать резюме','голосом','записать'],a:'Нажмите на большой фиолетовый микрофон на главной или перейдите в раздел "Создать резюме". Расскажите о себе 1-2 минуты в свободной форме — резюме готово за 30 секунд.'},
  {k:['тариф','цена','стоит','оплат'],a:'3 тарифа:\n\n• Бесплатно (0 руб) — 1 резюме, 1 письмо, без вакансий\n• Про (699 руб/мес) — безлимит резюме, до 100 вакансий/день, PDF и Word\n• Премиум (1490 руб/мес) — полный безлимит, 10 направлений, анализ зарплат'},
  {k:['вакансии','работа','hh'],a:'Вакансии подбираются по вашему резюме. Перейдите в "Вакансии" или "Подбор работы". Настройте профессии, города и минимальную зарплату — сервис будет находить подходящие предложения каждый день.'},
  {k:['telegram','уведомлени'],a:'В разделе "Подбор работы" нажмите "Подключить Telegram" — каждое утро в 9:00 будете получать список новых подходящих вакансий прямо в мессенджер.'},
  {k:['войти','регистрация','аккаунт'],a:'Регистрация и вход доступны по телефону (СМС-код), через WhatsApp, Telegram или email. Нажмите "Войти" или "Начать бесплатно" в правом верхнем углу.'},
  {k:['pdf','word','docx','скачать'],a:'PDF доступен на всех тарифах. Word (DOCX) — с тарифа Про. Кнопка "Скачать" в редакторе резюме или в разделе "Мои резюме".'},
  {k:['отправить','мессенджер','whatsapp','поделиться'],a:'В разделе "Мои резюме" нажмите "Поделиться" — откроются кнопки отправки в Telegram, WhatsApp и ВКонтакте. Или скопируйте ссылку на ваше резюме.'},
  {k:['улучшить','анализ','аудит'],a:'Раздел "Улучшить резюме" — загрузите PDF/DOCX/TXT, сервис проанализирует по 15 критериям и покажет конкретные правки в режиме "было — стало". Оценка резюме вырастает в среднем на 220 пунктов.'},
  {k:['собеседовани','интервью'],a:'Раздел "Тренировка собеседования" — сервис задаёт вопросы как настоящий HR, вы отвечаете голосом. После — детальный разбор каждого ответа и конкретные советы как отвечать лучше.'},
  {k:['возврат','деньги'],a:'Возврат возможен в течение 14 дней с момента оплаты, если вы не использовали платные функции. Напишите через "Обратная связь" — вернём деньги в течение 3-5 рабочих дней.'},
  {k:['сопроводительн','письмо'],a:'Сопроводительные письма создаются одной кнопкой для любой вакансии. Или надиктуйте голосом что добавить — сервис учтёт ваши пожелания. На бесплатном тарифе доступно 1 письмо.'},
];

const now = () => new Date().toLocaleTimeString('ru',{hour:'2-digit',minute:'2-digit'});

export default function AssistantPage() {
  const [msgs, setMsgs] = useState<Msg[]>([
    {role:'bot',text:'Привет! Я ваш персональный помощник ResumeVoice. Могу помочь с созданием резюме, поиском вакансий, подготовкой к собеседованию и любыми другими вопросами о сервисе.',time:now()},
  ]);
  const [inp, setInp] = useState('');
  const [typing, setTyping] = useState(false);
  const msgsRef = useRef<HTMLDivElement>(null);

  useEffect(()=>{if(msgsRef.current)msgsRef.current.scrollTop=msgsRef.current.scrollHeight;},[msgs]);

  const findAns=(q:string)=>{
    const ql=q.toLowerCase();
    for(const kb of KB) if(kb.k.some(k=>ql.includes(k))) return kb.a;
    return 'Интересный вопрос! По этой теме рекомендую написать напрямую нашей команде через страницу "Обратная связь" или Telegram @resumevoice_support — ответим подробно в течение часа.';
  };

  const send=(text?:string)=>{
    const q=(text??inp).trim();if(!q)return;
    setMsgs(m=>[...m,{role:'user',text:q,time:now()}]);
    setInp('');setTyping(true);
    setTimeout(()=>{setTyping(false);setMsgs(m=>[...m,{role:'bot',text:findAns(q),time:now()}]);},800);
  };

  return (
    <>
      <ScrollProgress/>
      <Nav/>
      <main>
        <div style={{maxWidth:900,margin:'0 auto',padding:'48px 24px 80px'}}>
          <div style={{textAlign:'center',marginBottom:32}}>
            <div style={{display:'inline-flex',alignItems:'center',gap:7,background:'var(--purple-light)',border:'1.5px solid var(--purple-mid)',color:'#7c3aed',fontSize:13,fontWeight:600,padding:'6px 16px',borderRadius:100,marginBottom:16}}>
              <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              AI Ассистент
            </div>
            <h1 style={{fontSize:'clamp(28px,4vw,42px)',fontWeight:900,letterSpacing:'-1.5px',color:'var(--text)',textAlign:'center',marginBottom:12}}>
              Персональный <span style={{color:'#7c3aed'}}>помощник</span>
            </h1>
            <p style={{fontSize:15,color:'var(--text3)',maxWidth:440,margin:'0 auto',textAlign:'center',lineHeight:1.6}}>
              Отвечу на любые вопросы о создании резюме, поиске работы и сервисе ResumeVoice.
            </p>
          </div>

          {/* Starter questions */}
          <div style={{display:'flex',flexWrap:'wrap',gap:8,justifyContent:'center',marginBottom:24}}>
            {STARTER_QUESTIONS.map(q=>(
              <button key={q} onClick={()=>send(q)} style={{padding:'7px 14px',borderRadius:100,fontSize:13,border:'1.5px solid var(--purple-mid)',background:'var(--purple-light)',color:'#7c3aed',cursor:'pointer',fontFamily:'inherit',transition:'all .15s'}}
                onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background='var(--purple-mid)'}
                onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='var(--purple-light)'}>
                {q}
              </button>
            ))}
          </div>

          {/* Chat */}
          <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:20,overflow:'hidden',boxShadow:'0 4px 20px rgba(0,0,0,.06)'}}>
            <div style={{background:'var(--purple-light)',padding:'16px 20px',display:'flex',alignItems:'center',gap:12,borderBottom:'1px solid var(--purple-mid)'}}>
              <div style={{width:40,height:40,borderRadius:'50%',background:'linear-gradient(135deg,#7c3aed,#a78bfa)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <svg width="20" height="20" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              </div>
              <div>
                <div style={{fontSize:15,fontWeight:700,color:'var(--text)'}}>Помощник ResumeVoice</div>
                <div style={{fontSize:12,color:'#7c3aed'}}>Онлайн — знает всё о сервисе</div>
              </div>
              <div style={{marginLeft:'auto',display:'flex',flexWrap:'wrap',gap:4}}>
                {SYSTEM_PROMPTS.map(p=><span key={p} style={{fontSize:11,padding:'2px 8px',borderRadius:100,background:'rgba(124,58,237,.15)',color:'#7c3aed',border:'1px solid var(--purple-mid)'}}>{p}</span>)}
              </div>
            </div>

            <div ref={msgsRef} style={{height:440,overflowY:'auto',padding:20,display:'flex',flexDirection:'column',gap:12}}>
              {msgs.map((m,i)=>(
                <div key={i} style={{display:'flex',flexDirection:'column',alignItems:m.role==='user'?'flex-end':'flex-start',gap:4}}>
                  <div style={{padding:'12px 16px',borderRadius:16,fontSize:14,lineHeight:1.6,maxWidth:'75%',whiteSpace:'pre-line',
                    background:m.role==='user'?'#7c3aed':'var(--purple-light)',
                    color:m.role==='user'?'white':'var(--text)',
                    borderBottomRightRadius:m.role==='user'?4:16,
                    borderBottomLeftRadius:m.role==='bot'?4:16,
                  }}>
                    {m.text}
                  </div>
                  <div style={{fontSize:11,color:'var(--text4)'}}>{m.time}</div>
                </div>
              ))}
              {typing && (
                <div style={{display:'flex',alignItems:'flex-start',gap:4,flexDirection:'column'}}>
                  <div style={{padding:'12px 16px',borderRadius:16,fontSize:14,background:'var(--purple-light)',color:'var(--text)',borderBottomLeftRadius:4}}>
                    <span style={{display:'inline-flex',gap:4}}>
                      {[0,1,2].map(i=><span key={i} style={{width:6,height:6,borderRadius:'50%',background:'#7c3aed',display:'inline-block',animation:`wvs 1.2s ${i*0.2}s ease-in-out infinite`}}/>)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div style={{padding:'14px 20px',borderTop:'1px solid var(--border)',display:'flex',gap:10,background:'var(--bg)'}}>
              <input value={inp} onChange={e=>setInp(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()}
                placeholder="Задайте любой вопрос о ResumeVoice..."
                style={{flex:1,padding:'11px 16px',border:'1.5px solid var(--border)',borderRadius:12,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit',transition:'border-color .15s'}}
                onFocus={e=>e.target.style.borderColor='#7c3aed'}
                onBlur={e=>e.target.style.borderColor='var(--border)'}/>
              <button onClick={()=>send()} style={{width:44,height:44,borderRadius:12,background:'#7c3aed',border:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,transition:'opacity .15s'}}
                onMouseEnter={e=>(e.currentTarget as HTMLElement).style.opacity='.88'}
                onMouseLeave={e=>(e.currentTarget as HTMLElement).style.opacity='1'}>
                <svg width="18" height="18" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
              </button>
            </div>
          </div>
        </div>
      </main>
      <Footer/>
      <style>{`@keyframes wvs{0%,100%{transform:scaleY(.5);opacity:.3}50%{transform:scaleY(1);opacity:1}}`}</style>
    </>
  );
}
