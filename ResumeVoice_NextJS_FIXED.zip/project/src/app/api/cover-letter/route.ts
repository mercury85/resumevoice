export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { chat } from '@/lib/ai';
import { coverLetterPrompt } from '@/lib/prompts';
import type { ResumeData, Vacancy } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const { resumeData, vacancy, extra } = await req.json() as {
      resumeData: ResumeData;
      vacancy: Vacancy;
      extra?: string;
    };

    if (!resumeData || !vacancy) {
      return NextResponse.json({ ok: false, error: 'Необходимы данные резюме и вакансии' }, { status: 400 });
    }

    const letter = await chat([{
      role: 'user',
      content: coverLetterPrompt(resumeData, vacancy, extra),
    }]);

    return NextResponse.json({ ok: true, data: { letter } });
  } catch (e) {
    console.error('[cover-letter]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка создания письма' }, { status: 500 });
  }
}
