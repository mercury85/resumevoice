export const dynamic = 'force-dynamic';
/**
 * POST /api/admin/auth  — вход, устанавливает HttpOnly JWT cookie
 * DELETE /api/admin/auth — выход, стирает cookie
 *
 * .env.local:
 *   ADMIN_LOGIN=ваш_логин
 *   ADMIN_PASSWORD_HASH=sha256_хеш_пароля
 *   JWT_SECRET=минимум_32_символа
 */
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { jwtSign, safeEqual } from '@/lib/admin-auth';

// ── Rate limiter (in-memory) ──────────────────────────────────────────────────
const rl = new Map<string, { count: number; until: number }>();
const RL_MAX    = 10;
const RL_WINDOW = 15 * 60 * 1000;

function getIp(req: NextRequest): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim()
      ?? req.headers.get('x-real-ip')
      ?? 'unknown';
}

function checkRateLimit(ip: string): { blocked: boolean; remaining: number } {
  const now   = Date.now();
  const entry = rl.get(ip);
  if (!entry || now > entry.until) {
    rl.set(ip, { count: 0, until: now + RL_WINDOW });
    return { blocked: false, remaining: RL_MAX };
  }
  if (entry.count >= RL_MAX) return { blocked: true, remaining: 0 };
  return { blocked: false, remaining: RL_MAX - entry.count };
}

function recordFailure(ip: string): void {
  const now   = Date.now();
  const entry = rl.get(ip) ?? { count: 0, until: now + RL_WINDOW };
  entry.count += 1;
  rl.set(ip, entry);
}

function resetRateLimit(ip: string): void { rl.delete(ip); }

// ── Константы сессии ──────────────────────────────────────────────────────────
const COOKIE_NAME  = 'rv_admin_session';
const SESSION_TTL  = 8 * 60 * 60; // секунды

// ── POST — логин ──────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  const ip = getIp(req);
  const { blocked, remaining } = checkRateLimit(ip);

  if (blocked) {
    return NextResponse.json(
      { ok: false, error: 'Слишком много попыток. Повторите через 15 минут.' },
      { status: 429, headers: { 'Retry-After': '900' } }
    );
  }

  let login: string, pass: string;
  try {
    const body = await req.json();
    login = String(body.login ?? '').trim().toLowerCase();
    pass  = String(body.pass  ?? '');
  } catch {
    return NextResponse.json({ ok: false, error: 'Неверный формат запроса' }, { status: 400 });
  }

  if (!login || !pass) {
    return NextResponse.json({ ok: false, error: 'Введите логин и пароль' }, { status: 400 });
  }

  const envLogin    = process.env.ADMIN_LOGIN?.trim().toLowerCase();
  const envPassHash = process.env.ADMIN_PASSWORD_HASH?.trim().toLowerCase();
  const jwtSecret   = process.env.JWT_SECRET;

  if (!envLogin || !envPassHash || !jwtSecret || jwtSecret.length < 32) {
    console.error('[admin/auth] Не заданы ADMIN_LOGIN, ADMIN_PASSWORD_HASH или JWT_SECRET');
    return NextResponse.json(
      { ok: false, error: 'Администратор не настроен. Проверьте .env.local' },
      { status: 503 }
    );
  }

  const inputHash = crypto.createHash('sha256').update(pass).digest('hex').toLowerCase();

  // Задержка против timing-атак (всегда, независимо от результата)
  await new Promise(r => setTimeout(r, 150 + Math.random() * 150));

  if (!safeEqual(login, envLogin) || !safeEqual(inputHash, envPassHash)) {
    recordFailure(ip);
    return NextResponse.json(
      { ok: false, error: `Неверный логин или пароль. Осталось попыток: ${remaining - 1}` },
      { status: 401 }
    );
  }

  resetRateLimit(ip);

  const now   = Math.floor(Date.now() / 1000);
  const token = jwtSign(
    { sub: 'admin', iat: now, exp: now + SESSION_TTL, role: 'admin' },
    jwtSecret
  );

  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge:   SESSION_TTL,
    path:     '/admin',
  });
  return res;
}

// ── DELETE — логаут ───────────────────────────────────────────────────────────
export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, '', { maxAge: 0, path: '/admin' });
  return res;
}
