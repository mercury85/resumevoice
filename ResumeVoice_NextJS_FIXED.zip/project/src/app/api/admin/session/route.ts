export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from '@/lib/admin-auth';

export async function GET(req: NextRequest) {
  const token  = req.cookies.get('rv_admin_session')?.value;
  const secret = process.env.JWT_SECRET ?? '';
  if (!token || secret.length < 32) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  const payload = jwtVerify(token, secret);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  return NextResponse.json({ ok: true });
}
