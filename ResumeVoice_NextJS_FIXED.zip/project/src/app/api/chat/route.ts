export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { chat } from '@/lib/ai';

type Role = 'user' | 'assistant' | 'system';
interface HistoryItem { role: Role; content: string; }

const SYSTEM = `Ты — умный помощник сервиса ResumeVoice.
ResumeVoice — первый в России сервис создания резюме голосом и поиска работы.
Тарифы: Бесплатно (0 руб), Про (699 руб/мес), Премиум (1490 руб/мес).
Вакансии: Про — до 100 в день, Премиум — безлимит.
Платежи: карта, СБП. Уведомления: Telegram каждое утро.
Отвечай на русском, кратко и по делу.`;

export async function POST(req: NextRequest) {
  try {
    const { message, history = [] } = await req.json() as {
      message: string;
      history: HistoryItem[];
    };
    if (!message) return NextResponse.json({ ok: false, error: 'Нет сообщения' }, { status: 400 });

    const messages = [
      { role: 'system' as const, content: SYSTEM },
      ...history.slice(-10).map(m => ({
        role: (m.role === 'user' || m.role === 'assistant' ? m.role : 'user') as 'user' | 'assistant',
        content: String(m.content),
      })),
      { role: 'user' as const, content: message },
    ];

    const response = await chat(messages, { temperature: 0.7, maxTokens: 800 });
    return NextResponse.json({ ok: true, data: { text: response } });
  } catch (e) {
    console.error('[chat]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка ответа' }, { status: 500 });
  }
}
