export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { chat } from '@/lib/ai';
import { auditResumePrompt } from '@/lib/prompts';

export async function POST(req: NextRequest) {
  try {
    const { resumeText } = await req.json() as { resumeText: string };
    if (!resumeText) return NextResponse.json({ ok: false, error: 'Нет текста' }, { status: 400 });

    const raw = await chat([{ role: 'user', content: auditResumePrompt(resumeText) }]);
    const cleaned = raw.replace(/^```[a-z]*\n?|```$/gm, '').trim();

    let result;
    try { result = JSON.parse(cleaned); }
    catch { return NextResponse.json({ ok: false, error: 'Ошибка разбора ответа' }, { status: 502 }); }

    return NextResponse.json({ ok: true, data: result });
  } catch (e) {
    console.error('[upgrade]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка анализа' }, { status: 500 });
  }
}
