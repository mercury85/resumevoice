export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { transcribe } from '@/lib/speech';

export const maxDuration = 30; // seconds

export async function POST(req: NextRequest) {
  try {
    const contentType = req.headers.get('content-type') ?? '';
    if (!contentType.includes('audio/') && !contentType.includes('application/octet-stream')) {
      return NextResponse.json({ ok: false, error: 'Ожидается аудио файл' }, { status: 400 });
    }

    const buf = Buffer.from(await req.arrayBuffer());
    if (buf.length === 0) {
      return NextResponse.json({ ok: false, error: 'Пустой файл' }, { status: 400 });
    }

    const text = await transcribe(buf);

    if (!text || text.trim().length < 5) {
      return NextResponse.json({
        ok: false,
        error: 'Речь не распознана. Попробуйте говорить чётче или ближе к микрофону.',
        code: 'LOW_CONFIDENCE',
      }, { status: 422 });
    }

    return NextResponse.json({ ok: true, data: { text } });
  } catch (e: unknown) {
    console.error('[transcribe]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка распознавания речи' }, { status: 500 });
  }
}
