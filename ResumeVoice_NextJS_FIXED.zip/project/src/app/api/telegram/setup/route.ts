export const dynamic = 'force-dynamic';
/**
 * GET /api/telegram/setup?secret=SETUP_SECRET
 * Вызвать ОДИН раз после деплоя чтобы зарегистрировать вебхук.
 * Защищён секретом из env.
 */
import { NextRequest, NextResponse } from 'next/server';
import { setWebhook, getMe } from '@/lib/telegram';

export async function GET(req: NextRequest) {
  const secret = req.nextUrl.searchParams.get('secret');
  if (secret !== process.env.SETUP_SECRET) {
    return NextResponse.json({ ok: false, error: 'Forbidden' }, { status: 403 });
  }

  const host = process.env.NEXT_PUBLIC_SITE_URL ?? `https://${req.headers.get('host')}`;
  const webhookUrl = `${host}/api/telegram/webhook`;

  const [me, webhookResult] = await Promise.all([
    getMe(),
    setWebhook(webhookUrl),
  ]);

  return NextResponse.json({
    ok: true,
    bot: me,
    webhook: webhookUrl,
    registered: webhookResult,
  });
}
