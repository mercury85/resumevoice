export const dynamic = 'force-dynamic';
/**
 * POST /api/telegram/webhook
 * Вебхук принимает обновления от Telegram Bot API.
 */
import { NextRequest, NextResponse } from 'next/server';
import {
  TgUpdate, sendMessage, answerCallbackQuery, sendWelcome,
} from '@/lib/telegram';
import { supabaseAdmin } from '@/lib/supabase';

export async function POST(req: NextRequest) {
  try {
    const update: TgUpdate = await req.json();

    if (update.message) {
      const msg    = update.message;
      const chatId = msg.chat.id;
      const text   = msg.text?.trim() ?? '';
      const from   = msg.from;

      if (text.startsWith('/start')) {
        const token = text.split(' ')[1];
        if (token) {
          const db = supabaseAdmin();
          const { data: user } = await db
            .from('users')
            .select('id, name')
            .eq('tg_link_token', token)
            .single();
          if (user) {
            await db.from('users').update({
              telegram_chat_id: String(chatId),
              telegram_username: from?.username ?? null,
              tg_link_token: null,
            }).eq('id', user.id);
            await sendMessage(chatId,
              '✅ *Telegram подключён\\!*\n\nВы будете получать уведомления о вакансиях и резюме\\.',
              { parseMode: 'MarkdownV2' }
            );
            return NextResponse.json({ ok: true });
          }
        }
        await sendWelcome(chatId, from?.first_name);
        return NextResponse.json({ ok: true });
      }

      if (text === '/help') {
        await sendMessage(chatId,
          '*Команды:*\n\n/start — подключить уведомления\n/stop — отключить\n/help — справка\n\n[Перейти на сайт](https://resumevoice.ru)',
          { parseMode: 'MarkdownV2' }
        );
        return NextResponse.json({ ok: true });
      }

      if (text === '/stop') {
        const db = supabaseAdmin();
        await db.from('users').update({ telegram_chat_id: null }).eq('telegram_chat_id', String(chatId));
        await sendMessage(chatId, '🔕 Уведомления отключены. Напишите /start чтобы подключиться снова.');
        return NextResponse.json({ ok: true });
      }

      await sendMessage(chatId,
        'Перейдите на сайт чтобы создать резюме: [resumevoice\\.ru](https://resumevoice.ru)',
        { parseMode: 'MarkdownV2' }
      );
    }

    if (update.callback_query) {
      await answerCallbackQuery(update.callback_query.id);
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error('[TG webhook]', e.message);
    return NextResponse.json({ ok: false, error: e.message });
  }
}

export async function GET() {
  return NextResponse.json({ ok: true, info: 'ResumeVoice Telegram webhook' });
}
