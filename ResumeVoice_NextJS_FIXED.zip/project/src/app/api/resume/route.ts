export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { chat } from '@/lib/ai';
import { buildResumePrompt } from '@/lib/prompts';
import { supabaseAdmin } from '@/lib/supabase';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { text, userId } = body as { text: string; userId?: string };

    if (!text || text.trim().length < 20) {
      return NextResponse.json({ ok: false, error: 'Слишком мало текста' }, { status: 400 });
    }

    const raw = await chat([{ role: 'user', content: buildResumePrompt(text) }]);

    let data;
    try {
      const cleaned = raw.replace(/^```[a-z]*\n?|```$/gm, '').trim();
      data = JSON.parse(cleaned);
    } catch {
      return NextResponse.json({ ok: false, error: 'Ошибка разбора ответа. Попробуйте ещё раз.' }, { status: 502 });
    }

    if (userId) {
      const db = supabaseAdmin();
      const { data: row, error } = await db
        .from('resumes')
        .insert({ user_id: userId, title: data.contacts?.role || 'Резюме', data, score: 0 })
        .select()
        .single();
      if (error) throw error;
      return NextResponse.json({ ok: true, data: row });
    }

    return NextResponse.json({ ok: true, data: { title: data.contacts?.role || 'Резюме', data } });
  } catch (e: unknown) {
    console.error('[resume/create]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка создания резюме' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get('userId');
  if (!userId) return NextResponse.json({ ok: false, error: 'userId обязателен' }, { status: 400 });
  const { data, error } = await supabaseAdmin()
    .from('resumes')
    .select('id, title, score, created_at, updated_at')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });
  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, data });
}
