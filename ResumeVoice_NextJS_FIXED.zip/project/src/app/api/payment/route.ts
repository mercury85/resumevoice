export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { createPayment, verifyWebhook, PRICES } from '@/lib/unitpay';
import { supabaseAdmin } from '@/lib/supabase';
import type { Plan } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const { plan, userId, email, returnUrl } = await req.json() as {
      plan: Plan; userId: string; email: string; returnUrl: string;
    };
    if (!PRICES[plan] || PRICES[plan] === 0) {
      return NextResponse.json({ ok: false, error: 'Тариф бесплатный' }, { status: 400 });
    }
    const result = await createPayment({ plan, userId, email, returnUrl });
    return NextResponse.json({ ok: true, data: result });
  } catch (e: unknown) {
    console.error('[payment/create]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка создания платежа' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json() as Record<string, unknown>;
    if (!verifyWebhook(body)) {
      return NextResponse.json({ error: { message: 'Неверная подпись' } });
    }

    const method = String(body.method ?? '');
    const params = (body.params ?? {}) as Record<string, string>;
    const orderId = params.orderId ?? '';

    if (method === 'pay' && orderId) {
      const [userId, plan] = orderId.split('_');
      const db = supabaseAdmin();
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      await db.from('profiles').update({ plan, plan_expires_at: expiresAt }).eq('id', userId);
      await db.from('payments').insert({
        user_id: userId, plan,
        amount: params.orderSum, unitpay_id: params.unitpayId,
        status: 'paid', paid_at: new Date().toISOString(),
      });
    }

    if (method === 'error' && orderId) {
      const [userId] = orderId.split('_');
      await supabaseAdmin().from('payments').insert({
        user_id: userId, unitpay_id: params.unitpayId,
        status: 'error', error_message: params.errorMessage,
      });
    }

    return NextResponse.json({ result: { message: 'OK' } });
  } catch (e) {
    console.error('[payment/webhook]', e);
    return NextResponse.json({ error: { message: 'Internal error' } }, { status: 500 });
  }
}
