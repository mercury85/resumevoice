export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { TV_ALL_REGIONS, TV_REGIONS_BY_FO } from '@/lib/trudvsem';

export const revalidate = 86400;

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: { regions: TV_ALL_REGIONS, byFO: TV_REGIONS_BY_FO },
  });
}
