export const dynamic = 'force-dynamic';
/**
 * GET /api/vacancies
 *
 * Параметры:
 *  text             — поисковый запрос
 *  regionCode       — код субъекта РФ (77=Москва, 78=СПб…)
 *  industry         — код отрасли
 *  social_protected — категория соц. защиты
 *  accommodation    — '1' = только с жильём
 *  uzbekistan       — '1' = организованный набор
 *  experienceFrom   — опыт от (лет)
 *  experienceTo     — опыт до (лет)
 *  salary           — зарплата от
 *  limit            — кол-во (макс 100)
 *  offset           — смещение
 */
import { NextRequest, NextResponse } from 'next/server';
import { searchTrudVsem } from '@/lib/trudvsem';


export async function GET(req: NextRequest) {
  try {
    const s = req.nextUrl.searchParams;

    const result = await searchTrudVsem({
      text:             s.get('text')             || undefined,
      regionCode:       s.get('regionCode')       || undefined,
      industry:         s.get('industry')         || undefined,
      social_protected: s.get('social_protected') || undefined,
      accommodation:    s.get('accommodation') === '1' ? true : undefined,
      uzbekistan:       s.get('uzbekistan')    === '1' ? true : undefined,
      experienceFrom:   s.has('experienceFrom') ? Number(s.get('experienceFrom')) : undefined,
      experienceTo:     s.has('experienceTo')   ? Number(s.get('experienceTo'))   : undefined,
      salary:           s.has('salary')  ? Number(s.get('salary'))  : undefined,
      limit:            s.has('limit')   ? Math.min(Number(s.get('limit')), 100) : 20,
      offset:           s.has('offset')  ? Number(s.get('offset'))  : 0,
    });

    return NextResponse.json({ ok: true, data: result });
  } catch (e: any) {
    console.error('[TV API]', e.message);
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
