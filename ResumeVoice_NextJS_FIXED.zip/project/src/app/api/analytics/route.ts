export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { chat } from '@/lib/ai';
import { matchVacancyPrompt } from '@/lib/prompts';
import type { Vacancy } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const { resumeText, vacancyText, vacancyTitle, vacancyCompany } = await req.json();

    if (!resumeText) {
      return NextResponse.json({ ok: false, error: 'Нужен текст резюме' }, { status: 400 });
    }

    const vacancy: Vacancy = {
      id: 'manual',
      name: vacancyTitle ?? 'Вакансия',
      title: vacancyTitle ?? 'Вакансия',
      company: vacancyCompany ?? '',
      employer: { name: vacancyCompany ?? '' },
      city: '',
      url: '',
      publishedAt: '',
      requirement: vacancyText ?? '',
      responsibility: '',
    };

    const raw = await chat([{ role: 'user', content: matchVacancyPrompt(resumeText, vacancy) }]);
    const cleaned = raw.replace(/^```[a-z]*\n?|```$/gm, '').trim();

    let result;
    try { result = JSON.parse(cleaned); }
    catch { return NextResponse.json({ ok: false, error: 'Ошибка разбора' }, { status: 502 }); }

    return NextResponse.json({ ok: true, data: result });
  } catch (e) {
    console.error('[analytics]', e);
    return NextResponse.json({ ok: false, error: 'Ошибка анализа' }, { status: 500 });
  }
}
