/**
 * /analytics — Аналитика
 * Полная реализация: конвертируй HTML из папки /pages в React-компоненты.
 */
export default function AnalyticsPage() {
  return (
    <main style={{padding:'80px 40px',textAlign:'center'}}>
      <h1 style={{fontSize:32,fontWeight:800,marginBottom:16}}>Аналитика</h1>
      <p style={{color:'#888',marginBottom:28}}>Страница в разработке. Используй готовый HTML из /pages.</p>
      <a href="/" style={{color:'#7c3aed',fontWeight:600}}>← На главную</a>
    </main>
  );
}
