'use client';

const cols = [
  {m:'Январь 2026',users:312,rev:'47 230 ₽',resumes:847,conv:'3.8%'},
  {m:'Декабрь 2025',users:248,rev:'38 520 ₽',resumes:624,conv:'3.2%'},
  {m:'Ноябрь 2025',users:198,rev:'28 190 ₽',resumes:511,conv:'2.9%'},
];

export default function AdminAnalytics() {
  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Аналитика</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Показатели роста сервиса</p></div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:24}}>
        {[['1 248','Пользователей всего','#7c3aed'],['+312','Новых за месяц','#16a34a'],['3 847','Резюме создано','#7c3aed'],['184 320 ₽','Выручка всего','#d97706']].map(([v,l,c])=>(
          <div key={l} style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:14,padding:18}}>
            <div style={{fontSize:12,color:'var(--text3)',marginBottom:6}}>{l}</div>
            <div style={{fontSize:26,fontWeight:800,color:c as string,letterSpacing:'-1px'}}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
        <div style={{fontSize:15,fontWeight:700,marginBottom:16,color:'var(--text)'}}>По месяцам</div>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr>{['Месяц','Новых пользователей','Выручка','Резюме','Конверсия'].map(h=><th key={h} style={{padding:'10px 14px',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--text3)',borderBottom:'2px solid var(--border)',textAlign:'left'}}>{h}</th>)}</tr></thead>
          <tbody>{cols.map((c,i)=>(
            <tr key={i}><td style={{padding:'12px 14px',fontSize:14,fontWeight:500,color:'var(--text)',borderBottom:'1px solid var(--border)'}}>{c.m}</td>
              <td style={{padding:'12px 14px',fontSize:14,color:'#7c3aed',fontWeight:700,borderBottom:'1px solid var(--border)'}}>{c.users}</td>
              <td style={{padding:'12px 14px',fontSize:14,color:'#16a34a',fontWeight:700,borderBottom:'1px solid var(--border)'}}>{c.rev}</td>
              <td style={{padding:'12px 14px',fontSize:14,color:'var(--text2)',borderBottom:'1px solid var(--border)'}}>{c.resumes}</td>
              <td style={{padding:'12px 14px',fontSize:14,color:'var(--text2)',borderBottom:'1px solid var(--border)'}}>{c.conv}</td>
            </tr>))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
