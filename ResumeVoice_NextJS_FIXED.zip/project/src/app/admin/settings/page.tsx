'use client';
import { useState } from 'react';

type SettingSection = { title: string; desc?: string; fields: SettingField[]; };
type SettingField = { label: string; desc?: string; type: 'text' | 'password' | 'toggle' | 'number'; value: string | boolean; key: string; };

export default function AdminSettings() {
  const [vals, setVals] = useState<Record<string,string|boolean>>({
    siteName:'ResumeVoice', supportEmail:'support@resumevoice.ru',
    tgSupport:'@resumevoice_support', maintenance:false, registrationOpen:true,
    adminPass:'', jwtSecret:'',
    aiClientId:'••••••••', aiClientSecret:'••••••••', aiScope:'GIGACHAT_API_PERS',
    supabaseUrl:'https://xxx.supabase.co', supabaseAnon:'••••••••', supabaseService:'••••••••',
    hhClientId:'', hhClientSecret:'',
    unitpayPublic:'', unitpaySecret:'', unitpayProject:'', unitpayTest:true,
    tgBotToken:'••••••••', tgBotUsername:'@ResumeVoiceBot',
    freePlanResumes:'1', freePlanLetters:'1', freePlanVacancies:'0',
    proPlanResumes:'Безлимит', proPlanLetters:'30', proPlanVacancies:'100', proPrice:'699',
    premPlanResumes:'Безлимит', premPlanLetters:'Безлимит', premPlanVacancies:'Безлимит', premPrice:'1490',
  });

  const set = (k: string, v: string|boolean) => setVals(p => ({...p,[k]:v}));
  const save = (k: string) => alert(`Сохранено: ${k}`);

  const Row = ({ label, desc, fieldKey, type }: { label: string; desc?: string; fieldKey: string; type: SettingField['type'] }) => (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr auto', gap:12, alignItems:'center', padding:'14px 0', borderBottom:'1px solid var(--border)' }}>
      <div>
        <div style={{ fontSize:14, fontWeight:600, color:'var(--text)' }}>{label}</div>
        {desc && <div style={{ fontSize:12, color:'var(--text3)', marginTop:2 }}>{desc}</div>}
      </div>
      {type === 'toggle' ? (
        <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer' }}>
          <div style={{ position:'relative', width:40, height:22 }}>
            <input type="checkbox" checked={vals[fieldKey] as boolean} onChange={e => set(fieldKey, e.target.checked)} style={{ opacity:0, width:0, height:0, position:'absolute' }} />
            <div style={{ position:'absolute', inset:0, background:vals[fieldKey]?'#7c3aed':'var(--border2)', borderRadius:11, cursor:'pointer', transition:'.3s' }}>
              <div style={{ position:'absolute', width:16, height:16, left: vals[fieldKey]?21:3, top:3, background:'white', borderRadius:'50%', transition:'.3s', boxShadow:'0 1px 3px rgba(0,0,0,.2)' }} />
            </div>
          </div>
          <span style={{ fontSize:13, color:'var(--text3)' }}>{vals[fieldKey]?'Включено':'Выключено'}</span>
        </label>
      ) : (
        <input type={type} value={vals[fieldKey] as string} onChange={e => set(fieldKey, e.target.value)}
          style={{ width:'100%', padding:'9px 12px', border:'1.5px solid var(--border)', borderRadius:8, fontSize:13, color:'var(--text)', background:'var(--bg)', outline:'none', fontFamily:'inherit' }} />
      )}
      {type !== 'toggle' && <button onClick={() => save(fieldKey)} style={{ padding:'8px 16px', borderRadius:8, background:'#7c3aed', color:'white', border:'none', cursor:'pointer', fontSize:13, fontWeight:600, fontFamily:'inherit', whiteSpace:'nowrap' }}>Сохранить</button>}
      {type === 'toggle' && <div />}
    </div>
  );

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:24, marginBottom:16 }}>
      <div style={{ fontSize:15, fontWeight:700, marginBottom:16, color:'var(--text)' }}>{title}</div>
      {children}
    </div>
  );

  return (
    <div>
      <h1 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.5px', color:'var(--text)', marginBottom:24 }}>Настройки</h1>

      <Section title="Сайт">
        <Row label="Название сайта" fieldKey="siteName" type="text" />
        <Row label="Email поддержки" fieldKey="supportEmail" type="text" />
        <Row label="Telegram поддержки" fieldKey="tgSupport" type="text" />
        <Row label="Режим обслуживания" desc="Показывает заглушку всем посетителям" fieldKey="maintenance" type="toggle" />
        <Row label="Регистрация открыта" fieldKey="registrationOpen" type="toggle" />
      </Section>

      <Section title="AI-провайдер (обработка текста и голоса)">
        <Row label="Client ID" fieldKey="aiClientId" type="password" />
        <Row label="Client Secret" fieldKey="aiClientSecret" type="password" />
        <Row label="Scope" fieldKey="aiScope" type="text" />
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 14px', background:'#f0fdf4', borderRadius:8, marginTop:12 }}>
          <div style={{ width:8, height:8, borderRadius:'50%', background:'#16a34a' }} />
          <span style={{ fontSize:13, color:'#16a34a', fontWeight:600 }}>Подключено, работает</span>
          <button style={{ marginLeft:'auto', padding:'5px 12px', borderRadius:6, fontSize:12, border:'1.5px solid var(--border)', background:'var(--bg)', color:'var(--text2)', cursor:'pointer', fontFamily:'inherit' }}>Проверить</button>
        </div>
      </Section>

      <Section title="Supabase (база данных)">
        <Row label="Project URL" fieldKey="supabaseUrl" type="text" />
        <Row label="Anon Key" fieldKey="supabaseAnon" type="password" />
        <Row label="Service Role Key" fieldKey="supabaseService" type="password" />
      </Section>

      <Section title="API вакансий (Работа в России)">
        <Row label="Client ID" fieldKey="hhClientId" type="text" />
        <Row label="Client Secret" fieldKey="hhClientSecret" type="password" />
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 14px', background:'#fffbeb', borderRadius:8, marginTop:12 }}>
          <div style={{ width:8, height:8, borderRadius:'50%', background:'#d97706' }} />
          <span style={{ fontSize:13, color:'#d97706', fontWeight:600 }}>Требуется настройка OAuth</span>
          <button style={{ marginLeft:'auto', padding:'5px 12px', borderRadius:6, fontSize:12, background:'#7c3aed', color:'white', border:'none', cursor:'pointer', fontFamily:'inherit' }}>Настроить</button>
        </div>
      </Section>

      <Section title="UnitPay (платежи)">
        <Row label="Public Key" fieldKey="unitpayPublic" type="text" />
        <Row label="Secret Key" fieldKey="unitpaySecret" type="password" />
        <Row label="Project ID" fieldKey="unitpayProject" type="number" />
        <Row label="Тестовый режим" desc="Отключите перед запуском в продакшн" fieldKey="unitpayTest" type="toggle" />
      </Section>

      <Section title="Telegram Bot">
        <Row label="Bot Token" fieldKey="tgBotToken" type="password" />
        <Row label="Username бота" fieldKey="tgBotUsername" type="text" />
      </Section>

      <Section title="Тарифы — Бесплатный">
        <Row label="Количество резюме" fieldKey="freePlanResumes" type="number" />
        <Row label="Сопроводительных писем" fieldKey="freePlanLetters" type="number" />
        <Row label="Вакансий в день (0 = нет доступа)" fieldKey="freePlanVacancies" type="number" />
      </Section>

      <Section title="Тарифы — Про">
        <Row label="Цена (руб/мес)" fieldKey="proPrice" type="number" />
        <Row label="Вакансий в день" fieldKey="proPlanVacancies" type="number" />
        <Row label="Сопроводительных писем" fieldKey="proPlanLetters" type="number" />
      </Section>

      <Section title="Тарифы — Премиум">
        <Row label="Цена (руб/мес)" fieldKey="premPrice" type="number" />
        <Row label="Вакансий в день" fieldKey="premPlanVacancies" type="text" />
        <Row label="Сопроводительных писем" fieldKey="premPlanLetters" type="text" />
      </Section>

      <Section title="Безопасность">
        <Row label="Пароль администратора" fieldKey="adminPass" type="password" />
        <Row label="JWT Secret" desc="Для подписи токенов авторизации" fieldKey="jwtSecret" type="password" />
      </Section>
    </div>
  );
}
