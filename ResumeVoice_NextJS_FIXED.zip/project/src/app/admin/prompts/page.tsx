'use client';
import { useState } from 'react';

const PROMPTS = [
  { id:1, name:'Создание резюме', key:'resume_create', desc:'Превращает голосовой транскрипт в структурированное JSON-резюме', tokens:800, active:true },
  { id:2, name:'Аудит резюме', key:'resume_audit', desc:'Анализирует резюме по 15 критериям и возвращает оценку и правки', tokens:600, active:true },
  { id:3, name:'Сопроводительное письмо', key:'cover_letter', desc:'Создаёт персональное письмо под вакансию', tokens:500, active:true },
  { id:4, name:'Совпадение с вакансией', key:'vacancy_match', desc:'Сравнивает резюме с вакансией и возвращает процент совпадения', tokens:700, active:true },
  { id:5, name:'Вопросы для собеседования', key:'interview_questions', desc:'Генерирует 5-10 HR-вопросов под конкретную должность', tokens:400, active:true },
  { id:6, name:'Карьерный совет', key:'career_advice', desc:'Отвечает на вопросы пользователя о поиске работы', tokens:600, active:true },
  { id:7, name:'AI Ассистент (системный)', key:'assistant_system', desc:'Системный промпт для чат-помощника сервиса', tokens:300, active:true },
];

export default function AdminPrompts() {
  const [editing, setEditing] = useState<number|null>(null);
  const [text, setText] = useState('');

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Промпты AI</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Управление системными промптами для всех сценариев</p></div>
        <button style={{padding:'8px 18px',borderRadius:8,fontSize:13,fontWeight:600,background:'#7c3aed',color:'white',border:'none',cursor:'pointer',fontFamily:'inherit'}}>+ Новый промпт</button>
      </div>

      {editing === null ? (
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {PROMPTS.map(p=>(
            <div key={p.id} style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:14,padding:20,display:'flex',alignItems:'center',gap:16}}>
              <div style={{flex:1}}>
                <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
                  <div style={{fontSize:15,fontWeight:700,color:'var(--text)'}}>{p.name}</div>
                  <code style={{fontSize:12,background:'var(--bg2)',color:'#7c3aed',padding:'2px 8px',borderRadius:6,border:'1px solid var(--border)'}}>{p.key}</code>
                  {p.active && <span style={{fontSize:11,fontWeight:600,background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0',padding:'2px 8px',borderRadius:100}}>Активен</span>}
                </div>
                <div style={{fontSize:13,color:'var(--text3)'}}>{p.desc}</div>
                <div style={{fontSize:12,color:'var(--text4)',marginTop:4}}>~{p.tokens} токенов</div>
              </div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>{setEditing(p.id);setText(`# Промпт: ${p.name}\n\nТы — эксперт по составлению резюме для российского рынка труда...\n\n## Задача\n...\n\n## Формат ответа\nВерни ТОЛЬКО валидный JSON без markdown-блоков.`);}} style={{padding:'7px 16px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--purple-light)',color:'#7c3aed',border:'1px solid var(--purple-mid)',cursor:'pointer',fontFamily:'inherit'}}>Редактировать</button>
                <button style={{padding:'7px 16px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}}>Тест</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16}}>
            <div style={{fontSize:16,fontWeight:700,color:'var(--text)'}}>Редактирование промпта #{editing}</div>
            <button onClick={()=>setEditing(null)} style={{padding:'7px 16px',borderRadius:8,fontSize:12,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}}>Назад</button>
          </div>
          <textarea value={text} onChange={e=>setText(e.target.value)} rows={20}
            style={{width:'100%',padding:'14px',border:'1.5px solid var(--border)',borderRadius:12,fontSize:13,color:'var(--text)',background:'var(--bg2)',outline:'none',fontFamily:'monospace',lineHeight:1.7,resize:'vertical'}} />
          <div style={{display:'flex',gap:10,marginTop:16}}>
            <button onClick={()=>setEditing(null)} style={{padding:'10px 24px',borderRadius:8,fontSize:13,fontWeight:600,background:'#7c3aed',color:'white',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Сохранить</button>
            <button style={{padding:'10px 24px',borderRadius:8,fontSize:13,fontWeight:500,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}}>Тест на примере</button>
          </div>
        </div>
      )}
    </div>
  );
}
