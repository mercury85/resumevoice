'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';

const adminLinks = [
  { href:'/admin',               label:'Дашборд',      icon:'grid' },
  { href:'/admin/users',         label:'Пользователи', icon:'users' },
  { href:'/admin/payments',      label:'Платежи',      icon:'credit' },
  { href:'/admin/subscriptions', label:'Подписки',     icon:'dollar' },
  { href:'/admin/vacancies',     label:'Вакансии',     icon:'briefcase' },
  { href:'/admin/analytics',     label:'Аналитика',    icon:'chart' },
  { href:'/admin/prompts',       label:'Промпты',      icon:'brain' },
  { href:'/admin/logs',          label:'Логи',         icon:'activity' },
  { href:'/admin/settings',      label:'Настройки',    icon:'settings' },
];

function Icon({ n }: { n: string }) {
  const p = { width:16, height:16, viewBox:'0 0 24 24', stroke:'currentColor', fill:'none', strokeWidth:1.8, strokeLinecap:'round' as const, strokeLinejoin:'round' as const };
  switch(n){
    case 'grid':      return <svg {...p}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
    case 'users':     return <svg {...p}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
    case 'credit':    return <svg {...p}><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>;
    case 'dollar':    return <svg {...p}><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>;
    case 'briefcase': return <svg {...p}><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>;
    case 'chart':     return <svg {...p}><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
    case 'brain':     return <svg {...p}><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/></svg>;
    case 'activity':  return <svg {...p}><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>;
    case 'settings':  return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>;
    default:          return <svg {...p}><circle cx="12" cy="12" r="10"/></svg>;
  }
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router   = useRouter();
  const [checked, setChecked] = useState(false);

  // Проверяем сессию через API (cookie проверяется на сервере)
  useEffect(() => {
    if (pathname === '/admin/login') { setChecked(true); return; }
    fetch('/api/admin/session')
      .then(r => {
        if (!r.ok) router.replace(`/admin/login?from=${encodeURIComponent(pathname)}`);
        else setChecked(true);
      })
      .catch(() => router.replace('/admin/login'));
  }, [pathname, router]);

  const doLogout = useCallback(async () => {
    await fetch('/api/admin/auth', { method: 'DELETE' });
    router.replace('/admin/login');
  }, [router]);

  // Страница логина — рендерим без layout
  if (pathname === '/admin/login') return <>{children}</>;

  // Пока не проверили сессию — пустой экран (middleware уже перенаправил если нет cookie)
  if (!checked) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh', background:'#0f0e17' }}>
      <div style={{ width:36, height:36, border:'3px solid #7c3aed', borderTopColor:'transparent', borderRadius:'50%', animation:'spin 0.7s linear infinite' }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  return (
    <div style={{ display:'grid', gridTemplateColumns:'220px 1fr', minHeight:'100vh' }}>
      <aside style={{ background:'#1e1c2a', display:'flex', flexDirection:'column' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'18px 18px 14px', borderBottom:'1px solid rgba(255,255,255,.08)' }}>
          <img src="/logo.png" alt="RV" style={{ height:30, objectFit:'contain' }} />
          <span style={{ fontSize:14, fontWeight:800, color:'white' }}>Admin<span style={{color:'#a78bfa'}}>Panel</span></span>
        </div>
        <nav style={{ flex:1, padding:'12px 8px', display:'flex', flexDirection:'column', gap:2 }}>
          {adminLinks.map(l => {
            const active = pathname === l.href;
            return (
              <Link key={l.href} href={l.href} style={{ display:'flex', alignItems:'center', gap:9, padding:'9px 12px', borderRadius:10, fontSize:14, textDecoration:'none', transition:'all .15s', color: active ? '#c4b5fd' : 'rgba(255,255,255,.5)', background: active ? 'rgba(124,58,237,.25)' : 'transparent', fontWeight: active ? 600 : 400 }}>
                <Icon n={l.icon} />{l.label}
              </Link>
            );
          })}
        </nav>
        <div style={{ padding:'12px 8px', borderTop:'1px solid rgba(255,255,255,.08)' }}>
          <button onClick={doLogout} style={{ display:'flex', alignItems:'center', gap:9, padding:'9px 12px', borderRadius:10, fontSize:14, color:'rgba(255,255,255,.4)', background:'none', border:'none', cursor:'pointer', fontFamily:'inherit', width:'100%' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            Выйти
          </button>
        </div>
      </aside>
      <main style={{ background:'var(--bg2)', padding:'28px 32px', overflowY:'auto' }}>
        {children}
      </main>
    </div>
  );
}
