'use client';
import { useState } from 'react';

const logs = [
  { time:'14.01 09:23:14', level:'info', msg:'Платёж UP-10048 успешно обработан: 1490 руб', user:'ivan@mail.ru' },
  { time:'14.01 09:18:02', level:'info', msg:'Новая регистрация пользователя', user:'new@example.com' },
  { time:'14.01 09:15:41', level:'info', msg:'Резюме создано: Менеджер по продажам', user:'anna@ya.ru' },
  { time:'13.01 22:14:33', level:'error', msg:'Ошибка платежа UP-10046: Карта отклонена', user:'sergey@gmail.com' },
  { time:'13.01 21:05:17', level:'warn', msg:'SaluteSpeech timeout, повторная попытка', user:'maria@mail.ru' },
  { time:'13.01 20:44:22', level:'info', msg:'API: загружено 127 вакансий для профиля', user:'oleg@ya.ru' },
  { time:'13.01 18:30:11', level:'info', msg:'Возврат инициирован: UP-10045', user:'maria@mail.ru' },
  { time:'13.01 15:22:05', level:'error', msg:'AI: превышен лимит запросов, ожидание 60s', user:'system' },
];

const lvlStyle: Record<string,React.CSSProperties> = {
  info:  {background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'},
  warn:  {background:'#fffbeb',color:'#d97706',border:'1px solid #fde68a'},
  error: {background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca'},
};

export default function AdminLogs() {
  const [lvl, setLvl] = useState('all');
  const filtered = lvl === 'all' ? logs : logs.filter(l => l.level === lvl);

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Системные логи</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Последние события в системе</p></div>
        <div style={{display:'flex',gap:8}}>
          {['all','info','warn','error'].map(l=>(
            <button key={l} onClick={()=>setLvl(l)} style={{padding:'7px 14px',borderRadius:8,fontSize:13,fontWeight:500,border:`1.5px solid ${lvl===l?'#7c3aed':'var(--border)'}`,background:lvl===l?'var(--purple-light)':'var(--bg)',color:lvl===l?'#7c3aed':'var(--text3)',cursor:'pointer',fontFamily:'inherit',textTransform:'capitalize'}}>
              {l==='all'?'Все':l}
            </button>
          ))}
        </div>
      </div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
        <div style={{display:'flex',flexDirection:'column',gap:2}}>
          {filtered.map((l,i)=>(
            <div key={i} style={{display:'grid',gridTemplateColumns:'140px 60px 1fr 140px',gap:12,alignItems:'center',padding:'10px 0',borderBottom:'1px solid var(--border)'}}>
              <div style={{fontSize:12,color:'var(--text4)',fontFamily:'monospace'}}>{l.time}</div>
              <span style={{display:'inline-flex',padding:'2px 7px',borderRadius:5,fontSize:11,fontWeight:700,...lvlStyle[l.level]}}>{l.level.toUpperCase()}</span>
              <div style={{fontSize:13,color:'var(--text)'}}>{l.msg}</div>
              <div style={{fontSize:12,color:'var(--text3)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{l.user}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
