'use client';
import { useState, useCallback, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function AdminLoginForm() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const [login,   setLogin]   = useState('');
  const [pass,    setPass]    = useState('');
  const [err,     setErr]     = useState('');
  const [loading, setLoading] = useState(false);
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    fetch('/api/admin/session').then(r => {
      if (r.ok) router.replace(searchParams.get('from') ?? '/admin');
    }).catch(() => {});
  }, [router, searchParams]);

  const doLogin = useCallback(async () => {
    if (blocked || loading) return;
    if (!login.trim() || !pass) { setErr('Введите логин и пароль'); return; }
    setLoading(true); setErr('');
    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login, pass }),
      });
      const j = await res.json();
      if (j.ok) { router.replace(searchParams.get('from') ?? '/admin'); return; }
      setErr(j.error ?? 'Ошибка входа');
      if (res.status === 429) setBlocked(true);
    } catch {
      setErr('Ошибка сети. Попробуйте ещё раз.');
    } finally {
      setLoading(false); setPass('');
    }
  }, [login, pass, loading, blocked, router, searchParams]);

  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh', background:'#0f0e17' }}>
      <div style={{ background:'#1a1828', border:'1.5px solid #2e2b40', borderRadius:20, padding:40, width:'100%', maxWidth:380, boxShadow:'0 8px 40px rgba(0,0,0,.4)' }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ width:56, height:56, borderRadius:16, background:'linear-gradient(135deg,#8b5cf6,#7c3aed)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
            <svg width="26" height="26" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </div>
          <div style={{ fontSize:20, fontWeight:800, color:'#e8e6f5' }}>Resume<span style={{color:'#a78bfa'}}>Voice</span></div>
          <div style={{ fontSize:13, color:'rgba(255,255,255,.4)', marginTop:4 }}>Административная панель</div>
        </div>

        <div style={{ marginBottom:16 }}>
          <label style={{ display:'block', fontSize:12, fontWeight:600, color:'rgba(255,255,255,.5)', marginBottom:7, textTransform:'uppercase', letterSpacing:'.06em' }}>Логин</label>
          <input value={login} onChange={e => setLogin(e.target.value)} autoComplete="username"
            disabled={loading || blocked}
            style={{ width:'100%', padding:'11px 14px', border:'1.5px solid #2e2b40', borderRadius:8, fontSize:15, color:'#e8e6f5', background:'#0f0e17', outline:'none', fontFamily:'inherit', boxSizing:'border-box' }} />
        </div>

        <div style={{ marginBottom:24 }}>
          <label style={{ display:'block', fontSize:12, fontWeight:600, color:'rgba(255,255,255,.5)', marginBottom:7, textTransform:'uppercase', letterSpacing:'.06em' }}>Пароль</label>
          <input type="password" value={pass} onChange={e => setPass(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && doLogin()}
            autoComplete="current-password" disabled={loading || blocked}
            style={{ width:'100%', padding:'11px 14px', border:'1.5px solid #2e2b40', borderRadius:8, fontSize:15, color:'#e8e6f5', background:'#0f0e17', outline:'none', fontFamily:'inherit', boxSizing:'border-box' }} />
        </div>

        {err && (
          <div style={{ fontSize:13, color:'#f87171', textAlign:'center', marginBottom:16, padding:'10px 14px', background:'rgba(220,38,38,.1)', borderRadius:8, border:'1px solid rgba(220,38,38,.25)', lineHeight:1.5 }}>
            {err}
          </div>
        )}

        <button onClick={doLogin} disabled={loading || blocked}
          style={{ width:'100%', padding:13, borderRadius:10, fontSize:15, fontWeight:600, border:'none', background:(loading||blocked)?'#4c1d95':'linear-gradient(135deg,#8b5cf6,#7c3aed)', color:'white', cursor:(loading||blocked)?'not-allowed':'pointer', fontFamily:'inherit', opacity:(loading||blocked)?.7:1 }}>
          {loading ? 'Проверка...' : blocked ? 'Заблокировано' : 'Войти'}
        </button>
      </div>
    </div>
  );
}
