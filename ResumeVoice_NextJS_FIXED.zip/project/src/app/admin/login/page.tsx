export const dynamic = 'force-dynamic';
import { Suspense } from 'react';
import AdminLoginForm from './LoginForm';

export default function AdminLoginPage() {
  return (
    <Suspense fallback={null}>
      <AdminLoginForm />
    </Suspense>
  );
}
