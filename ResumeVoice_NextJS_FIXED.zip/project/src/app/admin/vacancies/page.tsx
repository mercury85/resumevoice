'use client';
import { useState } from 'react';

export default function AdminVacancies() {
  const [text, setText] = useState('');
  const [city, setCity] = useState('1');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/vacancies?text=${encodeURIComponent(text)}&area=${city}&perPage=10`);
      const d = await r.json();
      setResults(d.ok ? d.data.items : []);
    } catch { setResults([]); }
    setLoading(false);
  };

  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Вакансии</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Вакансии из базы порталов занятости</p></div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24,marginBottom:16}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 180px auto',gap:12}}>
          <input value={text} onChange={e=>setText(e.target.value)} placeholder="Название вакансии..."
            style={{padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit'}}
            onFocus={e=>e.target.style.borderColor='#7c3aed'} onBlur={e=>e.target.style.borderColor='var(--border)'}/>
          <select value={city} onChange={e=>setCity(e.target.value)}
            style={{padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit',cursor:'pointer'}}>
            {[['1','Москва'],['2','Санкт-Петербург'],['66','Екатеринбург'],['4','Новосибирск'],['88','Казань']].map(([v,l])=><option key={v} value={v}>{l}</option>)}
          </select>
          <button onClick={search} disabled={loading} style={{padding:'10px 24px',borderRadius:8,fontSize:14,fontWeight:600,background:'#7c3aed',color:'white',border:'none',cursor:'pointer',fontFamily:'inherit',opacity:loading?.7:1}}>
            {loading ? 'Загрузка...' : 'Найти'}
          </button>
        </div>
      </div>
      {results.length > 0 && (
        <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
          <div style={{fontSize:14,fontWeight:600,marginBottom:14,color:'var(--text)'}}>Найдено {results.length} вакансий</div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {results.map((v:any,i:number)=>(
              <div key={i} style={{padding:'14px',border:'1.5px solid var(--border)',borderRadius:10,background:'var(--bg2)'}}>
                <div style={{fontSize:14,fontWeight:600,color:'var(--text)',marginBottom:4}}>{v.name}</div>
                <div style={{display:'flex',gap:12,fontSize:13,color:'var(--text3)'}}>
                  <span>{v.employer?.name}</span>
                  <span>{v.area?.name}</span>
                  <span>{v.salary ? `${v.salary.from||''} - ${v.salary.to||''} ${v.salary.currency}` : 'з/п не указана'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
