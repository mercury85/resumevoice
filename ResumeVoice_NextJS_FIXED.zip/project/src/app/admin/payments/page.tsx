'use client';
import { useState } from 'react';

const payments = [
  { id:'UP-10048', user:'ivan@mail.ru', plan:'Премиум', amount:'1490 ₽', method:'Карта', status:'Успешно', date:'14.01.2026 09:23' },
  { id:'UP-10047', user:'anna@ya.ru', plan:'Про', amount:'699 ₽', method:'СБП', status:'Успешно', date:'14.01.2026 08:51' },
  { id:'UP-10046', user:'sergey@gmail.com', plan:'Про', amount:'699 ₽', method:'Карта', status:'Отклонено', date:'13.01.2026 22:14' },
  { id:'UP-10045', user:'maria@mail.ru', plan:'Премиум', amount:'1490 ₽', method:'Карта', status:'Возврат', date:'13.01.2026 18:30' },
  { id:'UP-10044', user:'oleg@ya.ru', plan:'Про', amount:'699 ₽', method:'СБП', status:'Успешно', date:'12.01.2026 15:42' },
];
const stCl: Record<string,React.CSSProperties> = {
  'Успешно': {background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'},
  'Отклонено': {background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca'},
  'Возврат': {background:'#fffbeb',color:'#d97706',border:'1px solid #fde68a'},
};
export default function AdminPayments() {
  const [filter, setFilter] = useState('Все');
  const filtered = filter === 'Все' ? payments : payments.filter(p => p.status === filter);
  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Платежи</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>История транзакций через UnitPay</p></div>
        <div style={{display:'flex',gap:10}}>
          <select value={filter} onChange={e=>setFilter(e.target.value)} style={{padding:'8px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:13,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit',cursor:'pointer'}}>
            {['Все','Успешно','Отклонено','Возврат'].map(s=><option key={s}>{s}</option>)}
          </select>
          <button style={{padding:'8px 18px',borderRadius:8,fontSize:13,fontWeight:600,background:'#7c3aed',color:'white',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Экспорт CSV</button>
        </div>
      </div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr>{['Транзакция','Пользователь','Тариф','Сумма','Метод','Статус','Дата'].map(h=><th key={h} style={{padding:'10px 14px',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--text3)',borderBottom:'2px solid var(--border)',textAlign:'left'}}>{h}</th>)}</tr></thead>
          <tbody>{filtered.map((p,i)=>(
            <tr key={i}>
              {[p.id,p.user,p.plan,p.amount,p.method].map((v,j)=><td key={j} style={{padding:'12px 14px',fontSize:14,color: j===0?'var(--text3)':j===3?'var(--text)':'var(--text2)',fontWeight:j===3?600:400,borderBottom:'1px solid var(--border)'}}>{v}</td>)}
              <td style={{padding:'12px 14px',borderBottom:'1px solid var(--border)'}}><span style={{display:'inline-flex',padding:'3px 9px',borderRadius:100,fontSize:12,fontWeight:600,...stCl[p.status]}}>{p.status}</span></td>
              <td style={{padding:'12px 14px',fontSize:13,color:'var(--text3)',borderBottom:'1px solid var(--border)'}}>{p.date}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
