'use client';

const subs = [
  { user:'ivan@mail.ru', plan:'Премиум', start:'01.01.2026', end:'01.02.2026', status:'active', amount:'1490 ₽' },
  { user:'anna@ya.ru', plan:'Про', start:'05.12.2025', end:'05.01.2026', status:'expired', amount:'699 ₽' },
  { user:'alex@gmail.com', plan:'Бесплатный', start:'10.12.2025', end:'—', status:'free', amount:'0 ₽' },
  { user:'oleg@ya.ru', plan:'Про', start:'12.01.2026', end:'12.02.2026', status:'active', amount:'699 ₽' },
];
const stS: Record<string,React.CSSProperties> = {
  active:{background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'},
  expired:{background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca'},
  free:{background:'var(--purple-light)',color:'#7c3aed',border:'1px solid var(--purple-mid)'},
};
export default function AdminSubscriptions() {
  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Подписки</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Активные и истекшие подписки</p></div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr>{['Пользователь','Тариф','Начало','Окончание','Статус','Сумма'].map(h=><th key={h} style={{padding:'10px 14px',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--text3)',borderBottom:'2px solid var(--border)',textAlign:'left'}}>{h}</th>)}</tr></thead>
          <tbody>{subs.map((s,i)=>(<tr key={i}>{[s.user,s.plan,s.start,s.end].map((v,j)=><td key={j} style={{padding:'12px 14px',fontSize:14,color:j===0?'var(--text)':'var(--text2)',borderBottom:'1px solid var(--border)'}}>{v}</td>)}<td style={{padding:'12px 14px',borderBottom:'1px solid var(--border)'}}><span style={{display:'inline-flex',padding:'3px 9px',borderRadius:100,fontSize:12,fontWeight:600,...stS[s.status]}}>{s.status==='active'?'Активна':s.status==='expired'?'Истекла':'Бесплатный'}</span></td><td style={{padding:'12px 14px',fontSize:14,fontWeight:600,color:'var(--text)',borderBottom:'1px solid var(--border)'}}>{s.amount}</td></tr>))}</tbody>
        </table>
      </div>
    </div>
  );
}
