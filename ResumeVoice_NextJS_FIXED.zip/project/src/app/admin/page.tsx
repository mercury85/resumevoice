'use client';
import { useState } from 'react';

const stats = [
  { label:'Пользователи', value:'1 248', delta:'+87 за месяц', color:'#7c3aed' },
  { label:'Выручка', value:'184 320 ₽', delta:'+23% к прошлому', color:'#16a34a' },
  { label:'Резюме создано', value:'3 847', delta:'+342 за месяц', color:'#7c3aed' },
  { label:'Активные платники', value:'312', delta:'+41 за месяц', color:'#d97706' },
];

const recentPayments = [
  { id:'#1048', user:'ivan@mail.ru', plan:'Премиум', amount:'1490 ₽', status:'Оплачено', date:'14.01.2026' },
  { id:'#1047', user:'anna@ya.ru', plan:'Про', amount:'699 ₽', status:'Оплачено', date:'14.01.2026' },
  { id:'#1046', user:'alexey@gmail.com', plan:'Про', amount:'699 ₽', status:'Ожидает', date:'13.01.2026' },
  { id:'#1045', user:'maria@mail.ru', plan:'Премиум', amount:'1490 ₽', status:'Ошибка', date:'13.01.2026' },
  { id:'#1044', user:'sergey@ya.ru', plan:'Про', amount:'699 ₽', status:'Оплачено', date:'12.01.2026' },
];

const statusStyle: Record<string, React.CSSProperties> = {
  'Оплачено': { background:'#f0fdf4', color:'#16a34a', border:'1px solid #bbf7d0' },
  'Ожидает':  { background:'#fffbeb', color:'#d97706', border:'1px solid #fde68a' },
  'Ошибка':   { background:'#fef2f2', color:'#dc2626', border:'1px solid #fecaca' },
};

export default function AdminDashboard() {
  const [period, setPeriod] = useState('30 дней');

  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:24 }}>
        <div>
          <h1 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.5px', color:'var(--text)' }}>Дашборд</h1>
          <p style={{ fontSize:13, color:'var(--text3)', marginTop:2 }}>Обзор за последние {period}</p>
        </div>
        <select value={period} onChange={e => setPeriod(e.target.value)}
          style={{ padding:'8px 14px', border:'1.5px solid var(--border)', borderRadius:8, fontSize:13, color:'var(--text)', background:'var(--bg)', outline:'none', fontFamily:'inherit', cursor:'pointer' }}>
          {['7 дней','30 дней','90 дней','Год'].map(p => <option key={p}>{p}</option>)}
        </select>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:24 }}>
        {stats.map((s,i) => (
          <div key={i} style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:14, padding:18 }}>
            <div style={{ fontSize:12, color:'var(--text3)', marginBottom:6 }}>{s.label}</div>
            <div style={{ fontSize:26, fontWeight:800, letterSpacing:'-1px', color:s.color }}>{s.value}</div>
            <div style={{ fontSize:12, color:'#16a34a', marginTop:3 }}>{s.delta}</div>
          </div>
        ))}
      </div>

      {/* Plans distribution */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24 }}>
        <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:24 }}>
          <div style={{ fontSize:15, fontWeight:700, marginBottom:16, color:'var(--text)' }}>Распределение по тарифам</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
            {[['Бесплатный','936','75%','var(--purple-light)','#7c3aed'],['Про','248','20%','#f0fdf4','#16a34a'],['Премиум','64','5%','#fffbeb','#d97706']].map(([n,v,p,bg,c]) => (
              <div key={n} style={{ textAlign:'center', padding:14, background: bg as string, borderRadius:10 }}>
                <div style={{ fontSize:11, fontWeight:700, textTransform:'uppercase' as const, letterSpacing:'.07em', color: c as string, marginBottom:4 }}>{n}</div>
                <div style={{ fontSize:22, fontWeight:800, color: c as string, letterSpacing:'-1px' }}>{v}</div>
                <div style={{ fontSize:12, color:'var(--text3)', marginTop:2 }}>{p}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:24 }}>
          <div style={{ fontSize:15, fontWeight:700, marginBottom:16, color:'var(--text)' }}>Последние действия</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {['Новая регистрация: ivan@mail.ru','Платёж 1490 ₽ от anna@ya.ru','Создано 47 резюме сегодня','Ошибка платежа у alexey@gmail.com','Новое резюме: Менеджер по продажам'].map((l,i) => (
              <div key={i} style={{ fontSize:13, color:'var(--text2)', padding:'8px 0', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:6, height:6, borderRadius:'50%', background:'#7c3aed', flexShrink:0 }} />
                {l}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent payments */}
      <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:24 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
          <div style={{ fontSize:15, fontWeight:700, color:'var(--text)' }}>Последние платежи</div>
          <a href="/admin/payments" style={{ fontSize:13, color:'#7c3aed', textDecoration:'none' }}>Все платежи</a>
        </div>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr>
              {['#','Пользователь','Тариф','Сумма','Статус','Дата'].map(h => (
                <th key={h} style={{ padding:'10px 14px', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.07em', color:'var(--text3)', borderBottom:'2px solid var(--border)', textAlign:'left' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recentPayments.map((p,i) => (
              <tr key={i}>
                <td style={{ padding:'12px 14px', fontSize:14, color:'var(--text3)', borderBottom:'1px solid var(--border)' }}>{p.id}</td>
                <td style={{ padding:'12px 14px', fontSize:14, color:'var(--text)', borderBottom:'1px solid var(--border)' }}>{p.user}</td>
                <td style={{ padding:'12px 14px', fontSize:14, color:'var(--text2)', borderBottom:'1px solid var(--border)' }}>{p.plan}</td>
                <td style={{ padding:'12px 14px', fontSize:14, fontWeight:600, color:'var(--text)', borderBottom:'1px solid var(--border)' }}>{p.amount}</td>
                <td style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)' }}>
                  <span style={{ display:'inline-flex', alignItems:'center', padding:'3px 9px', borderRadius:100, fontSize:12, fontWeight:600, ...statusStyle[p.status] }}>{p.status}</span>
                </td>
                <td style={{ padding:'12px 14px', fontSize:13, color:'var(--text3)', borderBottom:'1px solid var(--border)' }}>{p.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
