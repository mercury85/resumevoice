'use client';
import { useState } from 'react';

const USERS = [
  { id:'001', email:'ivan@mail.ru', name:'Иван Петров', plan:'Премиум', resumes:5, created:'01.12.2025', status:'active' },
  { id:'002', email:'anna@ya.ru', name:'Анна Сидорова', plan:'Про', resumes:3, created:'05.12.2025', status:'active' },
  { id:'003', email:'alex@gmail.com', name:'Алексей Ко', plan:'Бесплатный', resumes:1, created:'10.12.2025', status:'active' },
  { id:'004', email:'maria@mail.ru', name:'Мария Иванова', plan:'Про', resumes:4, created:'15.12.2025', status:'blocked' },
];

const planColor: Record<string, string> = { 'Премиум':'#d97706', 'Про':'#16a34a', 'Бесплатный':'#7c3aed' };
const planBg: Record<string, string> = { 'Премиум':'#fffbeb', 'Про':'#f0fdf4', 'Бесплатный':'#f5f3ff' };

export default function AdminUsers() {
  const [search, setSearch] = useState('');
  const filtered = USERS.filter(u => u.email.includes(search) || u.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:24 }}>
        <div>
          <h1 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.5px', color:'var(--text)' }}>Пользователи</h1>
          <p style={{ fontSize:13, color:'var(--text3)', marginTop:2 }}>Управление аккаунтами</p>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по email или имени..."
            style={{ padding:'8px 14px', border:'1.5px solid var(--border)', borderRadius:8, fontSize:13, color:'var(--text)', background:'var(--bg)', outline:'none', width:220, fontFamily:'inherit' }} />
          <button style={{ padding:'8px 18px', borderRadius:8, fontSize:13, fontWeight:600, background:'#7c3aed', color:'white', border:'none', cursor:'pointer', fontFamily:'inherit' }}>+ Добавить</button>
        </div>
      </div>
      <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:24 }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr>{['ID','Email','Имя','Тариф','Резюме','Дата регистрации','Статус','Действия'].map(h => <th key={h} style={{ padding:'10px 14px', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.07em', color:'var(--text3)', borderBottom:'2px solid var(--border)', textAlign:'left' }}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((u,i) => (
              <tr key={i}>
                <td style={{ padding:'12px 14px', fontSize:13, color:'var(--text3)', borderBottom:'1px solid var(--border)' }}>#{u.id}</td>
                <td style={{ padding:'12px 14px', fontSize:14, color:'var(--text)', borderBottom:'1px solid var(--border)' }}>{u.email}</td>
                <td style={{ padding:'12px 14px', fontSize:14, fontWeight:500, color:'var(--text)', borderBottom:'1px solid var(--border)' }}>{u.name}</td>
                <td style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)' }}><span style={{ display:'inline-flex', padding:'3px 9px', borderRadius:6, fontSize:12, fontWeight:600, color:planColor[u.plan], background:planBg[u.plan] }}>{u.plan}</span></td>
                <td style={{ padding:'12px 14px', fontSize:14, color:'var(--text2)', borderBottom:'1px solid var(--border)' }}>{u.resumes}</td>
                <td style={{ padding:'12px 14px', fontSize:13, color:'var(--text3)', borderBottom:'1px solid var(--border)' }}>{u.created}</td>
                <td style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)' }}>
                  <span style={{ fontSize:12, fontWeight:600, color: u.status==='active'?'#16a34a':'#dc2626', background: u.status==='active'?'#f0fdf4':'#fef2f2', border:`1px solid ${u.status==='active'?'#bbf7d0':'#fecaca'}`, padding:'3px 9px', borderRadius:100, display:'inline-flex' }}>
                    {u.status==='active'?'Активен':'Заблокирован'}
                  </span>
                </td>
                <td style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)', display:'flex', gap:6 }}>
                  <button style={{ padding:'5px 12px', borderRadius:6, fontSize:12, fontWeight:600, background:'var(--bg2)', color:'var(--text2)', border:'1px solid var(--border)', cursor:'pointer', fontFamily:'inherit' }}>Профиль</button>
                  <button style={{ padding:'5px 12px', borderRadius:6, fontSize:12, fontWeight:600, background:'#fef2f2', color:'#dc2626', border:'1px solid #fecaca', cursor:'pointer', fontFamily:'inherit' }}>{u.status==='active'?'Блок':'Разблок'}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
