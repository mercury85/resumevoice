'use client';
import { useState } from 'react';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';
import AIWidget from '@/components/ai/AIWidget';
import Link from 'next/link';

interface Vacancy {
  id: number; title: string; company: string; logo: string;
  salary: string; city: string; match: number; remote?: boolean;
  tags: string[]; date: string; exp: string; employ: string;
}

const ALL_VACANCIES: Vacancy[] = [
  { id:1, title:'Менеджер по продажам B2B', company:'Яндекс', logo:'biz', salary:'от 120 000', city:'Москва', match:92, tags:['B2B','CRM','Переговоры'], date:'Сегодня', exp:'1-3 года', employ:'Полная' },
  { id:2, title:'Руководитель отдела продаж', company:'Сбер', logo:'biz', salary:'150 000 - 200 000', city:'Санкт-Петербург', match:87, tags:['KPI','Управление командой','Обучение'], date:'Вчера', exp:'3-6 лет', employ:'Полная' },
  { id:3, title:'Старший менеджер по продажам', company:'Ozon', logo:'biz', salary:'от 90 000', city:'Удалённо', remote:true, match:84, tags:['E-commerce','Excel','Аналитика'], date:'2 дня назад', exp:'1-3 года', employ:'Удалённая работа' },
  { id:4, title:'Key Account Manager', company:'МТС', logo:'biz', salary:'130 000 - 160 000', city:'Москва', match:81, tags:['Key Account','Переговоры','1С'], date:'3 дня назад', exp:'3-6 лет', employ:'Полная' },
  { id:5, title:'Менеджер по развитию бизнеса', company:'Тинькофф', logo:'biz', salary:'от 110 000', city:'Москва', match:78, remote:true, tags:['B2B','Развитие','Партнёрства'], date:'4 дня назад', exp:'1-3 года', employ:'Удалённая работа' },
  { id:6, title:'Региональный менеджер', company:'Магнит', logo:'biz', salary:'100 000 - 140 000', city:'Краснодар', match:74, tags:['Дистрибуция','Регионы','FMCG'], date:'5 дней назад', exp:'3-6 лет', employ:'Полная' },
  { id:7, title:'Sales Manager', company:'Авито', logo:'biz', salary:'от 95 000', city:'Екатеринбург', match:70, tags:['SaaS','B2B','CRM'], date:'6 дней назад', exp:'1-3 года', employ:'Полная' },
  { id:8, title:'Директор по продажам', company:'Лента', logo:'biz', salary:'от 200 000', city:'Новосибирск', match:66, tags:['Стратегия','Управление','P&L'], date:'7 дней назад', exp:'Более 6 лет', employ:'Полная' },
  { id:9, title:'Аккаунт-менеджер', company:'VK', logo:'biz', salary:'80 000 - 110 000', city:'Москва', match:63, tags:['Digital','Реклама','CRM'], date:'1 нед. назад', exp:'1-3 года', employ:'Полная' },
  { id:10, title:'Менеджер по продажам (удалённо)', company:'Selectel', logo:'biz', salary:'от 85 000', city:'Удалённо', remote:true, match:61, tags:['IT','Cloud','B2B'], date:'1 нед. назад', exp:'Нет опыта', employ:'Удалённая работа' },
];

const CITIES = ['Все города','Москва','Санкт-Петербург','Екатеринбург','Новосибирск','Казань','Краснодар','Ростов-на-Дону','Нижний Новгород','Самара','Омск','Уфа','Красноярск','Воронеж','Пермь','Волгоград','Удалённо'];
const EXPERIENCES = ['Любой опыт','Нет опыта','1-3 года','3-6 лет','Более 6 лет'];
const SCHEDULES = ['Любой график','Полная занятость','Частичная занятость','Удалённая работа','Гибкий график'];
const SORT_OPTIONS = ['По совпадению','По дате','По зарплате'];

const JOB_DIRS = ['Менеджер по продажам','Руководитель отдела','Key Account Manager','Бизнес-девелопер','Sales Manager','Директор по продажам'];

export default function MatchingPage() {
  const [city, setCity] = useState('Все города');
  const [minMatch, setMinMatch] = useState(60);
  const [minSalary, setMinSalary] = useState('');
  const [exp, setExp] = useState('Любой опыт');
  const [schedule, setSchedule] = useState('Любой график');
  const [sort, setSort] = useState('По совпадению');
  const [dirs, setDirs] = useState<string[]>(['Менеджер по продажам']);
  const [saved, setSaved] = useState<number[]>([]);
  const [searchText, setSearchText] = useState('');
  const [page, setPage] = useState(1);
  const PER_PAGE = 5;

  const toggleDir = (d: string) => setDirs(p => p.includes(d) ? p.filter(x => x !== d) : [...p, d]);
  const toggleSave = (id: number) => setSaved(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  let vacancies = ALL_VACANCIES.filter(v => {
    if (city !== 'Все города' && city !== 'Удалённо' && v.city !== city) return false;
    if (city === 'Удалённо' && !v.remote) return false;
    if (v.match < minMatch) return false;
    if (exp !== 'Любой опыт' && v.exp !== exp) return false;
    if (schedule !== 'Любой график' && v.employ !== schedule) return false;
    if (minSalary && parseInt(v.salary.replace(/\D/g, '')) < parseInt(minSalary)) return false;
    if (searchText && !v.title.toLowerCase().includes(searchText.toLowerCase()) && !v.company.toLowerCase().includes(searchText.toLowerCase())) return false;
    return true;
  });

  if (sort === 'По дате') vacancies = [...vacancies].sort((a, b) => a.id - b.id);
  if (sort === 'По зарплате') vacancies = [...vacancies].sort((a, b) => parseInt(b.salary.replace(/\D/g,'')) - parseInt(a.salary.replace(/\D/g,'')));

  const totalPages = Math.ceil(vacancies.length / PER_PAGE);
  const displayed = vacancies.slice((page-1)*PER_PAGE, page*PER_PAGE);

  const matchColor = (m: number) => m >= 85 ? '#16a34a' : m >= 70 ? '#d97706' : '#555';
  const matchBg = (m: number) => m >= 85 ? '#f0fdf4' : m >= 70 ? '#fffbeb' : '#f5f5f5';
  const matchBorder = (m: number) => m >= 85 ? '#bbf7d0' : m >= 70 ? '#fde68a' : '#e0e0e0';

  // styles via inline

  return (
    <>
      <ScrollProgress />
      <Nav active="/matching" />
      <main>
        <div style={{ padding: '52px 24px 36px', textAlign: 'center', background: 'var(--bg)' }}>
          <div style={{ display: 'inline-block', background: 'var(--purple-light)', color: '#7c3aed', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', padding: '5px 14px', borderRadius: 100, marginBottom: 14 }}>Подбор работы</div>
          <h1 style={{ fontSize: 'clamp(28px,4vw,44px)', fontWeight: 900, letterSpacing: '-1.5px', marginBottom: 12, color: 'var(--text)', textAlign: 'center' }}>
            Вакансии подобранные <span style={{ color: '#7c3aed' }}>именно для вас</span>
          </h1>
          <p style={{ fontSize: 16, color: 'var(--text3)', maxWidth: 480, margin: '0 auto', textAlign: 'center', lineHeight: 1.6 }}>
            Настройте критерии поиска — каждый день сервис находит подходящие вакансии.
          </p>
        </div>

        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '0 24px 80px', display: 'grid', gridTemplateColumns: '280px 1fr', gap: 24, alignItems: 'start' }}>

          {/* ── FILTERS ── */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, position: 'sticky', top: 80 }}>

            {/* Search */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 8 }}>Поиск</label>
              <input value={searchText} onChange={e => { setSearchText(e.target.value); setPage(1); }}
                placeholder="Должность или компания..."
                style={{ ...sel, padding: '9px 12px' }} />
            </div>

            {/* Job directions */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 10 }}>Направления</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {JOB_DIRS.map(d => (
                  <button key={d} onClick={() => { toggleDir(d); setPage(1); }}
                    style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 8, fontSize: 12.5, fontWeight: 500, border: `1.5px solid ${dirs.includes(d) ? '#7c3aed' : 'var(--border)'}`, background: dirs.includes(d) ? 'var(--purple-light)' : 'var(--bg)', color: dirs.includes(d) ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', textAlign: 'left', fontFamily: 'inherit', transition: 'all .15s' }}>
                    <div style={{ width: 14, height: 14, borderRadius: 3, border: `1.5px solid ${dirs.includes(d) ? '#7c3aed' : 'var(--border)'}`, background: dirs.includes(d) ? '#7c3aed' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {dirs.includes(d) && <svg width="9" height="9" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                    </div>
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* City */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 8 }}>Город</label>
              <select value={city} onChange={e => { setCity(e.target.value); setPage(1); }} style={sel}>
                {CITIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            {/* Salary */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 8 }}>Зарплата от</label>
              <input type="number" value={minSalary} onChange={e => { setMinSalary(e.target.value); setPage(1); }}
                placeholder="Например: 80000" style={{ ...sel }} />
            </div>

            {/* Experience */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 8 }}>Опыт работы</label>
              <select value={exp} onChange={e => { setExp(e.target.value); setPage(1); }} style={sel}>
                {EXPERIENCES.map(e => <option key={e}>{e}</option>)}
              </select>
            </div>

            {/* Schedule */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 8 }}>График работы</label>
              <select value={schedule} onChange={e => { setSchedule(e.target.value); setPage(1); }} style={sel}>
                {SCHEDULES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>

            {/* Match slider */}
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 18 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 4 }}>Совпадение от {minMatch}%</label>
              <div style={{ fontSize: 11, color: 'var(--text4)', marginBottom: 10 }}>Насколько вакансия подходит вашему резюме</div>
              <input type="range" min={50} max={95} value={minMatch} onChange={e => { setMinMatch(Number(e.target.value)); setPage(1); }}
                style={{ width: '100%', accentColor: '#7c3aed', cursor: 'pointer' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text4)', marginTop: 4 }}>
                <span>50%</span><span>95%</span>
              </div>
            </div>

            {/* Telegram notify */}
            <div style={{ background: 'var(--purple-light)', border: '1.5px solid var(--purple-mid)', borderRadius: 16, padding: 18, textAlign: 'center' }}>
              <div style={{ fontSize: 20, marginBottom: 8 }}>📩</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 6, color: 'var(--text)' }}>Уведомления в Telegram</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 14, lineHeight: 1.5 }}>Новые вакансии каждое утро в 9:00</div>
              <button style={{ width: '100%', padding: '10px', borderRadius: 10, fontSize: 13, fontWeight: 600, border: 'none', background: '#7c3aed', color: 'white', cursor: 'pointer', fontFamily: 'inherit' }}
                onClick={() => alert('Telegram бот: @ResumeVoiceBot')}>
                Подключить
              </button>
            </div>

            {/* Reset */}
            <button onClick={() => { setCity('Все города'); setMinMatch(60); setMinSalary(''); setExp('Любой опыт'); setSchedule('Любой график'); setSearchText(''); setPage(1); }}
              style={{ padding: '10px', borderRadius: 10, fontSize: 13, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit' }}>
              Сбросить фильтры
            </button>
          </div>

          {/* ── VACANCIES LIST ── */}
          <div>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
                Найдено <span style={{ color: '#7c3aed' }}>{vacancies.length}</span> вакансий
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, color: 'var(--text3)' }}>Сортировка:</span>
                <select value={sort} onChange={e => setSort(e.target.value)}
                  style={{ padding: '7px 10px', border: '1.5px solid var(--border)', borderRadius: 8, fontSize: 13, color: 'var(--text)', background: 'var(--bg)', outline: 'none', fontFamily: 'inherit', cursor: 'pointer' }}>
                  {SORT_OPTIONS.map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {/* Cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {displayed.map(v => (
                <div key={v.id} style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16, padding: '18px 20px', display: 'flex', alignItems: 'flex-start', gap: 16, transition: 'all .2s', cursor: 'pointer', animation: 'fadeUp .3s ease both' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = '#c4b5fd'; el.style.boxShadow = '0 4px 20px rgba(124,58,237,.08)'; el.style.transform = 'translateY(-1px)'; }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'var(--border)'; el.style.boxShadow = 'none'; el.style.transform = 'none'; }}>

                  {/* Logo */}
                  <div style={{ width: 52, height: 52, borderRadius: 12, background: 'var(--bg2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0, border: '1px solid var(--border)' }}>
                    {v.logo}
                  </div>

                  {/* Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.title}</div>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 8, flexWrap: 'wrap' }}>
                      <span style={{ fontSize: 13, color: 'var(--text2)', fontWeight: 500 }}>{v.company}</span>
                      <span style={{ fontSize: 12, color: 'var(--text3)' }}>📍 {v.city}{v.remote ? ' · Удалённо' : ''}</span>
                      <span style={{ fontSize: 12, color: 'var(--text4)' }}>{v.date}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
                      {[v.exp, v.employ, ...v.tags].map(tag => (
                        <span key={tag} style={{ fontSize: 11, padding: '3px 9px', borderRadius: 6, background: 'var(--bg2)', color: 'var(--text3)', border: '1px solid var(--border)', fontWeight: 500 }}>{tag}</span>
                      ))}
                    </div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <Link href={`/cover-letter?vac=${v.id}`}
                        style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: '8px 20px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', background: '#7c3aed', color: 'white', textDecoration: 'none', transition: 'opacity .15s' }}>
                        Откликнуться
                      </Link>
                      <button onClick={() => toggleSave(v.id)}
                        style={{ padding: '8px 12px', borderRadius: 8, fontSize: 13, border: `1.5px solid ${saved.includes(v.id) ? '#c4b5fd' : 'var(--border)'}`, background: saved.includes(v.id) ? 'var(--purple-light)' : 'var(--bg)', color: saved.includes(v.id) ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                        {saved.includes(v.id) ? '♥ Сохранено' : '♡ Сохранить'}
                      </button>
                    </div>
                  </div>

                  {/* Salary + match */}
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 8, whiteSpace: 'nowrap' }}>{v.salary} ₽</div>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 10, fontSize: 13, fontWeight: 700, color: matchColor(v.match), background: matchBg(v.match), border: `1px solid ${matchBorder(v.match)}` }}>
                      <svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                      {v.match}%
                    </div>
                  </div>
                </div>
              ))}

              {displayed.length === 0 && (
                <div style={{ textAlign: 'center', padding: '60px 24px', color: 'var(--text4)', background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16 }}>
                  <div style={{ width:56, height:56, borderRadius:16, background:'var(--purple-light)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
                <svg width="26" height="26" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </div>
                  <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 6, color: 'var(--text3)' }}>Нет вакансий по выбранным фильтрам</div>
                  <div style={{ fontSize: 13, marginBottom: 16 }}>Попробуйте изменить город, опыт или снизить порог совпадения</div>
                  <button onClick={() => { setCity('Все города'); setMinMatch(60); setExp('Любой опыт'); setSchedule('Любой график'); setPage(1); }}
                    style={{ padding: '9px 20px', borderRadius: 8, fontSize: 13, fontWeight: 600, background: '#7c3aed', color: 'white', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>
                    Сбросить фильтры
                  </button>
                </div>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 24 }}>
                <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1}
                  style={{ width: 36, height: 36, borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page===1?'default':'pointer', fontFamily: 'inherit', fontSize: 14, opacity: page===1?.5:1 }}>
                  ‹
                </button>
                {Array.from({length: totalPages}, (_,i) => i+1).map(p => (
                  <button key={p} onClick={() => setPage(p)}
                    style={{ width: 36, height: 36, borderRadius: 8, border: `1.5px solid ${page===p?'#7c3aed':'var(--border)'}`, background: page===p?'var(--purple-light)':'var(--bg)', color: page===p?'#7c3aed':'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13, fontWeight: page===p?700:400 }}>
                    {p}
                  </button>
                ))}
                <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page===totalPages}
                  style={{ width: 36, height: 36, borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page===totalPages?'default':'pointer', fontFamily: 'inherit', fontSize: 14, opacity: page===totalPages?.5:1 }}>
                  ›
                </button>
              </div>
            )}

            {/* Create resume CTA */}
            <div style={{ marginTop: 32, background: 'var(--bg2)', border: '1.5px solid var(--border)', borderRadius: 16, padding: '24px', textAlign: 'center' }}>
              <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: 'var(--text)' }}>Нет подходящего резюме?</div>
              <p style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 16 }}>Создайте резюме голосом за 2 минуты — и получайте вакансии которые соответствуют именно вашему опыту.</p>
              <Link href="/voice" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 24px', borderRadius: 8, fontSize: 13, fontWeight: 600, background: '#7c3aed', color: 'white', textDecoration: 'none' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
                Создать резюме
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <AIWidget />
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
        @media(max-width:860px){
          main > div:last-of-type{grid-template-columns:1fr!important}
        }
      `}</style>
    </>
  );
}
