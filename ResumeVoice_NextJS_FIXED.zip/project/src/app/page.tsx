'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';
import AIWidget from '@/components/ai/AIWidget';

// SVG иконки вместо эмодзи
const IconMic = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
    <line x1="12" y1="19" x2="12" y2="23"/>
    <line x1="8" y1="23" x2="16" y2="23"/>
  </svg>
);
const IconDoc = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
);
const IconSearch = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/>
    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const IconRocket = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/>
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>
  </svg>
);
const IconMail = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
    <polyline points="22,6 12,13 2,6"/>
  </svg>
);
const IconTarget = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <circle cx="12" cy="12" r="6"/>
    <circle cx="12" cy="12" r="2"/>
  </svg>
);
const IconChart = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"/>
    <line x1="12" y1="20" x2="12" y2="4"/>
    <line x1="6" y1="20" x2="6" y2="14"/>
  </svg>
);
const IconBriefcase = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
  </svg>
);
const IconBell = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
    <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
  </svg>
);
const IconUpload = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="17 8 12 3 7 8"/>
    <line x1="12" y1="3" x2="12" y2="15"/>
  </svg>
);
const IconStar = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
  </svg>
);

// Иконки для шагов (меньший размер)
const StepIconMic = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
    <line x1="12" y1="19" x2="12" y2="23"/>
  </svg>
);
const StepIconDoc = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
  </svg>
);
const StepIconSearch = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/>
    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const StepIconRocket = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
  </svg>
);

const features = [
  { icon: <IconMic />, title:'Резюме голосом', desc:'Расскажите о себе вслух. Сервис составит профессиональное резюме без единой формы.', star:true },
  { icon: <IconSearch />, title:'Автопоиск вакансий', desc:'Каждый день сервис находит вакансии которые максимально совпадают с вашим опытом.', star:true },
  { icon: <IconUpload />, title:'Улучшение резюме', desc:'Загрузите старое резюме или надиктуйте правки голосом. Режим «было — стало».', star:false },
  { icon: <IconMail />, title:'Сопроводительные письма', desc:'Персональное письмо для каждой вакансии одной кнопкой.', star:false },
  { icon: <IconTarget />, title:'Адаптация под вакансию', desc:'Для каждой вакансии создаётся отдельная версия резюме с акцентом на нужные навыки.', star:false },
  { icon: <IconStar />, title:'Тренировка собеседования', desc:'Пройдите пробное собеседование голосом. Сервис задаёт вопросы как HR, потом разбирает ответы.', star:false },
  { icon: <IconChart />, title:'Анализ рынка и зарплат', desc:'Средние и максимальные зарплаты по вашей позиции. Востребованные навыки.', star:false },
  { icon: <IconBriefcase />, title:'Карьерные рекомендации', desc:'Спросите: «Почему мне не отвечают?» Сервис проанализирует резюме и даст советы.', star:false },
  { icon: <IconBell />, title:'Уведомления о вакансиях', desc:'Новые подходящие вакансии приходят в Telegram каждое утро.', star:false },
];

const steps = [
  { n:1, icon: <StepIconMic />, t:'Рассказали о себе', d:'Нажали на микрофон и говорите 1-2 минуты. Где работали, что умеете, чего хотите.' },
  { n:2, icon: <StepIconDoc />, t:'Получили резюме', d:'Готовое профессиональное резюме через 30 секунд. Можно отредактировать или скачать.' },
  { n:3, icon: <StepIconSearch />, t:'Нашли вакансии', d:'Сервис подбирает вакансии которые максимально совпадают с вашим опытом.' },
  { n:4, icon: <StepIconRocket />, t:'Подготовились и отправили', d:'Сопроводительное письмо в один клик. Тренировка собеседования перед встречей.' },
];

const plans = [
  {
    name:'Бесплатно', price:'0', per:'навсегда', pop:false, prem:false,
    desc:'Попробуйте сервис без ограничений по времени.',
    items:['1 резюме голосом','Редактирование резюме','Скачать PDF','1 сопроводительное письмо'],
    nope:['Доступ к вакансиям','Улучшение резюме','Тренировка собеседования'],
    fit:'хотите попробовать сервис или создаёте первое резюме.',
    btn:'Начать бесплатно', btnCls:'outline', href:'/register',
  },
  {
    name:'Про', price:'699', per:'руб/мес', pop:true, prem:false,
    desc:'Для тех кто активно ищет работу прямо сейчас.',
    items:['Безлимит резюме','PDF и Word (DOCX)','До 100 вакансий в день','30 сопроводительных писем','Улучшение и анализ резюме','Адаптация резюме под вакансии','Уведомления о вакансиях','Тренировка собеседования'],
    nope:[], fit:'активно ищете работу и хотите найти её быстро.',
    btn:'Выбрать тариф', btnCls:'primary', href:'/register?plan=pro',
  },
  {
    name:'Премиум', price:'1490', per:'руб/мес', pop:false, prem:true,
    desc:'Для тех кто ищет в нескольких направлениях.',
    items:['Всё из тарифа Про','Безлимит вакансий','Безлимит писем','До 10 направлений поиска','Анализ рынка и зарплат','Персональный план поиска','Карьерный консультант','Приоритетная поддержка'],
    nope:[], fit:'ищете в нескольких городах или рассматриваете разные профессии.',
    btn:'Выбрать тариф', btnCls:'amber', href:'/register?plan=premium',
  },
];

export default function HomePage() {
  const [micState, setMicState] = useState<'idle'|'rec'|'proc'|'done'>('idle');
  const [sec, setSec] = useState(0);
  const [showTranscript, setShowTranscript] = useState(false);
  const [visible, setVisible] = useState<Record<string,boolean>>({});
  const timerRef = useRef<ReturnType<typeof setInterval>>();
  const mrRef = useRef<MediaRecorder>();

  // Fix hydration — всё рендерим после mount
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  // Intersection Observer для анимаций появления
  useEffect(() => {
    if (!mounted) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          setVisible(v => ({ ...v, [e.target.id]: true }));
        }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('[data-animate]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [mounted]);

  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      mrRef.current = mr;
      mr.start();
      mr.onstop = () => stream.getTracks().forEach(t => t.stop());
      setMicState('rec'); setSec(0);
      timerRef.current = setInterval(() => {
        setSec(s => { if (s >= 299) { stopRec(); return s; } return s + 1; });
      }, 1000);
    } catch {
      window.location.href = '/voice';
    }
  };

  const stopRec = () => {
    clearInterval(timerRef.current);
    mrRef.current?.stop();
    setMicState('proc');
    setTimeout(() => { setMicState('done'); setShowTranscript(true); }, 2000);
  };

  const toggleMic = () => {
    if (micState === 'rec') stopRec();
    else if (micState === 'idle' || micState === 'done') startRec();
  };

  const micBg =
    micState === 'rec'  ? 'linear-gradient(145deg,#f87171,#dc2626)' :
    micState === 'proc' ? 'linear-gradient(145deg,#34d399,#059669)' :
                          'linear-gradient(145deg,#8b5cf6,#7c3aed)';

  const fmtSec = (s:number) => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;

  if (!mounted) return null;

  return (
    <>
      <ScrollProgress />
      <Nav />
      <main>

        {/* ── HERO ── */}
        <section style={{ minHeight: 'calc(100vh - 64px)', maxHeight: 900, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px 56px', textAlign: 'center', background: 'var(--bg)', position: 'relative', overflow: 'hidden' }}>
          {/* animated bg blobs */}
          <div style={{ position: 'absolute', width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle,rgba(124,58,237,.09) 0%,transparent 70%)', top: '40%', left: '50%', transform: 'translate(-50%,-52%)', pointerEvents: 'none', animation: 'blobFloat 8s ease-in-out infinite' }} />
          <div style={{ position: 'absolute', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle,rgba(124,58,237,.05) 0%,transparent 70%)', top: '20%', left: '20%', pointerEvents: 'none', animation: 'blobFloat2 11s ease-in-out infinite' }} />
          <div style={{ position: 'absolute', width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle,rgba(139,92,246,.06) 0%,transparent 70%)', bottom: '15%', right: '15%', pointerEvents: 'none', animation: 'blobFloat 13s ease-in-out 2s infinite' }} />

          {/* badge */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: '#f5f3ff', border: '1.5px solid #e9e3ff', color: '#7c3aed', fontSize: 13, fontWeight: 600, padding: '6px 16px', borderRadius: 100, marginBottom: 20, animation: 'fadeSlideDown .7s ease both' }}>
            <span>🏆</span> Первый в России сервис создания резюме голосом
          </div>

          {/* h1 */}
          <h1 style={{ fontSize: 'clamp(26px,4vw,48px)', fontWeight: 900, letterSpacing: '-1.5px', lineHeight: 1.1, color: 'var(--text)', margin: '0 0 0', textAlign: 'center', maxWidth: 700, animation: 'fadeSlideDown .8s ease .1s both' }}>
            Расскажите о себе голосом<br />
            <em style={{ color: '#7c3aed', fontStyle: 'normal' }}>и получите идеальное резюме</em>
          </h1>

          {/* MIC */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 44, animation: 'fadeSlideDown .9s ease .2s both' }}>
            <div style={{ position: 'relative', width: 148, height: 148, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {/* rings */}
              {['-18px','-34px','-52px'].map((inset, i) => (
                <div key={i} style={{
                  position: 'absolute', inset: inset, borderRadius: '50%',
                  border: `2px solid rgba(${micState==='rec'?'220,38,38':'124,58,237'},.${18-i*4})`,
                  animation: `mrp 2.5s ease-in-out ${i*0.6}s infinite`,
                  pointerEvents: 'none',
                }} />
              ))}

              {/* button */}
              <button
                onClick={toggleMic}
                aria-label="Начать / остановить запись"
                style={{
                  position: 'relative', zIndex: 2,
                  width: 148, height: 148, borderRadius: '50%',
                  background: micBg,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  border: 'none', cursor: 'pointer',
                  boxShadow: '0 0 0 6px rgba(124,58,237,.1),0 20px 64px rgba(124,58,237,.38)',
                  transition: 'transform .2s,box-shadow .2s',
                  animation: micState === 'rec' ? 'rp .9s ease-in-out infinite' : 'none',
                }}
              >
                {micState === 'proc' ? (
                  <svg width="52" height="52" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M4.93 4.93a10 10 0 0 0 0 14.14"/>
                  </svg>
                ) : micState === 'rec' ? (
                  <svg width="48" height="48" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>
                  </svg>
                ) : (
                  <svg width="54" height="54" viewBox="0 0 24 24" stroke="#fff" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                    <line x1="12" y1="19" x2="12" y2="23"/>
                    <line x1="8" y1="23" x2="16" y2="23"/>
                  </svg>
                )}
              </button>
            </div>

            {/* waves */}
            {micState === 'rec' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, height: 26, marginTop: 16, justifyContent: 'center' }}>
                {[6,18,28,10,32,22,8,26,14,6].map((h,i) => (
                  <div key={i} style={{ width: 3, height: h, borderRadius: 3, background: '#ef4444', animation: `wvs 1.1s ${i*0.05}s ease-in-out infinite` }} />
                ))}
              </div>
            )}

            {/* timer */}
            {micState === 'rec' && (
              <div style={{ fontSize: 30, fontWeight: 800, color: '#dc2626', letterSpacing: '-1px', marginTop: 10 }}>
                {fmtSec(sec)}
              </div>
            )}

            {/* caption */}
            <div style={{ fontSize: 15, color: 'var(--text3)', maxWidth: 400, margin: '0 auto', marginTop: 44, paddingTop: 8, lineHeight: 1.65, textAlign: 'center' }}>
              {micState === 'idle' && (
                <>
                  Нажмите на микрофон и расскажите о себе.<br />
                  <span style={{ color: 'var(--text4)', fontSize: 13 }}>Резюме готово за 2 минуты — без форм, без шаблонов.</span>
                </>
              )}
              {micState === 'rec'  && <span style={{ color: '#dc2626', fontWeight: 600 }}>Слушаю — говорите свободно!</span>}
              {micState === 'proc' && <span style={{ color: '#059669', fontWeight: 600 }}>Готовлю резюме...</span>}
              {micState === 'done' && <span style={{ color: '#7c3aed', fontWeight: 600 }}>Готово! Создаём резюме</span>}
            </div>

            {/* transcript box */}
            {showTranscript && (
              <div style={{ background: '#f5f3ff', border: '1.5px solid #e9e3ff', borderRadius: 14, padding: '14px 18px', marginTop: 14, maxWidth: 440, width: '100%', textAlign: 'left', fontSize: 13, color: '#444', lineHeight: 1.6 }}>
                <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: '#7c3aed', marginBottom: 6 }}>Что вы сказали</div>
                <div>[В рабочей версии здесь появится распознанный текст вашей речи]</div>
                <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                  <button onClick={() => { setShowTranscript(false); setMicState('idle'); }} style={{ padding: '6px 13px', borderRadius: 8, fontSize: 12, fontWeight: 600, border: '1.5px solid #e9e3ff', background: '#fff', color: '#7c3aed', cursor: 'pointer', fontFamily: 'inherit' }}>Записать ещё раз</button>
                  <Link href="/voice" style={{ padding: '6px 13px', borderRadius: 8, fontSize: 12, fontWeight: 600, background: '#7c3aed', color: '#fff', textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>Создать резюме</Link>
                </div>
              </div>
            )}

            {/* CTA */}
            {micState === 'done' && !showTranscript && (
              <div style={{ marginTop: 20, textAlign: 'center' }}>
                <Link href="/voice" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 9, padding: '14px 32px', borderRadius: 100, fontSize: 15, fontWeight: 700, background: '#7c3aed', color: '#fff', textDecoration: 'none', boxShadow: '0 10px 36px rgba(124,58,237,.38)' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  Создать резюме
                </Link>
              </div>
            )}
          </div>

          {/* alt buttons */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap', marginTop: 20, animation: 'fadeSlideDown 1s ease .3s both' }}>
            {[['Написать текстом','/voice?mode=text'],['Загрузить резюме','/upgrade'],['Найти вакансии','/vacancies']].map(([l,h]) => (
              <Link key={h} href={h} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 16px', borderRadius: 100, fontSize: 12, fontWeight: 500, border: '1.5px solid var(--border)', color: 'var(--text3)', background: 'var(--bg)', textDecoration: 'none', transition: 'all .15s' }}>
                {l}
              </Link>
            ))}
          </div>
        </section>

        {/* ── STATS ── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', background: 'var(--bg)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
          {([
            { n:'2 мин', l:'среднее время создания резюме', icon: <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> },
            { n:'30 000+', l:'вакансий обновляется ежедневно', icon: <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> },
            { n:'+68%', l:'больше приглашений на собеседование', icon: <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg> },
          ] as const).map((item, i) => (
            <div key={item.n} style={{ padding: '32px 24px', textAlign: 'center', borderRight: i < 2 ? '1px solid var(--border)' : 'none', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 48, height: 48, borderRadius: 14, background: 'var(--purple-light)', border: '1.5px solid #e9e3ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {item.icon}
              </div>
              <div style={{ fontSize: 34, fontWeight: 900, color: '#7c3aed', letterSpacing: '-1.5px', lineHeight: 1 }}>{item.n}</div>
              <div style={{ fontSize: 13, color: 'var(--text3)', lineHeight: 1.4, maxWidth: 160 }}>{item.l}</div>
            </div>
          ))}
        </div>

        {/* ── UPGRADE BLOCK — полный, как на скриншоте ── */}
        <section id="resume-upload" data-animate style={{ padding:'56px 48px', background:'var(--bg)', opacity: visible['resume-upload'] ? 1 : 0, transform: visible['resume-upload'] ? 'translateY(0)' : 'translateY(30px)', transition: 'opacity .7s ease, transform .7s ease' }}>
          <div style={{ maxWidth:1000, margin:'0 auto' }}>
            {/* Заголовок */}
            <div style={{ textAlign:'center', marginBottom:40 }}>
              <div style={{ display:'inline-block', background:'var(--purple-light)', color:'#7c3aed', fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', padding:'5px 14px', borderRadius:100, marginBottom:14, border:'1px solid #c4b5fd' }}>
                Апгрейд резюме
              </div>
              <h2 style={{ fontSize:'clamp(26px,4vw,40px)', fontWeight:800, letterSpacing:'-1px', lineHeight:1.15, margin:'0 0 12px', color:'var(--text)' }}>
                Было слабое —{' '}<span style={{ color:'#7c3aed' }}>стало сильное</span>
              </h2>
              <p style={{ fontSize:16, color:'var(--text3)', maxWidth:500, margin:'0 auto', lineHeight:1.6 }}>
                Загрузи своё резюме. Мы найдём и исправим всё что мешает получить лучшую работу!
              </p>
            </div>

            {/* Карточка с демо */}
            <div style={{ background:'var(--bg2)', border:'1.5px solid var(--border)', borderRadius:24, padding:40, display:'grid', gridTemplateColumns:'1fr 1fr', gap:32, alignItems:'center' }}>
              {/* Левая часть — таблица было/стало */}
              <div>
                <p style={{ fontSize:14, color:'var(--text3)', lineHeight:1.6, marginBottom:20 }}>
                  Аудит по 15 критериям: структура, достижения, глаголы, навыки, длина, грамматика. Каждая правка с объяснением почему это важно.
                </p>
                <div style={{ border:'1.5px solid var(--border)', borderRadius:14, overflow:'hidden' }}>
                  {/* Шапка */}
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', background:'var(--bg)', borderBottom:'1.5px solid var(--border)' }}>
                    <div style={{ padding:'10px 16px', fontSize:11, fontWeight:700, letterSpacing:'.07em', textTransform:'uppercase', color:'var(--text4)' }}>Было</div>
                    <div style={{ padding:'10px 16px', fontSize:11, fontWeight:700, letterSpacing:'.07em', textTransform:'uppercase', color:'#7c3aed', borderLeft:'1.5px solid var(--border)' }}>Стало</div>
                  </div>
                  {[
                    ['Занимался улучшением процессов отдела','Сократил цикл сделки на 35%, конверсия +23%'],
                    ['Был ответственен за разработку функций','Разработал 12 функций, 4 вошли в ключевой релиз'],
                    ['Знание MS Office, коммуникабельный','Удалено — не добавляет ценности для позиции'],
                    ['(раздел summary отсутствует)','Middle Dev, 4 года, React/TS, продукт MAU 500k+'],
                  ].map(([before, after], i) => (
                    <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 1fr', borderBottom: i < 3 ? '1px solid var(--border)' : 'none' }}>
                      <div style={{ padding:'10px 16px', fontSize:13, color:'var(--text4)', lineHeight:1.45, fontStyle:'italic', borderRight:'1.5px solid var(--border)' }}>{before}</div>
                      <div style={{ padding:'10px 16px', fontSize:13, color:'var(--text)', lineHeight:1.45, fontWeight:500 }}>{after}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Правая часть — карьерный индекс */}
              <div style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:20, padding:28, display:'flex', flexDirection:'column', gap:16 }}>
                <div style={{ fontSize:13, color:'var(--text3)', fontWeight:500 }}>Карьерный индекс</div>
                <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between' }}>
                  <div>
                    <div style={{ fontSize:56, fontWeight:900, color:'#7c3aed', letterSpacing:'-3px', lineHeight:1 }}>810</div>
                    <div style={{ fontSize:14, fontWeight:700, color:'#16a34a', marginTop:4 }}>+390 после правок</div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ fontSize:13, color:'var(--text4)', marginBottom:2 }}>Было</div>
                    <div style={{ fontSize:28, fontWeight:800, color:'var(--text3)', letterSpacing:'-1px' }}>420</div>
                  </div>
                </div>
                {/* Прогресс-бары */}
                {[
                  ['Достижения', 92],
                  ['Навыки',     85],
                  ['Структура',  95],
                  ['Глаголы',    88],
                  ['Читаемость', 80],
                ].map(([label, pct]) => (
                  <div key={label as string}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                      <span style={{ fontSize:13, color:'var(--text2)' }}>{label}</span>
                      <span style={{ fontSize:13, fontWeight:600, color:'var(--text)' }}>{pct}%</span>
                    </div>
                    <div style={{ height:6, borderRadius:6, background:'var(--bg2)', overflow:'hidden' }}>
                      <div style={{ height:'100%', width:`${pct}%`, borderRadius:6, background:'linear-gradient(90deg,#8b5cf6,#7c3aed)', transition:'width 1s ease' }} />
                    </div>
                  </div>
                ))}
                {/* Кнопка */}
                <Link href="/upgrade" style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:9, padding:'14px', borderRadius:12, fontSize:15, fontWeight:700, background:'#7c3aed', color:'#fff', textDecoration:'none', marginTop:4, boxShadow:'0 6px 20px rgba(124,58,237,.35)', transition:'all .2s' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  Загрузить резюме на апгрейд
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ── FEATURES ── */}
        <section id="features" style={{ padding: '40px 48px 56px', background: 'var(--bg2)', textAlign: 'center' }}>
          <div style={{ maxWidth: 1000, margin: '0 auto' }}>
            <div id="feat-label" data-animate style={{ display: 'inline-block', background: 'var(--purple-light)', color: '#7c3aed', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', padding: '5px 14px', borderRadius: 100, marginBottom: 14, opacity: visible['feat-label'] ? 1 : 0, transform: visible['feat-label'] ? 'translateY(0)' : 'translateY(20px)', transition: 'opacity .6s ease, transform .6s ease' }}>Возможности</div>
            <h2 id="feat-h2" data-animate style={{ fontSize: 'clamp(26px,4vw,40px)', fontWeight: 800, letterSpacing: '-1px', lineHeight: 1.15, margin: '0 0 12px', color: 'var(--text)', textAlign: 'center', opacity: visible['feat-h2'] ? 1 : 0, transform: visible['feat-h2'] ? 'translateY(0)' : 'translateY(20px)', transition: 'opacity .6s .1s ease, transform .6s .1s ease' }}>
              От рассказа до <span style={{ color: '#7c3aed' }}>новой работы</span>
            </h2>
            <p id="feat-p" data-animate style={{ fontSize: 16, color: 'var(--text3)', lineHeight: 1.65, maxWidth: 560, margin: '0 auto 48px', textAlign: 'center', opacity: visible['feat-p'] ? 1 : 0, transform: visible['feat-p'] ? 'translateY(0)' : 'translateY(20px)', transition: 'opacity .6s .2s ease, transform .6s .2s ease' }}>Голос вместо форм. Резюме — за минуту. Работа — быстрее.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, textAlign: 'left' }}>
              {features.map((f, i) => (
                <div
                  key={i}
                  id={`feat-card-${i}`}
                  data-animate
                  style={{
                    background: 'var(--bg)',
                    border: '1.5px solid var(--border)',
                    borderRadius: 20, padding: 26,
                    transition: `all .25s ease ${i * 0.06}s`,
                    opacity: visible[`feat-card-${i}`] ? 1 : 0,
                    transform: visible[`feat-card-${i}`] ? 'translateY(0) scale(1)' : 'translateY(24px) scale(.98)',
                    cursor: 'default',
                  }}
                  onMouseEnter={e => {
                    const el = e.currentTarget as HTMLElement;
                    el.style.transform = 'translateY(-4px) scale(1.01)';
                    el.style.boxShadow = '0 12px 40px rgba(124,58,237,.14)';
                    el.style.borderColor = '#a78bfa';
                  }}
                  onMouseLeave={e => {
                    const el = e.currentTarget as HTMLElement;
                    el.style.transform = 'translateY(0) scale(1)';
                    el.style.boxShadow = 'none';
                    el.style.borderColor = 'var(--border)';
                  }}
                >
                  <div style={{ width: 52, height: 52, borderRadius: 14, background: 'var(--purple-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14, border: '1.5px solid #e9e3ff' }}>
                    {f.icon}
                  </div>
                  {f.star && <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: 'var(--purple-light)', color: '#7c3aed', fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20, marginBottom: 8, border: '1px solid #c4b5fd' }}><svg width="10" height="10" viewBox="0 0 24 24" fill="#7c3aed"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>Только у нас</div>}
                  <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 7, color: 'var(--text)' }}>{f.title}</div>
                  <div style={{ fontSize: 13, color: 'var(--text3)', lineHeight: 1.55 }}>{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── HOW ── */}
        <section id="how" style={{ padding: '40px 48px 56px', textAlign: 'center' }}>
          <div style={{ maxWidth: 1000, margin: '0 auto' }}>
            <div style={{ display: 'inline-block', background: 'var(--purple-light)', color: '#7c3aed', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', padding: '5px 14px', borderRadius: 100, marginBottom: 14 }}>Как это работает</div>
            <h2 style={{ fontSize: 'clamp(26px,4vw,40px)', fontWeight: 800, letterSpacing: '-1px', lineHeight: 1.15, margin: '0 0 12px', color: 'var(--text)', textAlign: 'center' }}>
              4 шага до <span style={{ color: '#7c3aed' }}>новой работы</span>
            </h2>
            <p style={{ fontSize: 16, color: 'var(--text3)', lineHeight: 1.65, maxWidth: 560, margin: '0 auto 48px', textAlign: 'center' }}>Не нужно знать что писать. Просто расскажите о себе.</p>
            <div id="how-grid" data-animate style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', border: '1.5px solid var(--border)', borderRadius: 20, overflow: 'hidden', textAlign: 'left', opacity: visible['how-grid'] ? 1 : 0, transform: visible['how-grid'] ? 'translateY(0)' : 'translateY(30px)', transition: 'opacity .7s ease, transform .7s ease' }}>
              {steps.map((st, i) => (
                <div key={i} style={{ padding: '28px 20px', borderRight: i < 3 ? '1.5px solid var(--border)' : 'none', background: 'var(--bg)' }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#7c3aed', color: '#fff', fontSize: 13, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12, boxShadow: '0 4px 12px rgba(124,58,237,.3)' }}>{st.icon}</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#7c3aed', letterSpacing: '.06em', marginBottom: 6 }}>ШАГ {st.n}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 6, color: 'var(--text)' }}>{st.t}</div>
                  <div style={{ fontSize: 13, color: 'var(--text3)', lineHeight: 1.55 }}>{st.d}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section id="pricing" style={{ padding: '40px 48px 56px', background: 'var(--bg2)', textAlign: 'center' }}>
          <div style={{ maxWidth: 1000, margin: '0 auto' }}>
            <div style={{ display: 'inline-block', background: 'var(--purple-light)', color: '#7c3aed', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', padding: '5px 14px', borderRadius: 100, marginBottom: 14 }}>Тарифы</div>
            <h2 style={{ fontSize: 'clamp(26px,4vw,40px)', fontWeight: 800, letterSpacing: '-1px', lineHeight: 1.15, margin: '0 0 12px', color: 'var(--text)', textAlign: 'center' }}>
              Начните <span style={{ color: '#7c3aed' }}>бесплатно</span>
            </h2>
            <p style={{ fontSize: 16, color: 'var(--text3)', lineHeight: 1.65, maxWidth: 560, margin: '0 auto 48px', textAlign: 'center' }}>Первое резюме бесплатно. Платите только когда хотите большего.</p>
            <div id="pricing-grid" data-animate style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, alignItems: 'start', textAlign: 'left', opacity: visible['pricing-grid'] ? 1 : 0, transform: visible['pricing-grid'] ? 'translateY(0)' : 'translateY(30px)', transition: 'opacity .7s ease, transform .7s ease' }}>
              {plans.map((p, i) => (
                <div key={i} style={{ border: `${p.pop||p.prem?2:1.5}px solid ${p.pop?'#7c3aed':p.prem?'#f59e0b':'var(--border)'}`, borderRadius: 20, padding: 28, background: p.pop?'var(--purple-light)':p.prem?'rgba(245,158,11,.05)':'var(--bg)', position: 'relative', transition: 'transform .2s' }}>
                  {p.pop && <div style={{ position: 'absolute', top: -13, left: '50%', transform: 'translateX(-50%)', background: '#7c3aed', color: '#fff', fontSize: 12, fontWeight: 700, padding: '4px 16px', borderRadius: 100, whiteSpace: 'nowrap' }}>Самый популярный</div>}
                  {p.prem && <div style={{ position: 'absolute', top: -13, left: '50%', transform: 'translateX(-50%)', background: '#f59e0b', color: '#fff', fontSize: 12, fontWeight: 700, padding: '4px 16px', borderRadius: 100, whiteSpace: 'nowrap' }}>Максимум возможностей</div>}
                  <div style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 8 }}>{p.name}</div>
                  <div style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-2px', lineHeight: 1, color: 'var(--text)', marginBottom: 4 }}>
                    {p.price} <sub style={{ fontSize: 14, fontWeight: 400, color: 'var(--text4)', letterSpacing: 0, verticalAlign: 'middle' }}>{p.per}</sub>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text4)', marginBottom: 8 }}>в месяц</div>
                  <div style={{ fontSize: 13, color: 'var(--text3)', marginBottom: 18, lineHeight: 1.5 }}>{p.desc}</div>
                  <ul style={{ listStyle: 'none', marginBottom: 20, padding: 0 }}>
                    {p.items.map(item => (
                      <li key={item} style={{ fontSize: 13, color: 'var(--text2)', padding: '6px 0', display: 'flex', alignItems: 'flex-start', gap: 7, borderBottom: '1px solid var(--border)', lineHeight: 1.4 }}>
                        <span style={{ color: '#16a34a', fontWeight: 800, fontSize: 12, flexShrink: 0, marginTop: 1 }}>✓</span>{item}
                      </li>
                    ))}
                    {p.nope.map(item => (
                      <li key={item} style={{ fontSize: 13, color: 'var(--text4)', padding: '6px 0', display: 'flex', alignItems: 'flex-start', gap: 7, lineHeight: 1.4 }}>
                        <span style={{ flexShrink: 0 }}>–</span>{item}
                      </li>
                    ))}
                  </ul>
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 18, borderTop: '1px solid var(--border)', paddingTop: 12, lineHeight: 1.55 }}>
                    <strong style={{ display: 'block', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--text4)', marginBottom: 6 }}>Подойдёт если:</strong>
                    {p.fit}
                  </div>
                  <Link href={p.href} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', padding: '12px 0', borderRadius: 12, fontSize: 14, fontWeight: 600, cursor: 'pointer', textAlign: 'center', textDecoration: 'none', background: p.btnCls==='primary'?'#7c3aed':p.btnCls==='amber'?'#f59e0b':'transparent', color: p.btnCls==='outline'?'var(--text)':'#fff', border: p.btnCls==='outline'?'1.5px solid var(--border)':'none', transition: 'all .15s' }}>
                    {p.btn}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ── */}
        <section style={{ background: 'var(--purple-light)', borderTop: '1.5px solid var(--purple-mid)', padding: '48px 48px', textAlign: 'center' }}>
          <h2 style={{ fontSize: 'clamp(26px,5vw,44px)', fontWeight: 800, letterSpacing: '-1.5px', marginBottom: 12, color: 'var(--text)', textAlign: 'center' }}>Расскажите о себе голосом</h2>
          <p style={{ fontSize: 17, color: 'var(--text3)', marginBottom: 32, maxWidth: 460, marginLeft: 'auto', marginRight: 'auto', lineHeight: 1.6, textAlign: 'center' }}>Получите готовое резюме и подходящие вакансии за 2 минуты. Бесплатно.</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/voice" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 9, padding: '15px 34px', borderRadius: 12, fontSize: 16, fontWeight: 700, background: '#7c3aed', color: '#fff', textDecoration: 'none', boxShadow: '0 8px 28px rgba(124,58,237,.35)' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
              Создать резюме
            </Link>
            <Link href="/vacancies" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: '15px 28px', borderRadius: 12, fontSize: 15, background: 'var(--bg)', color: 'var(--text)', textDecoration: 'none', border: '1.5px solid var(--border)' }}>
              Найти вакансии
            </Link>
          </div>
        </section>

      </main>
      <Footer />
      <AIWidget />

      <style>{`
        @keyframes mrp{0%,100%{opacity:.5;transform:scale(1)}50%{opacity:1;transform:scale(1.05)}}
        @keyframes rp{0%,100%{transform:scale(1)}50%{transform:scale(1.04)}}
        @keyframes wvs{0%,100%{transform:scaleY(.2);opacity:.3}50%{transform:scaleY(1);opacity:1}}
        @keyframes fadeSlideDown{from{opacity:0;transform:translateY(-18px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blobFloat{0%,100%{transform:translate(-50%,-52%) scale(1)}50%{transform:translate(-50%,-50%) scale(1.08)}}
        @keyframes blobFloat2{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(15px,-20px) scale(1.06)}}
        @media(max-width:860px){
          #resume-upload > div > div:last-child{grid-template-columns:1fr!important}
          #features > div > div:last-child{grid-template-columns:1fr 1fr!important}
          #how > div > div:last-child{grid-template-columns:1fr 1fr!important}
          #pricing > div > div:last-child{grid-template-columns:1fr!important}
        }
        @media(max-width:560px){
          #features > div > div:last-child{grid-template-columns:1fr!important}
          #how > div > div:last-child{grid-template-columns:1fr!important}
          section{padding:48px 20px!important}
          #resume-upload > div{padding:36px 24px!important}
        }
      `}</style>
    </>
  );
}
