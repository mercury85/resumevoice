import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/admin/',
          '/api/',
          '/dashboard/',
          '/_next/',
          '/editor',
          '/analytics',
        ],
      },
      // Яндекс-бот
      {
        userAgent: 'Yandexbot',
        allow: '/',
        disallow: ['/admin/', '/api/', '/dashboard/', '/editor'],
      },
    ],
    sitemap: 'https://resumevoice.ru/sitemap.xml',
    host: 'https://resumevoice.ru',
  };
}
