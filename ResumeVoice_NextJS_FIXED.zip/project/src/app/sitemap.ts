import { MetadataRoute } from 'next';

const SITE_URL = 'https://resumevoice.ru';

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date().toISOString();

  const staticRoutes = [
    { url: SITE_URL,                   priority: 1.0,  changeFrequency: 'weekly'  as const },
    { url: `${SITE_URL}/voice`,        priority: 0.95, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/upgrade`,      priority: 0.85, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/vacancies`,    priority: 0.85, changeFrequency: 'daily'   as const },
    { url: `${SITE_URL}/matching`,     priority: 0.80, changeFrequency: 'daily'   as const },
    { url: `${SITE_URL}/register`,     priority: 0.80, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/login`,        priority: 0.60, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/#pricing`,     priority: 0.75, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/about`,        priority: 0.50, changeFrequency: 'monthly' as const },
    { url: `${SITE_URL}/blog`,         priority: 0.60, changeFrequency: 'weekly'  as const },
    { url: `${SITE_URL}/contact`,      priority: 0.40, changeFrequency: 'yearly'  as const },
    { url: `${SITE_URL}/privacy`,      priority: 0.20, changeFrequency: 'yearly'  as const },
    { url: `${SITE_URL}/terms`,        priority: 0.20, changeFrequency: 'yearly'  as const },
  ];

  return staticRoutes.map(r => ({
    url: r.url,
    lastModified: now,
    changeFrequency: r.changeFrequency,
    priority: r.priority,
  }));
}
