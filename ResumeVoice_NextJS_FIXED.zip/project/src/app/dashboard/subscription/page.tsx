'use client';
import Link from 'next/link';

const plans = [
  { name:'Бесплатно', price:'0', per:'навсегда', current:true, color:'#7c3aed', bg:'var(--purple-light)', items:['1 резюме','1 сопроводительное письмо','Скачать PDF','Без доступа к вакансиям'], href:'/register' },
  { name:'Про', price:'699', per:'руб/мес', current:false, color:'#16a34a', bg:'#f0fdf4', items:['Безлимит резюме','PDF и Word (DOCX)','До 100 вакансий в день','30 писем в месяц','Улучшение резюме','Тренировка собеседования'], href:'/register?plan=pro' },
  { name:'Премиум', price:'1490', per:'руб/мес', current:false, color:'#d97706', bg:'#fffbeb', items:['Всё из Про','Безлимит вакансий','Безлимит писем','До 10 направлений','Анализ зарплат','Карьерный консультант','Приоритетная поддержка'], href:'/register?plan=premium' },
];

export default function DashboardSubscription() {
  return (
    <div>
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Тариф и оплата</h1>
        <p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Ваш текущий тариф и история платежей</p>
      </div>

      {/* Current plan */}
      <div style={{background:'linear-gradient(135deg,var(--purple-light),var(--purple-mid))',border:'2px solid var(--purple-mid)',borderRadius:20,padding:28,marginBottom:24}}>
        <div style={{fontSize:12,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'#7c3aed',marginBottom:8}}>Текущий тариф</div>
        <div style={{fontSize:32,fontWeight:900,letterSpacing:'-1px',color:'var(--text)',marginBottom:6}}>Бесплатно</div>
        <div style={{fontSize:14,color:'var(--text3)',marginBottom:20}}>Базовые возможности для знакомства с сервисом</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
          {[['1','резюме'],['1','письмо'],['0','вакансий'],['PDF','экспорт']].map(([n,l])=>(
            <div key={l} style={{background:'rgba(255,255,255,.6)',borderRadius:10,padding:'12px',textAlign:'center'}}>
              <div style={{fontSize:22,fontWeight:800,color:'#7c3aed',letterSpacing:'-1px'}}>{n}</div>
              <div style={{fontSize:11,color:'var(--text3)',marginTop:2}}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Upgrade options */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:24}}>
        {plans.filter(p=>!p.current).map(p=>(
          <div key={p.name} style={{background:'var(--bg)',border:`2px solid ${p.color}20`,borderRadius:20,padding:28}}>
            <div style={{fontSize:13,color:'var(--text3)',marginBottom:6}}>{p.name}</div>
            <div style={{fontSize:36,fontWeight:900,letterSpacing:'-2px',color:p.color,marginBottom:4}}>{p.price} <sub style={{fontSize:14,fontWeight:400,color:'var(--text4)',letterSpacing:0}}>{p.per}</sub></div>
            <ul style={{listStyle:'none',marginBottom:20,marginTop:12}}>
              {p.items.map(item=>(
                <li key={item} style={{fontSize:13,color:'var(--text2)',padding:'5px 0',display:'flex',alignItems:'center',gap:7,borderBottom:'1px solid var(--border)'}}>
                  <span style={{color:p.color,fontWeight:800,fontSize:12}}>✓</span>{item}
                </li>
              ))}
            </ul>
            <Link href={p.href} style={{display:'block',width:'100%',padding:12,borderRadius:12,fontSize:14,fontWeight:600,textAlign:'center',textDecoration:'none',background:p.color,color:'white'}}>
              Перейти на {p.name}
            </Link>
          </div>
        ))}
      </div>

      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24}}>
        <div style={{fontSize:15,fontWeight:700,marginBottom:16,color:'var(--text)'}}>История платежей</div>
        <div style={{textAlign:'center',padding:'32px 0',color:'var(--text3)',fontSize:14}}>Платежей пока нет</div>
      </div>
    </div>
  );
}
