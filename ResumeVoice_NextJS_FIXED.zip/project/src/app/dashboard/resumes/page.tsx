'use client';
import { useState } from 'react';
import Link from 'next/link';

const resumes = [
  { id:1, title:'Менеджер по продажам', score:620, updated:'14.01.2026', created:'10.01.2026', status:'active' },
];

export default function DashboardResumes() {
  const [sharing, setSharing] = useState<number|null>(null);

  const shareResume = (channel: string, id: number) => {
    const url = encodeURIComponent(`https://resumevoice.ru/r/${id}`);
    const msg = encodeURIComponent(`Моё резюме: https://resumevoice.ru/r/${id}`);
    const urls: Record<string,string> = {
      telegram: `https://t.me/share/url?url=${msg}`,
      whatsapp: `https://wa.me/?text=${msg}`,
      vk: `https://vk.com/share.php?url=${url}`,
    };
    if (urls[channel]) window.open(urls[channel], '_blank', 'noopener');
    else navigator.clipboard.writeText(`https://resumevoice.ru/r/${id}`).then(()=>alert('Ссылка скопирована!'));
    setSharing(null);
  };

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Мои резюме</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Все созданные резюме</p></div>
        <Link href="/voice" style={{padding:'9px 20px',borderRadius:8,fontSize:13,fontWeight:600,background:'#7c3aed',color:'white',textDecoration:'none',display:'inline-flex',alignItems:'center',gap:7}}>
          <svg width="15" height="15" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Создать резюме
        </Link>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        {resumes.map(r=>(
          <div key={r.id} style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:20,padding:24,transition:'border-color .2s'}}>
            <div style={{width:44,height:44,borderRadius:12,background:'var(--purple-light)',display:'flex',alignItems:'center',justifyContent:'center',marginBottom:14}}>
              <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
            </div>
            <div style={{fontSize:16,fontWeight:700,marginBottom:4,color:'var(--text)'}}>{r.title}</div>
            <div style={{fontSize:12,color:'var(--text3)',marginBottom:14}}>Создано {r.created} · Обновлено {r.updated}</div>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16}}>
              <span style={{fontSize:13,fontWeight:700,color:'#7c3aed'}}>{r.score}/1000</span>
              <div style={{flex:1,height:5,background:'var(--bg3)',borderRadius:3,overflow:'hidden'}}><div style={{height:'100%',background:'linear-gradient(90deg,#7c3aed,#a78bfa)',borderRadius:3,width:`${r.score/10}%`}}/></div>
              <span style={{fontSize:12,fontWeight:600,color:'#d97706',background:'#fffbeb',padding:'2px 8px',borderRadius:6,border:'1px solid #fde68a'}}>Средний</span>
            </div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap',position:'relative'}}>
              <Link href="/editor" style={{padding:'7px 14px',borderRadius:8,fontSize:12,fontWeight:600,background:'#7c3aed',color:'white',textDecoration:'none'}}>Редактировать</Link>
              <Link href="/upgrade" style={{padding:'7px 14px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',textDecoration:'none'}}>Улучшить</Link>
              <button style={{padding:'7px 14px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}} onClick={()=>alert('PDF скачан')}>PDF</button>
              <button onClick={()=>setSharing(sharing===r.id?null:r.id)} style={{padding:'7px 14px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}}>
                Поделиться
              </button>
              {sharing === r.id && (
                <div style={{position:'absolute',bottom:'100%',right:0,marginBottom:6,background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:14,padding:12,boxShadow:'0 8px 32px rgba(0,0,0,.12)',zIndex:10,minWidth:200}}>
                  <div style={{fontSize:12,fontWeight:700,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:8}}>Отправить в</div>
                  {[['telegram','Telegram','#0088cc'],['whatsapp','WhatsApp','#25d366'],['vk','ВКонтакте','#4a76a8'],['copy','Скопировать ссылку','#555']].map(([ch,label,color])=>(
                    <button key={ch} onClick={()=>shareResume(ch,r.id)} style={{display:'flex',alignItems:'center',gap:10,width:'100%',padding:'9px 12px',borderRadius:8,fontSize:13,border:'none',background:'none',cursor:'pointer',fontFamily:'inherit',color:'var(--text2)',transition:'background .15s'}}
                      onMouseEnter={e=>(e.currentTarget.style.background='var(--bg2)')}
                      onMouseLeave={e=>(e.currentTarget.style.background='none')}>
                      <div style={{width:28,height:28,borderRadius:8,background:color,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                        <svg width="14" height="14" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                      </div>
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Add new card */}
        <Link href="/voice" style={{border:'2px dashed var(--border)',borderRadius:20,padding:24,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',cursor:'pointer',textDecoration:'none',minHeight:180,transition:'border-color .2s,background .2s'}}
          onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.borderColor='#7c3aed';(e.currentTarget as HTMLElement).style.background='var(--purple-light)';}}
          onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.borderColor='var(--border)';(e.currentTarget as HTMLElement).style.background='transparent';}}>
          <div style={{width:44,height:44,background:'var(--bg3)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',marginBottom:10}}>
            <svg width="22" height="22" viewBox="0 0 24 24" stroke="var(--text4)" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </div>
          <div style={{fontSize:14,fontWeight:600,color:'var(--text3)'}}>Создать резюме</div>
          <div style={{fontSize:12,color:'var(--text4)',marginTop:4}}>Недоступно на бесплатном тарифе</div>
        </Link>
      </div>
    </div>
  );
}
