'use client';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
export default function DashboardAssistant() {
  const r = useRouter();
  useEffect(()=>{ r.push('/assistant'); },[r]);
  return null;
}
