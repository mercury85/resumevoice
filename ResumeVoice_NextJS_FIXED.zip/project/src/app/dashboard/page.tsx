'use client';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';

export default function DashboardPage() {
  const { user } = useAuth();
  const name = user?.name?.split(' ')[0] || 'друг';

  const stats = [
    { label:'Резюме', value:'1', sub:'из 1 по тарифу', icon:<DocIco /> },
    { label:'Откликов', value:'0', sub:'Начните откликаться!', icon:<SendIco /> },
    { label:'Оценка резюме', value:'620', sub:'Хороший результат', icon:<StarIco /> },
    { label:'Писем', value:'1', sub:'использовано из 1', icon:<MailIco /> },
  ];

  return (
    <div>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.5px', color:'var(--text)' }}>Добрый день, {name}!</h1>
        <p style={{ fontSize:14, color:'var(--text3)', marginTop:2 }}>Вот ваш прогресс в поиске работы</p>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:24 }}>
        {stats.map((s,i) => (
          <div key={i} style={{ background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:14, padding:18 }}>
            <div style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--text3)', marginBottom:6 }}>{s.icon}{s.label}</div>
            <div style={{ fontSize:26, fontWeight:800, letterSpacing:'-1px', color:'var(--text)' }}>{s.value}</div>
            <div style={{ fontSize:12, color:'#16a34a', marginTop:3 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24 }}>
        <div style={{ background:'var(--purple-light)', border:'1.5px solid var(--purple-mid)', borderRadius:16, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8, color:'var(--text)' }}>Улучшите резюме</div>
          <div style={{ fontSize:13, color:'var(--text3)', marginBottom:14 }}>Рейтинг 620/1000. Добавьте цифры в достижения — вырастет до 840.</div>
          <Link href="/upgrade" style={{ display:'inline-flex', alignItems:'center', padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:600, background:'var(--purple-mid)', color:'#7c3aed', textDecoration:'none' }}>Улучшить</Link>
        </div>
        <div style={{ background:'#f0fdf4', border:'1.5px solid #bbf7d0', borderRadius:16, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8, color:'var(--text)' }}>Найдите вакансии</div>
          <div style={{ fontSize:13, color:'var(--text3)', marginBottom:14 }}>Перейдите на тариф Про чтобы получать до 100 вакансий в день.</div>
          <Link href="/dashboard/subscription" style={{ display:'inline-flex', alignItems:'center', padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:600, background:'#16a34a', color:'white', textDecoration:'none' }}>Улучшить тариф</Link>
        </div>
      </div>

      {/* Actions */}
      <div>
        <div style={{ fontSize:16, fontWeight:700, marginBottom:12, color:'var(--text)' }}>Быстрые действия</div>
        <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
          {[['Создать резюме','/voice'],['Найти вакансии','/vacancies'],['Тренировка собеседования','/interview'],['Мои резюме','/dashboard/resumes']].map(([l,h]) => (
            <Link key={h} href={h} style={{ display:'inline-flex', alignItems:'center', padding:'9px 18px', borderRadius:8, fontSize:13, fontWeight:500, border:'1.5px solid var(--border)', background:'var(--bg)', color:'var(--text2)', textDecoration:'none', transition:'all .15s' }}>{l}</Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function DocIco() { return <svg width="13" height="13" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>; }
function SendIco() { return <svg width="13" height="13" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>; }
function StarIco() { return <svg width="13" height="13" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>; }
function MailIco() { return <svg width="13" height="13" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>; }
