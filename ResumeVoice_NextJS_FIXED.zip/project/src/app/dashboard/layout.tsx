'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Nav from '@/components/layout/Nav';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

const sideLinks = [
  { href:'/dashboard', label:'Обзор', icon:'grid' },
  { href:'/dashboard/resumes', label:'Мои резюме', icon:'doc' },
  { href:'/dashboard/vacancies', label:'Вакансии для меня', icon:'briefcase' },
  { href:'/dashboard/applications', label:'История откликов', icon:'activity' },
  { href:'/dashboard/interviews', label:'Тренировки', icon:'users' },
  { href:'/dashboard/analytics', label:'Аналитика', icon:'chart' },
  { href:'/dashboard/assistant', label:'Ассистент', icon:'chat' },
  { sep: true, label: '' },
  { href:'/dashboard/subscription', label:'Тариф и оплата', icon:'credit' },
  { href:'/dashboard/settings', label:'Настройки', icon:'settings' },
];

function Icon({ name }: { name: string }) {
  const props = { width:16, height:16, viewBox:'0 0 24 24', stroke:'currentColor', fill:'none', strokeWidth:1.8, strokeLinecap:'round' as const, strokeLinejoin:'round' as const };
  switch(name) {
    case 'grid': return <svg {...props}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
    case 'doc': return <svg {...props}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>;
    case 'briefcase': return <svg {...props}><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>;
    case 'activity': return <svg {...props}><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>;
    case 'users': return <svg {...props}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
    case 'chart': return <svg {...props}><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
    case 'chat': return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
    case 'credit': return <svg {...props}><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>;
    case 'settings': return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>;
    case 'logout': return <svg {...props}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>;
    default: return <svg {...props}><circle cx="12" cy="12" r="10"/></svg>;
  }
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, loading, signOut } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push('/login');
  }, [user, loading, router]);

  if (loading) return <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh' }}><div style={{ width:44, height:44, border:'4px solid #f0e8ff', borderTopColor:'#7c3aed', borderRadius:'50%', animation:'spin 1s linear infinite' }} /></div>;

  return (
    <>
      <Nav active="/dashboard" />
      <div style={{ display:'flex', minHeight:'calc(100vh - 64px)' }}>
        {/* Sidebar */}
        <aside style={{ width:220, flexShrink:0, borderRight:'1.5px solid var(--border)', background:'var(--bg2)', display:'flex', flexDirection:'column', padding:'16px 10px' }}>
          {/* User info */}
          <div style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px', background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:12, marginBottom:16 }}>
            <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,#7c3aed,#a78bfa)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:800, color:'white', flexShrink:0 }}>
              {(user?.name || user?.email || 'U')[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize:13, fontWeight:700, color:'var(--text)' }}>{user?.name || user?.email?.split('@')[0] || 'Пользователь'}</div>
              <div style={{ display:'inline-block', fontSize:11, fontWeight:600, color:'#7c3aed', background:'var(--purple-light)', padding:'1px 7px', borderRadius:4, marginTop:2 }}>
                {user?.plan === 'pro' ? 'Про' : user?.plan === 'premium' ? 'Премиум' : 'Бесплатный'}
              </div>
            </div>
          </div>

          {/* Nav */}
          <div style={{ flex:1, display:'flex', flexDirection:'column', gap:2 }}>
            {sideLinks.map((l, i) => {
              if ('sep' in l && l.sep) return <div key={i} style={{ height:1, background:'var(--border)', margin:'6px 4px' }} />;
              const isActive = pathname === l.href;
              return (
                <Link key={l.href} href={l.href!}
                  style={{ display:'flex', alignItems:'center', gap:9, padding:'9px 12px', borderRadius:10, fontSize:14, textDecoration:'none', transition:'all .15s', color: isActive ? '#7c3aed' : 'var(--text3)', background: isActive ? 'var(--purple-light)' : 'transparent', fontWeight: isActive ? 600 : 400 }}>
                  <Icon name={l.icon!} />
                  {l.label}
                </Link>
              );
            })}
          </div>

          <button onClick={signOut} style={{ display:'flex', alignItems:'center', gap:9, padding:'9px 12px', borderRadius:10, fontSize:14, border:'none', background:'none', cursor:'pointer', color:'#dc2626', fontFamily:'inherit', width:'100%', textAlign:'left' }}>
            <Icon name="logout" />
            Выйти
          </button>
        </aside>

        {/* Content */}
        <main style={{ flex:1, padding:'28px 32px', overflowY:'auto', minWidth:0 }}>
          {children}
        </main>
      </div>
    </>
  );
}
