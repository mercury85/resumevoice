'use client';
import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';

export default function DashboardSettings() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [city, setCity] = useState('Москва');
  const [role, setRole] = useState('Менеджер по продажам');
  const [tgVac, setTgVac] = useState(true);
  const [emailWeekly, setEmailWeekly] = useState(false);
  const [marketing, setMarketing] = useState(false);

  const save = (what: string) => alert(`Сохранено: ${what}`);

  const Toggle = ({ v, set }: { v: boolean; set: (x:boolean)=>void }) => (
    <div onClick={()=>set(!v)} style={{position:'relative',width:40,height:22,cursor:'pointer'}}>
      <div style={{position:'absolute',inset:0,background:v?'#7c3aed':'var(--border2)',borderRadius:11,transition:'.3s'}}/>
      <div style={{position:'absolute',width:16,height:16,left:v?21:3,top:3,background:'white',borderRadius:'50%',transition:'.3s',boxShadow:'0 1px 3px rgba(0,0,0,.2)'}}/>
    </div>
  );

  const Row = ({ label, desc, children }: { label:string; desc?:string; children:React.ReactNode }) => (
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 0',borderBottom:'1px solid var(--border)'}}>
      <div><div style={{fontSize:14,fontWeight:600,color:'var(--text)'}}>{label}</div>{desc&&<div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>{desc}</div>}</div>
      {children}
    </div>
  );

  const Section = ({ title, children }: { title:string; children:React.ReactNode }) => (
    <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24,marginBottom:16}}>
      <div style={{fontSize:15,fontWeight:700,marginBottom:14,color:'var(--text)'}}>{title}</div>
      {children}
    </div>
  );

  return (
    <div>
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Настройки</h1>
        <p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Управление профилем и уведомлениями</p>
      </div>
      <Section title="Профиль">
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Имя</label>
            <input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%',padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit'}} /></div>
          <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" style={{width:'100%',padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit'}} /></div>
          <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Желаемая должность</label>
            <input value={role} onChange={e=>setRole(e.target.value)} style={{width:'100%',padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit'}} /></div>
          <div><label style={{display:'block',fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:6}}>Город</label>
            <input value={city} onChange={e=>setCity(e.target.value)} style={{width:'100%',padding:'10px 14px',border:'1.5px solid var(--border)',borderRadius:8,fontSize:14,color:'var(--text)',background:'var(--bg)',outline:'none',fontFamily:'inherit'}} /></div>
        </div>
        <button onClick={()=>save('профиль')} style={{marginTop:16,padding:'10px 24px',borderRadius:8,fontSize:13,fontWeight:600,background:'#7c3aed',color:'white',border:'none',cursor:'pointer',fontFamily:'inherit'}}>Сохранить</button>
      </Section>
      <Section title="Уведомления">
        <Row label="Вакансии в Telegram каждое утро" desc="В 9:00 список новых подходящих вакансий"><Toggle v={tgVac} set={setTgVac}/></Row>
        <Row label="Еженедельный дайджест на email" desc="Лучшие вакансии недели"><Toggle v={emailWeekly} set={setEmailWeekly}/></Row>
        <Row label="Маркетинговые письма" desc="Акции и новости сервиса"><Toggle v={marketing} set={setMarketing}/></Row>
      </Section>
      <Section title="Аккаунт">
        <Row label="Изменить пароль" desc="Только для email-авторизации">
          <button style={{padding:'7px 16px',borderRadius:8,fontSize:12,fontWeight:600,background:'var(--bg2)',color:'var(--text2)',border:'1.5px solid var(--border)',cursor:'pointer',fontFamily:'inherit'}}>Изменить</button>
        </Row>
        <Row label="Удалить аккаунт" desc="Все данные будут удалены без возможности восстановления">
          <button onClick={()=>confirm('Удалить аккаунт?')} style={{padding:'7px 16px',borderRadius:8,fontSize:12,fontWeight:600,background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca',cursor:'pointer',fontFamily:'inherit'}}>Удалить</button>
        </Row>
      </Section>
    </div>
  );
}
