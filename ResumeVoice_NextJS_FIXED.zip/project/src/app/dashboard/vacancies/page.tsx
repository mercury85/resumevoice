'use client';
import Link from 'next/link';

export default function DashboardVacancies() {
  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Вакансии для меня</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Подобраны на основе вашего резюме</p></div>
      <div style={{background:'#fffbeb',border:'1.5px solid #fde68a',borderRadius:14,padding:20,marginBottom:20,display:'flex',alignItems:'flex-start',gap:12}}>
        <svg width="20" height="20" viewBox="0 0 24 24" stroke="#d97706" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{flexShrink:0,marginTop:2}}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <div>
          <div style={{fontSize:14,fontWeight:600,color:'#d97706'}}>Нужен тариф Про</div>
          <div style={{fontSize:13,color:'var(--text2)',marginTop:4}}>Доступ к вакансиям — с тарифа Про (699 руб/мес). Получайте до 100 подходящих вакансий .</div>
          <Link href="/dashboard/subscription" style={{display:'inline-flex',alignItems:'center',padding:'8px 16px',borderRadius:8,fontSize:13,fontWeight:600,background:'#f59e0b',color:'white',textDecoration:'none',marginTop:12}}>Перейти на Про</Link>
        </div>
      </div>
      <div style={{textAlign:'center',padding:'40px 0'}}>
        <Link href="/matching" style={{display:'inline-flex',alignItems:'center',gap:8,padding:'12px 24px',borderRadius:10,fontSize:14,fontWeight:600,background:'var(--purple-light)',color:'#7c3aed',textDecoration:'none',border:'1.5px solid var(--purple-mid)'}}>
          Посмотреть демо вакансий
        </Link>
      </div>
    </div>
  );
}
