'use client';

export default function DashboardAnalytics() {
  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Аналитика</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>Статистика поиска работы</p></div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14,marginBottom:24}}>
        {[['Просмотров резюме','0','за всё время'],['Откликов отправлено','0','за всё время'],['Приглашений получено','0','за всё время']].map(([l,v,s])=>(
          <div key={l} style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:14,padding:18}}>
            <div style={{fontSize:12,color:'var(--text3)',marginBottom:6}}>{l}</div>
            <div style={{fontSize:26,fontWeight:800,color:'var(--text)',letterSpacing:'-1px'}}>{v}</div>
            <div style={{fontSize:12,color:'var(--text4)',marginTop:3}}>{s}</div>
          </div>
        ))}
      </div>
      <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:16,padding:24,textAlign:'center'}}>
        <div style={{fontSize:14,color:'var(--text3)',marginBottom:12}}>График появится после первых откликов</div>
        <div style={{height:160,background:'var(--bg2)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',color:'var(--text4)',fontSize:13}}>Нет данных для отображения</div>
      </div>
    </div>
  );
}
