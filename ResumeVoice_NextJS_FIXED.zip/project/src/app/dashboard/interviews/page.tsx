'use client';
import Link from 'next/link';
export default function DashboardInterviews() {
  return (
    <div>
      <div style={{marginBottom:24}}><h1 style={{fontSize:22,fontWeight:800,color:'var(--text)'}}>Тренировки собеседования</h1><p style={{fontSize:13,color:'var(--text3)',marginTop:2}}>История тренировок и прогресс</p></div>
      <div style={{textAlign:'center',padding:'60px 24px',color:'var(--text4)'}}>
        <div style={{width:64,height:64,background:'var(--bg2)',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 16px'}}>
          <svg width="28" height="28" viewBox="0 0 24 24" stroke="var(--text4)" fill="none" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
        <div style={{fontSize:16,fontWeight:600,marginBottom:6,color:'var(--text3)'}}>Тренировок пока нет</div>
        <div style={{fontSize:13,marginBottom:20}}>Пройдите пробное собеседование перед реальным</div>
        <Link href="/interview" style={{display:'inline-flex',alignItems:'center',padding:'10px 24px',borderRadius:8,fontSize:14,fontWeight:600,background:'#7c3aed',color:'white',textDecoration:'none'}}>Начать тренировку</Link>
      </div>
    </div>
  );
}
