'use client';
import { useState, useRef, useEffect } from 'react';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';
import AIWidget from '@/components/ai/AIWidget';
import Link from 'next/link';

type Mode = 'voice' | 'text' | 'file';
type Step = 'input' | 'questions' | 'processing' | 'done';

const STEPS = ['Ввод данных', 'Уточнения', 'Готово'];
const STEP_KEYS: Step[] = ['input', 'questions', 'done'];

// Web Speech API types
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}

export default function VoicePage() {
  const [mode, setMode] = useState<Mode>('voice');
  const [step, setStep] = useState<Step>('input');
  const [isRec, setIsRec] = useState(false);
  const [sec, setSec] = useState(0);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [showTranscript, setShowTranscript] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [fileName, setFileName] = useState('');
  const [speechSupported, setSpeechSupported] = useState(true);
  const [answers, setAnswers] = useState(['', '', '']);
  const timerRef = useRef<NodeJS.Timeout>();
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const finalTranscriptRef = useRef('');

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) setSpeechSupported(false);
  }, []);

  const startRec = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      alert('Ваш браузер не поддерживает Web Speech API. Используйте Chrome или Edge.');
      return;
    }

    const recognition = new SR();
    recognition.lang = 'ru-RU';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    finalTranscriptRef.current = '';

    recognition.onstart = () => {
      setIsRec(true);
      setSec(0);
      setShowTranscript(false);
      setTranscript('');
      setInterimTranscript('');
      timerRef.current = setInterval(() => setSec(s => {
        if (s >= 299) { stopRec(); return s; }
        return s + 1;
      }), 1000);
    };

    recognition.onresult = (event) => {
      let interim = '';
      let final = finalTranscriptRef.current;
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += (final ? ' ' : '') + t;
          finalTranscriptRef.current = final;
        } else {
          interim += t;
        }
      }
      setTranscript(final);
      setInterimTranscript(interim);
    };

    recognition.onend = () => {
      clearInterval(timerRef.current);
      setIsRec(false);
      setInterimTranscript('');
      if (finalTranscriptRef.current.trim()) {
        setTranscript(finalTranscriptRef.current.trim());
        setShowTranscript(true);
      } else {
        setShowTranscript(false);
      }
    };

    recognition.onerror = (e) => {
      clearInterval(timerRef.current);
      setIsRec(false);
      if (e.error === 'no-speech') {
        // silently ignore
      } else if (e.error === 'not-allowed') {
        alert('Доступ к микрофону запрещён. Разрешите доступ в настройках браузера.');
      } else {
        alert(`Ошибка распознавания: ${e.error}`);
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopRec = () => {
    recognitionRef.current?.stop();
    clearInterval(timerRef.current);
    setIsRec(false);
    setSec(0);
  };

  const goNext = () => {
    if (mode === 'voice' && !showTranscript && !transcript.trim()) {
      alert('Сначала запишите голосовое сообщение'); return;
    }
    if (mode === 'text' && !textInput.trim()) { alert('Введите текст о себе'); return; }
    if (mode === 'file' && !fileName) { alert('Загрузите файл резюме'); return; }
    setStep('questions');
  };

  const goProcess = () => {
    setStep('processing');
    setTimeout(() => setStep('done'), 3500);
  };

  const fmtSec = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const stepIdx = STEP_KEYS.indexOf(step === 'processing' ? 'done' : step);

  return (
    <>
      <ScrollProgress />
      <Nav active="/voice" />
      <main style={{ minHeight: 'calc(100vh - 64px)', background: 'var(--bg2)' }}>

        {/* ── HERO ── */}
        <section style={{
          background: 'linear-gradient(135deg, #4c1d95 0%, #7c3aed 50%, #6d28d9 100%)',
          padding: '64px 24px 56px',
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
        }}>
          {/* Decorative blobs */}
          <div style={{ position:'absolute', top:-80, right:-80, width:300, height:300, borderRadius:'50%', background:'rgba(255,255,255,.06)', pointerEvents:'none' }} />
          <div style={{ position:'absolute', bottom:-60, left:-60, width:200, height:200, borderRadius:'50%', background:'rgba(255,255,255,.04)', pointerEvents:'none' }} />

          <div style={{ position:'relative', zIndex:1 }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              background: 'rgba(255,255,255,.15)', backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255,255,255,.25)',
              color: 'white', fontSize: 12, fontWeight: 700, letterSpacing: '.08em',
              textTransform: 'uppercase', padding: '6px 16px', borderRadius: 100, marginBottom: 20,
            }}>
              🎤 Создание резюме голосом
            </div>
            <h1 style={{
              fontSize: 'clamp(30px, 5vw, 52px)', fontWeight: 900,
              letterSpacing: '-2px', margin: '0 0 16px', color: 'white', lineHeight: 1.1,
            }}>
              Говорите — <span style={{ color: '#c4b5fd' }}>получайте резюме</span>
            </h1>
            <p style={{ fontSize: 18, color: 'rgba(255,255,255,.8)', maxWidth: 480, margin: '0 auto 32px', lineHeight: 1.6 }}>
              1–2 минуты о себе в свободной форме.<br />
              <strong style={{ color: 'white' }}>Готовое профессиональное резюме</strong> через 30 секунд.
            </p>

            {/* Stats row */}
            <div style={{ display: 'flex', gap: 32, justifyContent: 'center', flexWrap: 'wrap' }}>
              {[['12 400+', 'резюме создано'], ['30 сек', 'среднее время'], ['4.9★', 'средний рейтинг']].map(([v, l]) => (
                <div key={l} style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: 'white', letterSpacing: '-0.5px' }}>{v}</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,.65)', marginTop: 2 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── ПРОГРЕСС ── */}
        <div style={{ background: 'var(--bg)', borderBottom: '1px solid var(--border)', boxShadow: '0 2px 8px rgba(0,0,0,.04)' }}>
          <div style={{ maxWidth: 640, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', padding: '0 24px' }}>
            {STEPS.map((s, i) => {
              const done = stepIdx > i;
              const active = stepIdx === i;
              return (
                <div key={s} style={{
                  padding: '18px 8px', textAlign: 'center',
                  borderBottom: `3px solid ${active ? '#7c3aed' : done ? '#a78bfa' : 'transparent'}`,
                  transition: 'border-color .3s',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                    <div style={{
                      width: 26, height: 26, borderRadius: '50%',
                      background: active ? '#7c3aed' : done ? '#ede9fe' : 'var(--bg2)',
                      border: `2px solid ${active ? '#7c3aed' : done ? '#a78bfa' : 'var(--border)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, transition: 'all .3s',
                    }}>
                      {done
                        ? <svg width="12" height="12" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                        : <span style={{ fontSize: 12, fontWeight: 700, color: active ? '#fff' : 'var(--text4)' }}>{i + 1}</span>
                      }
                    </div>
                    <span style={{ fontSize: 13, fontWeight: active ? 700 : 400, color: active ? '#7c3aed' : done ? '#7c3aed' : 'var(--text4)', transition: 'color .3s' }}>{s}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── КОНТЕНТ ── */}
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '40px 24px 80px' }}>

          {/* STEP 1: INPUT */}
          {step === 'input' && (
            <div style={{ animation: 'fadeUp .35s ease both' }}>

              {/* Табы режимов */}
              <div style={{
                display: 'flex', gap: 0, background: 'var(--bg)', borderRadius: 14,
                border: '1.5px solid var(--border)', overflow: 'hidden', marginBottom: 28,
                boxShadow: '0 2px 8px rgba(0,0,0,.04)',
              }}>
                {([['voice', '🎤 Голосом'], ['text', '✏️ Текстом'], ['file', '📄 Загрузить файл']] as [Mode, string][]).map(([m, label]) => (
                  <button key={m} onClick={() => setMode(m)} style={{
                    flex: 1, padding: '13px 12px', fontSize: 13, fontWeight: mode === m ? 700 : 400,
                    border: 'none', borderRight: '1px solid var(--border)',
                    background: mode === m ? '#7c3aed' : 'transparent',
                    color: mode === m ? 'white' : 'var(--text3)', cursor: 'pointer',
                    fontFamily: 'inherit', transition: 'all .2s',
                  }}>
                    {label}
                  </button>
                ))}
              </div>

              {/* ГОЛОСОВОЙ режим */}
              {mode === 'voice' && (
                <div>
                  {!speechSupported && (
                    <div style={{ background: '#fef3c7', border: '1.5px solid #fcd34d', borderRadius: 12, padding: '12px 16px', marginBottom: 16, fontSize: 13, color: '#92400e' }}>
                      ⚠️ Ваш браузер не поддерживает распознавание речи. Используйте <strong>Chrome</strong> или <strong>Edge</strong>, либо введите текст вручную.
                    </div>
                  )}
                  <div style={{
                    background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 24,
                    padding: '48px 32px', textAlign: 'center',
                    boxShadow: '0 4px 24px rgba(124,58,237,.08)',
                  }}>
                    {/* MIC BUTTON */}
                    <div style={{ position: 'relative', width: 160, height: 160, margin: '0 auto' }}>
                      {isRec && [-20, -38, -56].map((inset, i) => (
                        <div key={i} style={{
                          position: 'absolute', inset: inset,
                          borderRadius: '50%', border: `2px solid rgba(220,38,38,.${18 - i * 5})`,
                          animation: `mrp 2.5s ease-in-out ${i * 0.6}s infinite`, pointerEvents: 'none',
                        }} />
                      ))}
                      <button
                        onClick={isRec ? stopRec : startRec}
                        disabled={!speechSupported}
                        aria-label={isRec ? 'Остановить запись' : 'Начать запись'}
                        style={{
                          position: 'relative', zIndex: 2, width: 160, height: 160, borderRadius: '50%',
                          background: isRec
                            ? 'linear-gradient(145deg,#f87171,#dc2626)'
                            : speechSupported
                              ? 'linear-gradient(145deg,#8b5cf6,#7c3aed)'
                              : '#aaa',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          border: 'none', cursor: speechSupported ? 'pointer' : 'not-allowed',
                          boxShadow: isRec
                            ? '0 0 0 6px rgba(220,38,38,.12), 0 20px 60px rgba(220,38,38,.35)'
                            : '0 0 0 6px rgba(124,58,237,.12), 0 20px 60px rgba(124,58,237,.35)',
                          transition: 'transform .2s, box-shadow .2s',
                        }}
                        onMouseEnter={e => speechSupported && !isRec && ((e.currentTarget as HTMLElement).style.transform = 'scale(1.04)')}
                        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.transform = 'scale(1)')}
                      >
                        {isRec
                          ? <svg width="52" height="52" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="4" width="4" height="16" rx="1" /><rect x="14" y="4" width="4" height="16" rx="1" /></svg>
                          : <svg width="58" height="58" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
                            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                            <line x1="12" y1="19" x2="12" y2="23" />
                            <line x1="8" y1="23" x2="16" y2="23" />
                          </svg>
                        }
                      </button>
                    </div>

                    {/* Волны */}
                    {isRec && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 3, height: 32, margin: '20px auto 8px', justifyContent: 'center' }}>
                        {[6, 18, 28, 10, 32, 22, 8, 26, 14, 6, 20, 30].map((h, i) => (
                          <div key={i} style={{ width: 3, height: h, borderRadius: 3, background: '#ef4444', animation: `wvs 1.1s ${i * 0.08}s ease-in-out infinite` }} />
                        ))}
                      </div>
                    )}

                    {/* Таймер */}
                    {isRec && (
                      <div style={{ fontSize: 36, fontWeight: 900, color: '#dc2626', letterSpacing: '-2px', marginTop: 4 }}>{fmtSec(sec)}</div>
                    )}

                    {/* Промежуточный транскрипт */}
                    {isRec && (interimTranscript || transcript) && (
                      <div style={{ marginTop: 16, background: 'var(--bg2)', borderRadius: 12, padding: '12px 16px', textAlign: 'left', fontSize: 13, color: 'var(--text2)', lineHeight: 1.6, maxHeight: 120, overflowY: 'auto' }}>
                        <span style={{ color: 'var(--text)' }}>{transcript}</span>
                        <span style={{ color: 'var(--text4)' }}>{interimTranscript}</span>
                      </div>
                    )}

                    {/* Подпись */}
                    <div style={{ marginTop: isRec ? 16 : 36, fontSize: 18, fontWeight: 700, color: 'var(--text)', lineHeight: 1.4 }}>
                      {isRec ? '🔴 Слушаю — говорите свободно!' : showTranscript ? '✅ Отлично, записано!' : 'Нажмите и расскажите о себе'}
                    </div>
                    {!isRec && !showTranscript && (
                      <div style={{ fontSize: 14, color: 'var(--text3)', marginTop: 10, lineHeight: 1.7 }}>
                        Расскажите: где работали, что умеете, чего хотите<br />
                        <span style={{ fontSize: 12, color: 'var(--text4)', background: 'var(--bg2)', padding: '4px 10px', borderRadius: 6, display: 'inline-block', marginTop: 6 }}>
                          «Работал менеджером 3 года, умею вести переговоры, ищу удалённую работу...»
                        </span>
                      </div>
                    )}

                    {/* Транскрипт */}
                    {showTranscript && (
                      <div style={{ background: 'var(--bg2)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 20, marginTop: 24, textAlign: 'left' }}>
                        <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: '#7c3aed', marginBottom: 10 }}>
                          📝 Распознанный текст (можно отредактировать)
                        </div>
                        <div
                          contentEditable
                          suppressContentEditableWarning
                          onInput={e => setTranscript((e.currentTarget as HTMLElement).innerText)}
                          style={{ fontSize: 14, color: 'var(--text)', lineHeight: 1.7, outline: 'none', minHeight: 60, whiteSpace: 'pre-wrap' }}
                        >
                          {transcript}
                        </div>
                        <div style={{ display: 'flex', gap: 10, marginTop: 16, flexWrap: 'wrap' }}>
                          <button
                            onClick={() => { setShowTranscript(false); setTranscript(''); setInterimTranscript(''); setSec(0); finalTranscriptRef.current = ''; }}
                            style={{ padding: '9px 18px', borderRadius: 9, fontSize: 13, fontWeight: 600, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text2)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}
                          >
                            🔄 Записать снова
                          </button>
                          <button
                            onClick={goNext}
                            style={{ flex: 1, minWidth: 160, padding: '9px 24px', borderRadius: 9, fontSize: 14, fontWeight: 700, border: 'none', background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 4px 14px rgba(124,58,237,.35)', transition: 'all .15s' }}
                          >
                            Создать резюме →
                          </button>
                        </div>
                      </div>
                    )}

                    {!isRec && !showTranscript && speechSupported && (
                      <div style={{ marginTop: 24, display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
                        <div style={{ fontSize: 12, color: 'var(--text4)', display: 'flex', alignItems: 'center', gap: 5 }}>
                          <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
                          Web Speech API · только Chrome/Edge · русский язык
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ТЕКСТОВЫЙ режим */}
              {mode === 'text' && (
                <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 20, padding: 28, boxShadow: '0 4px 24px rgba(0,0,0,.05)' }}>
                  <label style={{ display: 'block', fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 10 }}>
                    Расскажите о себе в свободной форме
                  </label>
                  <div style={{ fontSize: 12, color: 'var(--text4)', marginBottom: 12 }}>
                    Где работали, что умеете, каких результатов достигли, что ищете
                  </div>
                  <textarea
                    value={textInput}
                    onChange={e => setTextInput(e.target.value)}
                    rows={9}
                    placeholder="Последние 3 года работал продавцом-консультантом в крупной розничной сети. До этого год работал на складе логистической компании. Умею общаться с людьми, знаю 1С и Excel на базовом уровне. Хочу найти работу менеджера по работе с клиентами с зарплатой от 60 000 рублей, предпочтительно с возможностью удалённой работы..."
                    style={{ width: '100%', padding: '14px 16px', border: '1.5px solid var(--border)', borderRadius: 12, fontSize: 14, color: 'var(--text)', background: 'var(--bg2)', outline: 'none', resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.7, boxSizing: 'border-box', transition: 'border-color .15s' }}
                    onFocus={e => e.target.style.borderColor = '#7c3aed'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, marginBottom: 18 }}>
                    <span style={{ fontSize: 12, color: textInput.length >= 200 ? '#16a34a' : 'var(--text4)' }}>
                      {textInput.length} символов {textInput.length < 200 ? `· ещё ${200 - textInput.length} для хорошего резюме` : '· отлично!'}
                    </span>
                    {textInput.length > 0 && (
                      <div style={{ height: 4, width: 80, background: 'var(--border)', borderRadius: 4, overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${Math.min(100, textInput.length / 2)}%`, background: textInput.length >= 200 ? '#16a34a' : '#7c3aed', borderRadius: 4, transition: 'width .3s' }} />
                      </div>
                    )}
                  </div>
                  <button
                    onClick={goNext}
                    style={{ width: '100%', padding: 15, borderRadius: 12, fontSize: 15, fontWeight: 700, border: 'none', background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 6px 20px rgba(124,58,237,.3)', transition: 'all .15s' }}
                  >
                    Создать резюме →
                  </button>
                </div>
              )}

              {/* ФАЙЛ режим */}
              {mode === 'file' && (
                <div>
                  <div
                    onClick={() => document.getElementById('fileIn')?.click()}
                    style={{ border: '2px dashed #c4b5fd', borderRadius: 20, padding: '64px 32px', textAlign: 'center', cursor: 'pointer', transition: 'all .2s', background: 'var(--bg)' }}
                    onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = '#7c3aed'; el.style.background = 'var(--purple-light)'; }}
                    onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = '#c4b5fd'; el.style.background = 'var(--bg)'; }}
                  >
                    <div style={{ width: 72, height: 72, background: 'var(--purple-light)', border: '1.5px solid #c4b5fd', borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px', boxShadow: '0 4px 16px rgba(124,58,237,.12)' }}>
                      <svg width="34" height="34" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
                      </svg>
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, color: 'var(--text)' }}>{fileName || 'Загрузите своё резюме'}</div>
                    <div style={{ fontSize: 14, color: 'var(--text3)', marginBottom: 6 }}>Перетащите файл или нажмите для выбора</div>
                    <div style={{ fontSize: 12, color: 'var(--text4)', background: 'var(--bg2)', display: 'inline-block', padding: '4px 12px', borderRadius: 100 }}>PDF, DOCX, DOC, TXT — до 10 МБ</div>
                  </div>
                  <input id="fileIn" type="file" accept=".pdf,.docx,.doc,.txt" style={{ display: 'none' }}
                    onChange={e => { if (e.target.files?.[0]) { setFileName(e.target.files[0].name); setTimeout(goNext, 500); } }} />
                </div>
              )}

              {mode !== 'voice' && (
                <div style={{ textAlign: 'center', marginTop: 16 }}>
                  <button
                    onClick={() => setMode('voice')}
                    style={{ padding: '8px 18px', borderRadius: 100, fontSize: 12, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}
                  >
                    🎤 Попробовать голосом →
                  </button>
                </div>
              )}

              {/* Преимущества внизу */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginTop: 32 }}>
                {[
                  ['🤖', 'ИИ-форматирование', 'Чистая структура без ошибок'],
                  ['⚡', '30 секунд', 'Быстрее любого конструктора'],
                  ['📥', 'PDF + DOCX', 'Скачать в любом формате'],
                ].map(([icon, title, desc]) => (
                  <div key={title} style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 14, padding: '16px 14px', textAlign: 'center' }}>
                    <div style={{ fontSize: 24, marginBottom: 6 }}>{icon}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', marginBottom: 4 }}>{title}</div>
                    <div style={{ fontSize: 11, color: 'var(--text4)' }}>{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: QUESTIONS */}
          {step === 'questions' && (
            <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 20, padding: 32, animation: 'fadeUp .35s ease both', boxShadow: '0 4px 24px rgba(0,0,0,.05)' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 14px', borderRadius: 100, fontSize: 12, fontWeight: 600, background: 'var(--purple-light)', color: '#7c3aed', border: '1px solid #c4b5fd', marginBottom: 20 }}>
                ✨ Несколько уточняющих вопросов
              </div>
              <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)', marginBottom: 6, letterSpacing: '-0.5px' }}>Расскажите немного больше</h2>
              <p style={{ fontSize: 14, color: 'var(--text3)', marginBottom: 24, lineHeight: 1.5 }}>Это сделает ваше резюме сильнее. Все вопросы необязательны.</p>
              {[
                ['Каких результатов удалось достичь?', 'Например: продажи выросли на 30%, выполнял план каждый месяц...'],
                ['Какой был размер команды/проектов?', 'Работал один / было 5 человек, я был старшим / проекты на 10+ млн'],
                ['Какую работу ищете сейчас?', 'Хочу вырасти до руководителя / ищу удалённую работу / смена сферы'],
              ].map(([q, ph], i) => (
                <div key={i} style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 8, color: 'var(--text)' }}>{q}</div>
                  <input
                    value={answers[i]}
                    onChange={e => { const a = [...answers]; a[i] = e.target.value; setAnswers(a); }}
                    placeholder={ph}
                    style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, fontSize: 14, color: 'var(--text)', background: 'var(--bg2)', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', transition: 'border-color .15s' }}
                    onFocus={e => e.target.style.borderColor = '#7c3aed'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'}
                  />
                </div>
              ))}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 8 }}>
                <button
                  onClick={goProcess}
                  style={{ flex: 1, minWidth: 160, padding: '14px 20px', borderRadius: 12, fontSize: 15, fontWeight: 700, border: 'none', background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 6px 20px rgba(124,58,237,.3)', transition: 'all .15s' }}>
                  ✨ Создать резюме
                </button>
                <button
                  onClick={goProcess}
                  style={{ padding: '14px 20px', borderRadius: 12, fontSize: 13, fontWeight: 500, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  Пропустить
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PROCESSING */}
          {step === 'processing' && (
            <div style={{ textAlign: 'center', padding: '60px 0', animation: 'fadeUp .35s ease both' }}>
              <div style={{ width: 88, height: 88, borderRadius: '50%', background: 'var(--purple-light)', border: '1.5px solid #c4b5fd', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px', position: 'relative' }}>
                <div style={{ position: 'absolute', inset: -4, borderRadius: '50%', border: '3px solid transparent', borderTopColor: '#7c3aed', animation: 'spin 1s linear infinite' }} />
                <svg width="36" height="36" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" />
                  <line x1="16" y1="13" x2="8" y2="13" /><line x1="16" y1="17" x2="8" y2="17" />
                </svg>
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-.5px', marginBottom: 8, color: 'var(--text)' }}>Создаю резюме...</div>
              <div style={{ fontSize: 14, color: 'var(--text3)', marginBottom: 36 }}>Обычно занимает 10–20 секунд</div>
              <div style={{ maxWidth: 260, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[
                  ['Анализирую ваш опыт', 'done'],
                  ['Выделяю ключевые навыки', 'cur'],
                  ['Формирую структуру резюме', ''],
                  ['Готовлю PDF и DOCX файлы', ''],
                ].map(([l, s], i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 14, color: s === 'done' ? '#16a34a' : s === 'cur' ? 'var(--text)' : 'var(--text4)', fontWeight: s === 'cur' ? 600 : 400 }}>
                    <div style={{ width: 28, height: 28, borderRadius: '50%', background: s === 'done' ? '#f0fdf4' : s === 'cur' ? 'var(--purple-light)' : 'var(--bg2)', border: `1.5px solid ${s === 'done' ? '#bbf7d0' : s === 'cur' ? '#c4b5fd' : 'var(--border)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {s === 'done'
                        ? <svg width="13" height="13" viewBox="0 0 24 24" stroke="#16a34a" fill="none" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                        : s === 'cur'
                          ? <div style={{ width: 9, height: 9, borderRadius: '50%', background: '#7c3aed', animation: 'recpulse .9s ease-in-out infinite' }} />
                          : <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--border)' }} />
                      }
                    </div>
                    {l}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 4: DONE */}
          {step === 'done' && (
            <div style={{ textAlign: 'center', animation: 'fadeUp .35s ease both' }}>
              <div style={{ width: 88, height: 88, borderRadius: '50%', background: '#f0fdf4', border: '2px solid #bbf7d0', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px' }}>
                <svg width="40" height="40" viewBox="0 0 24 24" stroke="#16a34a" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
              </div>
              <h2 style={{ fontSize: 28, fontWeight: 900, letterSpacing: '-1px', marginBottom: 10, color: 'var(--text)' }}>Резюме готово! 🎉</h2>
              <p style={{ fontSize: 15, color: 'var(--text3)', marginBottom: 32, lineHeight: 1.6, maxWidth: 380, margin: '0 auto 32px' }}>
                Откройте редактор, чтобы просмотреть, отредактировать и скачать в PDF или DOCX.
              </p>
              <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
                <Link href="/editor" style={{ display: 'inline-flex', alignItems: 'center', gap: 9, padding: '14px 32px', borderRadius: 12, fontSize: 15, fontWeight: 700, background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', textDecoration: 'none', boxShadow: '0 8px 28px rgba(124,58,237,.35)', transition: 'all .15s' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                  Открыть резюме
                </Link>
                <button
                  onClick={() => { setStep('input'); setShowTranscript(false); setTranscript(''); setSec(0); finalTranscriptRef.current = ''; }}
                  style={{ padding: '14px 24px', borderRadius: 12, fontSize: 14, fontWeight: 500, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text2)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  Создать ещё одно
                </button>
              </div>
              <div style={{ marginTop: 28, padding: '18px 24px', background: 'var(--purple-light)', border: '1.5px solid #c4b5fd', borderRadius: 16, display: 'inline-flex', alignItems: 'center', gap: 14 }}>
                <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
                <span style={{ fontSize: 14, color: '#6d28d9' }}>Хотите сразу найти подходящие вакансии?</span>
                <Link href="/vacancies" style={{ fontSize: 13, fontWeight: 700, color: '#7c3aed', textDecoration: 'none', whiteSpace: 'nowrap', padding: '6px 14px', background: 'white', borderRadius: 8, border: '1px solid #c4b5fd' }}>
                  Найти вакансии →
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
      <AIWidget />
      <style>{`
        @keyframes mrp{0%,100%{opacity:.4;transform:scale(1)}50%{opacity:.8;transform:scale(1.04)}}
        @keyframes recpulse{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}
        @keyframes wvs{0%,100%{transform:scaleY(.15);opacity:.25}50%{transform:scaleY(1);opacity:1}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
        button:hover{opacity:.88}
        a:hover{opacity:.88}
      `}</style>
    </>
  );
}
