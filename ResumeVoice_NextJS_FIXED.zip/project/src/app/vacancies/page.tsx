'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';
import AIWidget from '@/components/ai/AIWidget';
import {
  TV_ALL_REGIONS, TV_REGIONS_BY_FO,
  TV_INDUSTRIES, TV_SOCIAL_GROUPS, TV_EXPERIENCE_RANGES,
  TV_EMPLOYMENT_TYPES, TV_SCHEDULES, TV_EDUCATION_LEVELS,
  type TVVacancy,
} from '@/lib/trudvsem';

function fmtDate(s: string) {
  if (!s) return '';
  try { return new Date(s).toLocaleDateString('ru', { day: 'numeric', month: 'short' }); }
  catch { return ''; }
}
function plural(n: number, one: string, few: string, many: string) {
  const m = n % 100;
  if (m >= 11 && m <= 14) return many;
  const r = n % 10;
  if (r === 1) return one;
  if (r >= 2 && r <= 4) return few;
  return many;
}

const FO_ORDER = ['ЦФО', 'СЗФО', 'ЮФО', 'СКФО', 'ПФО', 'УФО', 'СФО', 'ДФО'];
const FO_NAMES: Record<string, string> = {
  'ЦФО': 'Центральный ФО', 'СЗФО': 'Северо-Западный ФО', 'ЮФО': 'Южный ФО',
  'СКФО': 'Северо-Кавказский ФО', 'ПФО': 'Приволжский ФО', 'УФО': 'Уральский ФО',
  'СФО': 'Сибирский ФО', 'ДФО': 'Дальневосточный ФО',
};

function CustomSelect({ value, onChange, options, placeholder = 'Выберите...' }: {
  value: string; onChange: (v: string) => void;
  options: { value: string; label: string }[]; placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const label = options.find(o => o.value === value)?.label ?? placeholder;
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button type="button" onClick={() => setOpen(o => !o)}
        style={{ width: '100%', padding: '10px 14px', border: `1.5px solid ${open ? '#7c3aed' : 'var(--border)'}`, borderRadius: 9, fontSize: 13, color: value ? 'var(--text)' : 'var(--text4)', background: 'var(--bg)', outline: 'none', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'border-color .15s' }}>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{label}</span>
        <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" style={{ flexShrink: 0, marginLeft: 6, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}><polyline points="6 9 12 15 18 9" /></svg>
      </button>
      {open && (
        <div style={{ position: 'absolute', top: 'calc(100% + 5px)', left: 0, right: 0, background: 'var(--bg)', border: '1.5px solid #c4b5fd', borderRadius: 11, zIndex: 100, boxShadow: '0 8px 32px rgba(0,0,0,.14)', maxHeight: 220, overflowY: 'auto' }}>
          {options.map(o => (
            <div key={o.value} onClick={() => { onChange(o.value); setOpen(false); }}
              style={{ padding: '9px 14px', fontSize: 13, cursor: 'pointer', color: value === o.value ? '#7c3aed' : 'var(--text)', background: value === o.value ? 'var(--purple-light)' : 'transparent', transition: 'background .1s', fontWeight: value === o.value ? 600 : 400 }}>
              {o.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SalarySlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const min = 0, max = 300000, step = 5000;
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 12, color: '#7c3aed', fontWeight: 600 }}>{value > 0 ? 'от ' + value.toLocaleString('ru') + ' ₽' : 'любая'}</span>
        <span style={{ fontSize: 12, color: 'var(--text4)' }}>{max.toLocaleString('ru')} ₽</span>
      </div>
      <div style={{ position: 'relative', height: 20, display: 'flex', alignItems: 'center' }}>
        <div style={{ position: 'absolute', left: 0, right: 0, height: 4, borderRadius: 4, background: 'var(--border)' }} />
        <div style={{ position: 'absolute', left: 0, width: `${pct}%`, height: 4, borderRadius: 4, background: '#7c3aed' }} />
        <input type="range" min={min} max={max} step={step} value={value} onChange={e => onChange(Number(e.target.value))}
          style={{ position: 'absolute', left: 0, right: 0, width: '100%', opacity: 0, height: 20, cursor: 'pointer', margin: 0 }} />
        <div style={{ position: 'absolute', left: `${pct}%`, transform: 'translateX(-50%)', width: 18, height: 18, borderRadius: '50%', background: '#7c3aed', border: '3px solid white', boxShadow: '0 2px 8px rgba(124,58,237,.4)', pointerEvents: 'none' }} />
      </div>
    </div>
  );
}

function Checkbox({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer', fontSize: 13, color: 'var(--text2)', userSelect: 'none', padding: '4px 0' }}>
      <div onClick={() => onChange(!checked)}
        style={{ width: 20, height: 20, borderRadius: 6, border: `2px solid ${checked ? '#7c3aed' : 'var(--border)'}`, background: checked ? '#7c3aed' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all .15s', cursor: 'pointer' }}>
        {checked && <svg width="11" height="11" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>}
      </div>
      {label}
    </label>
  );
}

const IcoSearch = () => <svg width="15" height="15" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>;
const IcoPin = () => <svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>;
const IcoHeart = ({ filled }: { filled: boolean }) => <svg width="16" height="16" viewBox="0 0 24 24" stroke={filled ? 'none' : 'currentColor'} fill={filled ? '#7c3aed' : 'none'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" /></svg>;
const IcoBuilding = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="18" rx="2" /><path d="M7 8h4M7 12h4M7 16h4M13 8h4M13 12h4" />
  </svg>
);

export default function VacanciesPage() {
  const [text, setText] = useState('');
  const [regionCode, setRegionCode] = useState('');
  const [regionSearch, setRegionSearch] = useState('');
  const [regionOpen, setRegionOpen] = useState(false);
  const [industry, setIndustry] = useState('');
  const [socialProtected, setSocialProtected] = useState('');
  const [expRange, setExpRange] = useState('');
  const [employmentType, setEmploymentType] = useState('');
  const [schedule, setSchedule] = useState('');
  const [education, setEducation] = useState('');
  const [salaryFrom, setSalaryFrom] = useState(0);
  const [accommodation, setAccommodation] = useState(false);
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [withSalary, setWithSalary] = useState(false);
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<TVVacancy[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [saved, setSaved] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [error, setError] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const regionRef = useRef<HTMLDivElement>(null);
  const LIMIT = 20;

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (regionRef.current && !regionRef.current.contains(e.target as Node)) setRegionOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const doSearch = useCallback(async (pg = 0) => {
    setLoading(true); setError('');
    try {
      const expObj = TV_EXPERIENCE_RANGES.find(r => r.label === expRange);
      const params = new URLSearchParams();
      if (text) params.set('text', text);
      if (regionCode) params.set('regionCode', regionCode);
      if (industry) params.set('industry', industry);
      if (socialProtected) params.set('social_protected', socialProtected);
      if (accommodation) params.set('accommodation', '1');
      if (salaryFrom > 0) params.set('salary', String(salaryFrom));
      if (expObj?.from != null) params.set('experienceFrom', String(expObj.from));
      if (expObj?.to != null) params.set('experienceTo', String(expObj.to));
      params.set('limit', String(LIMIT));
      params.set('offset', String(pg * LIMIT));
      const res = await fetch(`/api/vacancies?${params}`);
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Ошибка API');

      let result = json.data.items as TVVacancy[];

      // Client-side filters (these fields aren't filterable via API)
      if (remoteOnly) {
        result = result.filter(v =>
          v.isRemote ||
          (v.schedule || '').toLowerCase().includes('удал') ||
          (v.employment || '').toLowerCase().includes('удал')
        );
      }
      if (withSalary) {
        result = result.filter(v => v.salaryFrom || v.salaryTo);
      }
      if (employmentType) {
        result = result.filter(v => (v.employment || '').includes(employmentType));
      }
      if (schedule) {
        result = result.filter(v => (v.schedule || '').includes(schedule));
      }
      if (education) {
        result = result.filter(v => (v.education || '').includes(education));
      }

      setItems(result);
      setTotal(result.length < LIMIT ? pg * LIMIT + result.length : json.data.total);
      setPage(pg);
      setExpanded(new Set());
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Ошибка загрузки');
    } finally {
      setLoading(false);
    }
  }, [text, regionCode, industry, socialProtected, accommodation, salaryFrom, expRange, remoteOnly, withSalary, employmentType, schedule, education]);

  useEffect(() => { doSearch(0); }, []);

  const reset = () => {
    setText(''); setRegionCode(''); setRegionSearch(''); setIndustry('');
    setSocialProtected(''); setExpRange(''); setSalaryFrom(0); setAccommodation(false);
    setRemoteOnly(false); setWithSalary(false); setEmploymentType(''); setSchedule(''); setEducation('');
    setTimeout(() => doSearch(0), 0);
  };

  const toggleSave = (id: string) => setSaved(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleExpand = (id: string) => setExpanded(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const totalPages = Math.ceil(total / LIMIT);
  const selectedRegion = TV_ALL_REGIONS.find(r => r.code === regionCode);
  const filteredRegions = regionSearch ? TV_ALL_REGIONS.filter(r => r.name.toLowerCase().includes(regionSearch.toLowerCase())) : null;

  // Count active filters
  const activeFilterCount = [regionCode, industry, socialProtected, expRange, employmentType, schedule, education].filter(Boolean).length
    + (salaryFrom > 0 ? 1 : 0) + (accommodation ? 1 : 0) + (remoteOnly ? 1 : 0) + (withSalary ? 1 : 0);

  const FilterSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 14, padding: '14px 16px' }}>
      <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 10 }}>{title}</label>
      {children}
    </div>
  );

  return (
    <>
      <ScrollProgress />
      <Nav active="/vacancies" />
      <main>
        {/* Шапка */}
        <div style={{ padding: '36px 40px 24px', background: 'var(--bg)', borderBottom: '1px solid var(--border)' }}>
          <div style={{ maxWidth: 1160, margin: '0 auto' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', marginBottom: 20 }}>
              <div>
                <h1 style={{ fontSize: 'clamp(20px, 3vw, 30px)', fontWeight: 800, letterSpacing: '-1px', color: 'var(--text)', margin: '0 0 4px' }}>
                  Вакансии по всей России
                </h1>
                <p style={{ fontSize: 14, color: 'var(--text3)', margin: 0 }}>
                  База trudvsem.ru — Государственный портал «Работа в России»
                </p>
              </div>
              {/* Quick toggles */}
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button onClick={() => { setRemoteOnly(!remoteOnly); }}
                  style={{ padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, border: `1.5px solid ${remoteOnly ? '#7c3aed' : 'var(--border)'}`, background: remoteOnly ? 'var(--purple-light)' : 'var(--bg)', color: remoteOnly ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  🏠 Удалённая работа
                </button>
                <button onClick={() => { setWithSalary(!withSalary); }}
                  style={{ padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, border: `1.5px solid ${withSalary ? '#7c3aed' : 'var(--border)'}`, background: withSalary ? 'var(--purple-light)' : 'var(--bg)', color: withSalary ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  💰 С указанной зарплатой
                </button>
                <button onClick={() => { setAccommodation(!accommodation); }}
                  style={{ padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, border: `1.5px solid ${accommodation ? '#7c3aed' : 'var(--border)'}`, background: accommodation ? 'var(--purple-light)' : 'var(--bg)', color: accommodation ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  🏡 С жильём
                </button>
              </div>
            </div>
            {/* Поисковая строка */}
            <div style={{ display: 'flex', gap: 10, maxWidth: 800 }}>
              <div style={{ flex: 1, position: 'relative' }}>
                <div style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', color: 'var(--text4)', pointerEvents: 'none' }}>
                  <IcoSearch />
                </div>
                <input value={text} onChange={e => setText(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && doSearch(0)}
                  placeholder="Должность, профессия, навык, компания..."
                  style={{ width: '100%', padding: '12px 14px 12px 40px', border: '1.5px solid var(--border)', borderRadius: 10, fontSize: 14, color: 'var(--text)', background: 'var(--bg2)', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', transition: 'border-color .15s' }}
                  onFocus={e => e.target.style.borderColor = '#7c3aed'}
                  onBlur={e => e.target.style.borderColor = 'var(--border)'}
                />
              </div>
              {/* Region quick select */}
              <div ref={regionRef} style={{ position: 'relative', width: 200, flexShrink: 0 }}>
                <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text4)', pointerEvents: 'none' }}>
                  <IcoPin />
                </div>
                <button type="button" onClick={() => setRegionOpen(o => !o)}
                  style={{ width: '100%', height: '100%', padding: '12px 14px 12px 32px', border: `1.5px solid ${regionOpen ? '#7c3aed' : 'var(--border)'}`, borderRadius: 10, fontSize: 13, color: regionCode ? 'var(--text)' : 'var(--text4)', background: 'var(--bg2)', outline: 'none', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'border-color .15s' }}>
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 13 }}>
                    {selectedRegion ? selectedRegion.name : 'Вся Россия'}
                  </span>
                  <svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2.5" style={{ flexShrink: 0, marginLeft: 4 }}><polyline points="6 9 12 15 18 9" /></svg>
                </button>
                {regionOpen && (
                  <div style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, background: 'var(--bg)', border: '1.5px solid #c4b5fd', borderRadius: 12, zIndex: 200, boxShadow: '0 8px 32px rgba(0,0,0,.14)', overflow: 'hidden' }}>
                    <div style={{ padding: '8px 10px', borderBottom: '1px solid var(--border)' }}>
                      <input value={regionSearch} onChange={e => setRegionSearch(e.target.value)}
                        placeholder="Поиск региона..."
                        style={{ width: '100%', padding: '7px 10px', border: '1.5px solid var(--border)', borderRadius: 8, fontSize: 13, color: 'var(--text)', background: 'var(--bg2)', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box' }}
                        autoFocus />
                    </div>
                    <div style={{ maxHeight: 280, overflowY: 'auto' }}>
                      <div onClick={() => { setRegionCode(''); setRegionSearch(''); setRegionOpen(false); }}
                        style={{ padding: '9px 14px', fontSize: 13, cursor: 'pointer', color: !regionCode ? '#7c3aed' : 'var(--text)', background: !regionCode ? 'var(--purple-light)' : 'transparent', fontWeight: !regionCode ? 600 : 400 }}>
                        Вся Россия
                      </div>
                      {filteredRegions
                        ? filteredRegions.map(r => (
                          <div key={r.code} onClick={() => { setRegionCode(r.code); setRegionSearch(''); setRegionOpen(false); }}
                            style={{ padding: '9px 14px', fontSize: 13, cursor: 'pointer', color: regionCode === r.code ? '#7c3aed' : 'var(--text)', background: regionCode === r.code ? 'var(--purple-light)' : 'transparent' }}>
                            {r.name}
                          </div>
                        ))
                        : FO_ORDER.filter(fo => TV_REGIONS_BY_FO[fo]).map(fo => (
                          <div key={fo}>
                            <div style={{ padding: '5px 14px 3px', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--text4)', background: 'var(--bg2)', borderTop: '1px solid var(--border)' }}>
                              {FO_NAMES[fo]}
                            </div>
                            {TV_REGIONS_BY_FO[fo].map(r => (
                              <div key={r.code} onClick={() => { setRegionCode(r.code); setRegionOpen(false); }}
                                style={{ padding: '8px 14px 8px 20px', fontSize: 13, cursor: 'pointer', color: regionCode === r.code ? '#7c3aed' : 'var(--text)', background: regionCode === r.code ? 'var(--purple-light)' : 'transparent' }}>
                                {r.name}
                              </div>
                            ))}
                          </div>
                        ))
                      }
                    </div>
                  </div>
                )}
              </div>
              <button onClick={() => doSearch(0)} disabled={loading}
                style={{ padding: '12px 28px', borderRadius: 10, fontSize: 14, fontWeight: 700, border: 'none', background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', cursor: loading ? 'default' : 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0, transition: 'all .15s', opacity: loading ? .7 : 1, boxShadow: '0 4px 14px rgba(124,58,237,.3)' }}>
                <IcoSearch /> Найти
              </button>
            </div>
          </div>
        </div>

        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px 24px', display: 'grid', gridTemplateColumns: '280px 1fr', gap: 24, minHeight: 'calc(100vh - 220px)' }}>

          {/* ══ ФИЛЬТРЫ ══ */}
          <aside style={{ display: 'flex', flexDirection: 'column', gap: 10, alignSelf: 'start', position: 'sticky', top: 80, maxHeight: 'calc(100vh - 100px)', overflowY: 'auto', paddingBottom: 16, paddingRight: 4 }}>

            <FilterSection title="Сфера деятельности">
              <CustomSelect value={industry} onChange={setIndustry}
                options={TV_INDUSTRIES.map(i => ({ value: i.value, label: i.label }))}
                placeholder="Все сферы" />
            </FilterSection>

            <FilterSection title="Тип занятости">
              <CustomSelect value={employmentType} onChange={setEmploymentType}
                options={TV_EMPLOYMENT_TYPES}
                placeholder="Любой тип" />
            </FilterSection>

            <FilterSection title="График работы">
              <CustomSelect value={schedule} onChange={setSchedule}
                options={TV_SCHEDULES}
                placeholder="Любой график" />
            </FilterSection>

            <FilterSection title="Опыт работы">
              <CustomSelect value={expRange} onChange={setExpRange}
                options={TV_EXPERIENCE_RANGES.map(r => ({ value: r.label, label: r.label }))}
                placeholder="Любой опыт" />
            </FilterSection>

            <FilterSection title="Образование">
              <CustomSelect value={education} onChange={setEducation}
                options={TV_EDUCATION_LEVELS}
                placeholder="Любое образование" />
            </FilterSection>

            <FilterSection title="Зарплата от">
              <SalarySlider value={salaryFrom} onChange={setSalaryFrom} />
            </FilterSection>

            <FilterSection title="Категория соискателя">
              <CustomSelect value={socialProtected} onChange={setSocialProtected}
                options={TV_SOCIAL_GROUPS.map(g => ({ value: g.value, label: g.label }))}
                placeholder="Все категории" />
            </FilterSection>

            <FilterSection title="Дополнительно">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <Checkbox checked={remoteOnly} onChange={setRemoteOnly} label="Только удалённая работа" />
                <Checkbox checked={withSalary} onChange={setWithSalary} label="Только с зарплатой" />
                <Checkbox checked={accommodation} onChange={setAccommodation} label="Предоставляется жильё" />
              </div>
            </FilterSection>

            <button onClick={() => doSearch(0)} disabled={loading}
              style={{ padding: '12px', borderRadius: 10, fontSize: 14, fontWeight: 700, border: 'none', background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', cursor: loading ? 'default' : 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, opacity: loading ? .75 : 1, transition: 'all .15s', boxShadow: '0 4px 16px rgba(124,58,237,.3)' }}>
              {loading
                ? <><div style={{ width: 14, height: 14, border: '2px solid rgba(255,255,255,.4)', borderTopColor: 'white', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />Ищем...</>
                : <><IcoSearch />Применить фильтры</>
              }
            </button>
            {activeFilterCount > 0 && (
              <button onClick={reset}
                style={{ padding: '9px', borderRadius: 10, fontSize: 13, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                ✕ Сбросить фильтры ({activeFilterCount})
              </button>
            )}
          </aside>

          {/* ══ РЕЗУЛЬТАТЫ ══ */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
              <div style={{ fontSize: 14, color: 'var(--text3)' }}>
                {loading ? 'Загружаем вакансии...' : error ? '' : (
                  <span>Найдено <strong style={{ color: 'var(--text)', fontSize: 15 }}>{total.toLocaleString('ru')}</strong>{' '}
                    {plural(total, 'вакансия', 'вакансии', 'вакансий')}
                    {selectedRegion ? ` · ${selectedRegion.name}` : ' · по всей России'}
                    {remoteOnly ? ' · удалённая' : ''}
                    {withSalary ? ' · с зарплатой' : ''}
                  </span>
                )}
              </div>
              {!loading && totalPages > 1 && (
                <div style={{ fontSize: 12, color: 'var(--text4)', background: 'var(--bg2)', padding: '4px 10px', borderRadius: 6 }}>Страница {page + 1} из {totalPages}</div>
              )}
            </div>

            {error && (
              <div style={{ background: '#fef2f2', border: '1.5px solid #fecaca', borderRadius: 14, padding: 20, marginBottom: 16 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#dc2626', marginBottom: 4 }}>Ошибка загрузки</div>
                <div style={{ fontSize: 13, color: '#555', marginBottom: 10 }}>{error}</div>
                <button onClick={() => doSearch(0)} style={{ padding: '7px 16px', borderRadius: 7, fontSize: 13, fontWeight: 600, background: '#dc2626', color: 'white', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>Повторить</button>
              </div>
            )}

            {loading && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 14, padding: 20, height: 110, position: 'relative', overflow: 'hidden' }}>
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg,transparent,var(--bg2),transparent)', backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite linear' }} />
                  </div>
                ))}
              </div>
            )}

            {!loading && !error && items.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {items.map((v, idx) => {
                  const isSaved = saved.has(v.id);
                  const isOpen = expanded.has(v.id);
                  return (
                    <article key={v.id}
                      style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 14, padding: '18px 20px', transition: 'all .2s', animation: `fadeUp .3s ease ${idx * 0.03}s both` }}
                      onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#c4b5fd'; el.style.boxShadow = '0 4px 20px rgba(124,58,237,.07)'; }}
                      onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = 'var(--border)'; el.style.boxShadow = 'none'; }}
                    >
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                        <div style={{ width: 48, height: 48, borderRadius: 12, background: 'var(--purple-light)', border: '1.5px solid #e9e3ff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <IcoBuilding />
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {v.title}
                          </div>
                          <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8, flexWrap: 'wrap' }}>
                            {v.company && <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text2)' }}>{v.company}</span>}
                            {v.city && <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 12, color: 'var(--text3)' }}><IcoPin />{v.city}</span>}
                            {v.publishedAt && <span style={{ fontSize: 11, color: 'var(--text4)' }}>{fmtDate(v.publishedAt)}</span>}
                          </div>
                          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 12 }}>
                            {v.experience && <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: 'var(--bg2)', color: 'var(--text3)', border: '1px solid var(--border)' }}>📅 {v.experience}</span>}
                            {v.employment && <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: 'var(--bg2)', color: 'var(--text3)', border: '1px solid var(--border)' }}>{v.employment}</span>}
                            {v.schedule && v.schedule !== v.employment && <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: 'var(--bg2)', color: 'var(--text3)', border: '1px solid var(--border)' }}>{v.schedule}</span>}
                            {(v.isRemote || (v.schedule || '').toLowerCase().includes('удал')) && (
                              <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: '#eff9ff', color: '#0055a5', border: '1px solid #bae6fd' }}>🏠 Удалённо</span>
                            )}
                            {v.education && <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: 'var(--bg2)', color: 'var(--text3)', border: '1px solid var(--border)' }}>🎓 {v.education}</span>}
                            {v.accommodation && <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' }}>🏡 Жильё</span>}
                          </div>
                          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                            <a href={v.url} target="_blank" rel="noopener noreferrer"
                              style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 18px', borderRadius: 8, fontSize: 13, fontWeight: 600, background: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', color: 'white', textDecoration: 'none', transition: 'all .15s', boxShadow: '0 2px 8px rgba(124,58,237,.25)' }}>
                              Откликнуться
                            </a>
                            {v.description && (
                              <button onClick={() => toggleExpand(v.id)}
                                style={{ padding: '8px 14px', borderRadius: 8, fontSize: 13, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                                {isOpen ? 'Скрыть' : 'Подробнее'}
                              </button>
                            )}
                            <button onClick={() => toggleSave(v.id)}
                              style={{ padding: '8px 12px', borderRadius: 8, fontSize: 13, border: `1.5px solid ${isSaved ? '#c4b5fd' : 'var(--border)'}`, background: isSaved ? 'var(--purple-light)' : 'var(--bg)', color: isSaved ? '#7c3aed' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                              <IcoHeart filled={isSaved} />
                            </button>
                          </div>
                        </div>
                        <div style={{ textAlign: 'right', flexShrink: 0 }}>
                          <div style={{ fontSize: 15, fontWeight: 700, color: v.salaryFrom ? '#16a34a' : 'var(--text)', whiteSpace: 'nowrap' }}>{v.salary}</div>
                          {v.source && <div style={{ fontSize: 10, color: 'var(--text4)', marginTop: 4 }}>{v.source}</div>}
                        </div>
                      </div>
                      {isOpen && (
                        <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)' }}>
                          {v.description && (
                            <div>
                              <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--text3)', marginBottom: 6 }}>Обязанности</div>
                              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.7, whiteSpace: 'pre-line' }}>{v.description.replace(/<[^>]+>/g, '')}</div>
                            </div>
                          )}
                          {(v.contactName || v.contactEmail || v.contactPhone) && (
                            <div style={{ marginTop: 14, padding: '12px 14px', background: 'var(--bg2)', borderRadius: 10 }}>
                              <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--text3)', marginBottom: 8 }}>Контакты</div>
                              <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                                {v.contactName && <span style={{ fontSize: 13, color: 'var(--text2)' }}>{v.contactName}</span>}
                                {v.contactPhone && <a href={`tel:${v.contactPhone}`} style={{ fontSize: 13, color: '#7c3aed', textDecoration: 'none' }}>{v.contactPhone}</a>}
                                {v.contactEmail && <a href={`mailto:${v.contactEmail}`} style={{ fontSize: 13, color: '#7c3aed', textDecoration: 'none' }}>{v.contactEmail}</a>}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            )}

            {!loading && !error && items.length === 0 && (
              <div style={{ textAlign: 'center', padding: '60px 24px', background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 16 }}>
                <div style={{ width: 64, height: 64, borderRadius: 16, background: 'var(--purple-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                  <svg width="28" height="28" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
                </div>
                <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 8, color: 'var(--text)' }}>Вакансий не найдено</div>
                <div style={{ fontSize: 14, color: 'var(--text3)', marginBottom: 20 }}>Попробуйте изменить регион или убрать часть фильтров</div>
                <button onClick={reset} style={{ padding: '10px 24px', borderRadius: 8, fontSize: 14, fontWeight: 600, background: '#7c3aed', color: 'white', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>
                  Сбросить фильтры
                </button>
              </div>
            )}

            {!loading && !error && totalPages > 1 && (
              <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 28, flexWrap: 'wrap' }}>
                <button onClick={() => doSearch(0)} disabled={page === 0}
                  style={{ padding: '8px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page === 0 ? 'default' : 'pointer', fontFamily: 'inherit', fontSize: 12, opacity: page === 0 ? .4 : 1 }}>«</button>
                <button onClick={() => doSearch(Math.max(0, page - 1))} disabled={page === 0}
                  style={{ padding: '8px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page === 0 ? 'default' : 'pointer', fontFamily: 'inherit', fontSize: 12, opacity: page === 0 ? .4 : 1 }}>‹</button>
                {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                  const start = Math.max(0, Math.min(page - 3, totalPages - 7));
                  return start + i;
                }).map(p => (
                  <button key={p} onClick={() => doSearch(p)}
                    style={{ width: 36, height: 36, borderRadius: 8, border: `1.5px solid ${page === p ? '#7c3aed' : 'var(--border)'}`, background: page === p ? '#7c3aed' : 'var(--bg)', color: page === p ? 'white' : 'var(--text3)', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13, fontWeight: page === p ? 700 : 400, transition: 'all .15s' }}>
                    {p + 1}
                  </button>
                ))}
                <button onClick={() => doSearch(Math.min(totalPages - 1, page + 1))} disabled={page === totalPages - 1}
                  style={{ padding: '8px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page === totalPages - 1 ? 'default' : 'pointer', fontFamily: 'inherit', fontSize: 12, opacity: page === totalPages - 1 ? .4 : 1 }}>›</button>
                <button onClick={() => doSearch(totalPages - 1)} disabled={page === totalPages - 1}
                  style={{ padding: '8px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg)', color: 'var(--text3)', cursor: page === totalPages - 1 ? 'default' : 'pointer', fontFamily: 'inherit', fontSize: 12, opacity: page === totalPages - 1 ? .4 : 1 }}>»</button>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <AIWidget />
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:0;height:0}
        input[type=range]::-moz-range-thumb{width:0;height:0;border:none}
        @media(max-width:900px){
          main > div:last-child { grid-template-columns: 1fr !important; }
          aside { position: static !important; max-height: none !important; }
        }
      `}</style>
    </>
  );
}
