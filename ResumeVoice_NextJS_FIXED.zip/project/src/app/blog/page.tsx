import Nav from '@/components/layout/Nav';
import Footer from '@/components/layout/Footer';
import ScrollProgress from '@/components/layout/ScrollProgress';
import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Блог — советы по резюме и поиску работы',
  description: 'Полезные статьи о составлении резюме, подготовке к собеседованию и поиску работы в России.',
};

const IconPen    = () => <svg width="20" height="20" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>;
const IconClock  = () => <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>;
const IconTag    = () => <svg width="13" height="13" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>;
const IconArrow  = () => <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>;

const POSTS = [
  {
    slug: 'kak-sostavit-rezyume',
    category: 'Резюме', categoryColor: '#7c3aed',
    title: 'Как составить резюме которое заметят: полное руководство 2025',
    desc: 'Разбираем структуру, формулировки достижений и типичные ошибки. С примерами для разных профессий.',
    date: '12 июня 2025', read: '8 мин',
    featured: true,
  },
  {
    slug: 'golosovoe-rezyume',
    category: 'Голосовое резюме', categoryColor: '#059669',
    title: 'Голосовое резюме: почему это работает лучше чем писать текст',
    desc: 'Речь раскрывает то что сложно передать на бумаге. Как подготовиться к записи за 5 минут.',
    date: '8 июня 2025', read: '5 мин',
    featured: true,
  },
  {
    slug: 'sobesedovanie-top-voprosy',
    category: 'Собеседование', categoryColor: '#d97706',
    title: '25 вопросов на которые нужно готовиться перед собеседованием',
    desc: 'HR задаёт одни и те же вопросы в 90% компаний. Готовые ответы и стратегии для каждого.',
    date: '3 июня 2025', read: '12 мин',
    featured: false,
  },
  {
    slug: 'zarplata-peregovory',
    category: 'Карьера', categoryColor: '#0891b2',
    title: 'Как обсуждать зарплату: скрипты и примеры фраз',
    desc: 'Когда называть цифру, как отвечать на «какие у вас зарплатные ожидания» и как не продешевить.',
    date: '29 мая 2025', read: '7 мин',
    featured: false,
  },
  {
    slug: 'soprovitelnoe-pismo',
    category: 'Резюме', categoryColor: '#7c3aed',
    title: 'Сопроводительное письмо которое не выбросят в корзину',
    desc: 'Структура, длина, тон. Примеры хороших и плохих писем с разбором каждого абзаца.',
    date: '22 мая 2025', read: '6 мин',
    featured: false,
  },
  {
    slug: 'udalennaya-rabota',
    category: 'Поиск работы', categoryColor: '#dc2626',
    title: 'Удалённая работа в 2025: где искать и как выделиться',
    desc: 'Лучшие площадки, особенности резюме для удалёнки и советы по прохождению онлайн-собеседований.',
    date: '15 мая 2025', read: '9 мин',
    featured: false,
  },
];

export default function BlogPage() {
  const featured = POSTS.filter(p => p.featured);
  const rest     = POSTS.filter(p => !p.featured);

  return (
    <>
      <ScrollProgress />
      <Nav active="/blog" />
      <main>
        {/* Hero */}
        <section style={{ padding:'52px 48px 40px', background:'var(--bg)', borderBottom:'1px solid var(--border)' }}>
          <div style={{ maxWidth:960, margin:'0 auto' }}>
            <div style={{ display:'inline-flex', alignItems:'center', gap:7, background:'var(--purple-light)', color:'#7c3aed', fontSize:11, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', padding:'5px 14px', borderRadius:100, marginBottom:16 }}>
              <IconPen /> Блог
            </div>
            <h1 style={{ fontSize:'clamp(26px,4vw,42px)', fontWeight:800, letterSpacing:'-1.5px', color:'var(--text)', margin:'0 0 10px', lineHeight:1.1 }}>
              Советы по резюме и<br /><span style={{ color:'#7c3aed' }}>поиску работы</span>
            </h1>
            <p style={{ fontSize:16, color:'var(--text3)', margin:0, maxWidth:500, lineHeight:1.6 }}>
              Практические статьи от экспертов по карьере. Без воды — только то что работает.
            </p>
          </div>
        </section>

        <section style={{ padding:'40px 48px 80px', maxWidth:960+96, margin:'0 auto' }}>

          {/* Главные статьи */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:32 }}>
            {featured.map(p => (
              <Link key={p.slug} href={`/blog/${p.slug}`}
                style={{ textDecoration:'none', display:'block', background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:20, padding:28, transition:'all .2s', overflow:'hidden', position:'relative' }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor='#c4b5fd'; el.style.boxShadow='0 8px 32px rgba(124,58,237,.1)'; el.style.transform='translateY(-2px)'; }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor='var(--border)'; el.style.boxShadow='none'; el.style.transform='none'; }}
              >
                <div style={{ display:'inline-flex', alignItems:'center', gap:5, background:`${p.categoryColor}18`, color:p.categoryColor, fontSize:11, fontWeight:700, padding:'3px 10px', borderRadius:20, marginBottom:14, border:`1px solid ${p.categoryColor}30` }}>
                  <IconTag /> {p.category}
                </div>
                <h2 style={{ fontSize:18, fontWeight:700, color:'var(--text)', marginBottom:10, lineHeight:1.3, letterSpacing:'-.3px' }}>{p.title}</h2>
                <p style={{ fontSize:13, color:'var(--text3)', lineHeight:1.6, marginBottom:16 }}>{p.desc}</p>
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:12, fontSize:12, color:'var(--text4)' }}>
                    <span style={{ display:'flex', alignItems:'center', gap:4 }}><IconClock />{p.read}</span>
                    <span>{p.date}</span>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:4, fontSize:13, fontWeight:600, color:'#7c3aed' }}>
                    Читать <IconArrow />
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Остальные статьи */}
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {rest.map(p => (
              <Link key={p.slug} href={`/blog/${p.slug}`}
                style={{ textDecoration:'none', display:'flex', alignItems:'center', gap:20, background:'var(--bg)', border:'1.5px solid var(--border)', borderRadius:16, padding:'20px 24px', transition:'all .2s' }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor='#c4b5fd'; el.style.boxShadow='0 4px 16px rgba(124,58,237,.08)'; }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor='var(--border)'; el.style.boxShadow='none'; }}
              >
                <div style={{ width:48, height:48, borderRadius:14, background:'var(--purple-light)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, border:'1.5px solid #e9e3ff' }}>
                  <IconPen />
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'inline-flex', alignItems:'center', gap:4, background:`${p.categoryColor}18`, color:p.categoryColor, fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:20, marginBottom:6, border:`1px solid ${p.categoryColor}30` }}>
                    {p.category}
                  </div>
                  <div style={{ fontSize:15, fontWeight:700, color:'var(--text)', marginBottom:4, letterSpacing:'-.2px' }}>{p.title}</div>
                  <div style={{ fontSize:13, color:'var(--text3)', lineHeight:1.5, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.desc}</div>
                </div>
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ fontSize:12, color:'var(--text4)', marginBottom:4 }}>{p.read}</div>
                  <div style={{ fontSize:11, color:'var(--text4)' }}>{p.date}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
