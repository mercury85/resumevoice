'use client';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type Theme = 'light' | 'dark';
type Lang = 'ru' | 'en';

interface ThemeCtx {
  theme: Theme;
  lang: Lang;
  toggleTheme: () => void;
  toggleLang: () => void;
  t: (key: string) => string;
}

const i18n: Record<Lang, Record<string, string>> = {
  ru: {
    'nav.create': 'Создать резюме',
    'nav.improve': 'Улучшить резюме',
    'nav.vac': 'Вакансии',
    'nav.match': 'Подбор работы',
    'nav.prices': 'Цены',
    'nav.blog': 'Блог',
    'nav.contact': 'Контакты',
    'nav.cabinet': 'Кабинет',
    'nav.login': 'Войти',
    'nav.start': 'Начать бесплатно',
  },
  en: {
    'nav.create': 'Create Resume',
    'nav.improve': 'Improve Resume',
    'nav.vac': 'Jobs',
    'nav.match': 'Job Matching',
    'nav.prices': 'Pricing',
    'nav.blog': 'Blog',
    'nav.contact': 'Contact',
    'nav.cabinet': 'Dashboard',
    'nav.login': 'Log in',
    'nav.start': 'Get started free',
  },
};

const Ctx = createContext<ThemeCtx>({
  theme: 'light', lang: 'ru',
  toggleTheme: () => {}, toggleLang: () => {},
  t: (k) => k,
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Always start with 'light' to match SSR, then update after mount
  const [theme, setTheme] = useState<Theme>('light');
  const [lang, setLang] = useState<Lang>('ru');

  useEffect(() => {
    // Read saved values after mount (client-only)
    const savedTheme = localStorage.getItem('rvTheme') as Theme;
    const savedLang = localStorage.getItem('rvLang') as Lang;
    if (savedTheme === 'dark') {
      setTheme('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
    }
    if (savedLang === 'en') setLang('en');
  }, []);

  const toggleTheme = () => {
    const next: Theme = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    localStorage.setItem('rvTheme', next);
    document.documentElement.setAttribute('data-theme', next);
  };

  const toggleLang = () => {
    const next: Lang = lang === 'ru' ? 'en' : 'ru';
    setLang(next);
    localStorage.setItem('rvLang', next);
  };

  const t = (key: string) => i18n[lang][key] ?? key;

  return (
    <Ctx.Provider value={{ theme, lang, toggleTheme, toggleLang, t }}>
      {children}
    </Ctx.Provider>
  );
}

export const useTheme = () => useContext(Ctx);
