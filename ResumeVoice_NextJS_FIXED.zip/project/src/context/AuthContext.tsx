'use client';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

interface User {
  id: string; email?: string; phone?: string;
  name?: string; plan: 'free' | 'pro' | 'premium';
  planExpiresAt?: string;
}

interface AuthCtx { user: User | null; loading: boolean; signOut: () => void; }

const Ctx = createContext<AuthCtx>({ user: null, loading: false, signOut: () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // В продакшне: Supabase auth.getSession()
    // Пока: localStorage
    const saved = localStorage.getItem('rvUser');
    if (saved) {
      try { setUser(JSON.parse(saved)); } catch {}
    }
    setLoading(false);
  }, []);

  const signOut = () => {
    localStorage.removeItem('rvUser');
    setUser(null);
    window.location.href = '/';
  };

  return <Ctx.Provider value={{ user, loading, signOut }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
