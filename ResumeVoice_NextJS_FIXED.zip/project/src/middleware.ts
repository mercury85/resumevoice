/**
 * Next.js Middleware — Edge Runtime.
 * Запускается перед каждым запросом на сервере (не Node.js, а Edge).
 *
 * ВАЖНО: Edge Runtime не поддерживает Node.js модули (crypto, fs и т.д.).
 * Здесь используется только Web Crypto API (globalThis.crypto),
 * который доступен везде: Edge, Node 18+, браузер.
 */
import { NextRequest, NextResponse } from 'next/server';

const COOKIE_NAME  = 'rv_admin_session';
const LOGIN_PAGE   = '/admin/login';
const ADMIN_PREFIX = '/admin';
const API_ADMIN    = '/api/admin';

// ── Побитовое сравнение строк без утечки времени (аналог timingSafeEqual) ──
function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

// ── HMAC-SHA256 через Web Crypto (Edge-совместимо) ───────────────────────────
async function verifyHmac(data: string, sig: string, secret: string): Promise<boolean> {
  try {
    const enc = new TextEncoder();
    const key = await globalThis.crypto.subtle.importKey(
      'raw',
      enc.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const rawSig  = await globalThis.crypto.subtle.sign('HMAC', key, enc.encode(data));
    const b64Sig  = btoa(Array.from(new Uint8Array(rawSig), b => String.fromCharCode(b)).join(''))
      .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, ''); // base64url
    return constantTimeEqual(sig, b64Sig);
  } catch {
    return false;
  }
}

// ── JWT verify (только проверка подписи + exp, без сторонних библиотек) ──────
async function verifyJwt(token: string, secret: string): Promise<boolean> {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    const [header, body, sig] = parts;

    // Проверяем подпись
    if (!(await verifyHmac(`${header}.${body}`, sig, secret))) return false;

    // Декодируем payload
    const json    = atob(body.replace(/-/g, '+').replace(/_/g, '/'));
    const payload = JSON.parse(json) as Record<string, unknown>;

    // Проверяем срок действия и роль
    if (typeof payload.exp === 'number' && Date.now() / 1000 > payload.exp) return false;
    if (payload.role !== 'admin') return false;

    return true;
  } catch {
    return false;
  }
}

// ── Security headers ──────────────────────────────────────────────────────────
function securityHeaders(res: NextResponse, isAdmin = false): NextResponse {
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(self), geolocation=()');
  if (isAdmin) {
    res.headers.set('X-Robots-Tag', 'noindex, nofollow');
    res.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  }
  return res;
}

// ── Главный обработчик ────────────────────────────────────────────────────────
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Страница логина — всегда доступна
  if (pathname === LOGIN_PAGE || pathname.startsWith(`${LOGIN_PAGE}/`)) {
    return securityHeaders(NextResponse.next(), true);
  }

  // Эндпоинты авторизации — всегда доступны
  if (
    pathname.startsWith(`${API_ADMIN}/auth`) ||
    pathname.startsWith(`${API_ADMIN}/session`)
  ) {
    return NextResponse.next();
  }

  const isAdminPage = pathname.startsWith(ADMIN_PREFIX);
  const isAdminApi  = pathname.startsWith(API_ADMIN);

  if (isAdminPage || isAdminApi) {
    const token  = req.cookies.get(COOKIE_NAME)?.value ?? '';
    const secret = process.env.JWT_SECRET ?? '';

    // JWT_SECRET должен быть минимум 32 символа
    const valid = token && secret.length >= 32
      ? await verifyJwt(token, secret)
      : false;

    if (!valid) {
      if (isAdminApi) {
        return new NextResponse(
          JSON.stringify({ ok: false, error: 'Unauthorized' }),
          { status: 401, headers: { 'Content-Type': 'application/json' } }
        );
      }
      const url = req.nextUrl.clone();
      url.pathname = LOGIN_PAGE;
      url.searchParams.set('from', pathname);
      return NextResponse.redirect(url);
    }

    return securityHeaders(NextResponse.next(), true);
  }

  return securityHeaders(NextResponse.next());
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon\\.ico|logo\\.png|og-image\\.png|apple-touch-icon\\.png|site\\.webmanifest|icon\\.svg).*)',
  ],
};
