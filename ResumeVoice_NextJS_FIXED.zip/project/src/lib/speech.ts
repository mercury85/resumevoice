/**
 * Голосовое распознавание — только серверная сторона (SaluteSpeech).
 */
import crypto from 'crypto';

let _speechToken: string | null = null;
let _speechTokenExp = 0;

async function getSpeechToken(): Promise<string> {
  if (_speechToken && Date.now() < _speechTokenExp - 60_000) return _speechToken;

  if (process.env.SPEECH_TOKEN) {
    _speechToken = process.env.SPEECH_TOKEN;
    _speechTokenExp = Date.now() + 30 * 60 * 1000;
    return _speechToken;
  }

  const creds = Buffer.from(
    `${process.env.SPEECH_CLIENT_ID}:${process.env.SPEECH_CLIENT_SECRET}`
  ).toString('base64');

  const res = await fetch('https://ngw.devices.sberbank.ru:9443/api/v2/oauth', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${creds}`,
      RqUID: crypto.randomUUID(),
    },
    body: 'scope=SALUTE_SPEECH_PERS',
  });

  if (!res.ok) throw new Error(`SaluteSpeech auth failed: ${res.status}`);
  const j = await res.json();
  _speechToken = j.access_token;
  _speechTokenExp = j.expires_at ?? (Date.now() + 29 * 60 * 1000);
  return _speechToken!;
}

export async function transcribe(audioBuffer: Buffer): Promise<string> {
  const token = await getSpeechToken();
  const url = process.env.SPEECH_URL ?? 'https://smartspeech.sber.ru/rest/v1/speech:recognize';

  // Buffer → гарантированный ArrayBuffer без SharedArrayBuffer.
  // Копируем байты через Uint8Array в новый ArrayBuffer —
  // это работает при любом tsconfig и исключает SharedArrayBuffer.
  const tmp = new Uint8Array(audioBuffer.byteLength);
  for (let i = 0; i < audioBuffer.byteLength; i++) tmp[i] = audioBuffer[i];
  const body: ArrayBuffer = tmp.buffer;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'audio/ogg;codecs=opus',
    },
    body,
  });
  if (!res.ok) throw new Error(`Speech API error: ${res.status}`);
  const j = await res.json();
  const results: string[] = j.result ?? [];
  return results.join(' ').trim();
}

export function calcConfidence(alternatives: { text: string; confidence: number }[]): number {
  if (!alternatives.length) return 0;
  return Math.round(alternatives[0].confidence * 100);
}
