import { createClient, SupabaseClient } from '@supabase/supabase-js';

let _client: SupabaseClient | null = null;

/** Браузерный клиент (анонимный ключ). Ленивая инициализация. */
export function getSupabase(): SupabaseClient {
  if (_client) return _client;
  const url  = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anon) throw new Error('NEXT_PUBLIC_SUPABASE_URL и NEXT_PUBLIC_SUPABASE_ANON_KEY не заданы в .env.local');
  _client = createClient(url, anon);
  return _client;
}

/** Серверный клиент с bypass RLS. Только server-side. Ленивая инициализация. */
export function supabaseAdmin(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('NEXT_PUBLIC_SUPABASE_URL и SUPABASE_SERVICE_KEY не заданы в .env.local');
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

/** @deprecated Используйте getSupabase() */
export const supabase = {
  get auth()  { return getSupabase().auth; },
  get from()  { return getSupabase().from.bind(getSupabase()); },
  get storage(){ return getSupabase().storage; },
  get rpc()   { return getSupabase().rpc.bind(getSupabase()); },
};
