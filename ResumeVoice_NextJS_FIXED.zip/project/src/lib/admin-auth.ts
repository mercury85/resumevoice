/**
 * Утилиты JWT для административной авторизации.
 * Используется в:
 *   src/app/api/admin/auth/route.ts
 *   src/app/api/admin/session/route.ts
 */
import crypto from 'crypto';

// ── Timing-safe сравнение строк ───────────────────────────────────────────────
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

// ── JWT (HS256, без сторонних зависимостей) ───────────────────────────────────
export function jwtSign(payload: Record<string, unknown>, secret: string): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body   = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig    = crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

export function jwtVerify(token: string, secret: string): Record<string, unknown> | null {
  try {
    const [header, body, sig] = token.split('.');
    if (!header || !body || !sig) return null;

    const expected = crypto.createHmac('sha256', secret)
      .update(`${header}.${body}`)
      .digest('base64url');

    if (!safeEqual(sig, expected)) return null;

    const payload = JSON.parse(Buffer.from(body, 'base64url').toString()) as Record<string, unknown>;
    if (typeof payload.exp === 'number' && Date.now() / 1000 > payload.exp) return null;

    return payload;
  } catch {
    return null;
  }
}
