/**
 * Агрегатор вакансий — Труд Всем (trudvsem.ru).
 * Государственный портал «Работа в России», открытый API без токена.
 * Документация: https://trudvsem.ru/opendata/apidesc
 */

// Реэкспортируем из trudvsem для единой точки входа
export {
  searchTrudVsem,
  TV_ALL_REGIONS,
  TV_REGIONS_BY_FO,
  TV_INDUSTRIES,
  TV_SOCIAL_GROUPS,
  TV_EXPERIENCE_RANGES,
} from './trudvsem';

export type {
  TVVacancy as UnifiedVacancy,
  TVSearchFilters as SearchFilters,
  TVSearchResult as SearchResult,
} from './trudvsem';
