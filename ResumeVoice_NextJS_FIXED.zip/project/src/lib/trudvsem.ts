/**
 * Труд Всем (trudvsem.ru) — Государственный портал «Работа в России»
 * Base:  http://opendata.trudvsem.ru/api/v1
 * Auth:  НЕ ТРЕБУЕТСЯ — полностью открытый API
 * Docs:  https://trudvsem.ru/opendata/apidesc
 *
 * Полный список параметров (из документации):
 *  text            — полнотекстовый поиск
 *  limit / offset  — пагинация (макс 100 на страницу)
 *  industry        — сфера деятельности
 *  source          — источник публикации
 *  accommodation   — предоставление жилья (true/false)
 *  social_protected — группа соц. защищённости
 *  experienceFrom / experienceTo — опыт (в годах)
 *  salary          — зарплата от
 *  uzbekistan      — организованный набор (true)
 *
 * Эндпоинты:
 *  GET /vacancies
 *  GET /vacancies/region/{region_code}
 *  GET /vacancies/company/{companycode}
 *  GET /vacancies/company/inn/{inn}
 */

const TV_BASE = 'http://opendata.trudvsem.ru/api/v1';

// ── ТИПЫ ──────────────────────────────────────────────────────────────────

export interface TVVacancy {
  id: string;
  title: string;
  company: string;
  salary: string;
  salaryFrom?: number;
  salaryTo?: number;
  city: string;
  region: string;
  regionCode: string;
  experience: string;
  employment: string;
  schedule: string;
  education: string;
  accommodation: boolean;
  isRemote: boolean;
  social_protected?: string;
  description: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  publishedAt: string;
  url: string;
  source: string;
}

export interface TVSearchFilters {
  text?: string;
  regionCode?: string;      // двузначный код субъекта РФ
  industry?: string;
  source?: string;
  accommodation?: boolean;  // предоставляется жильё
  social_protected?: string;// категория соц. защиты
  experienceFrom?: number;  // опыт в годах, от
  experienceTo?: number;    // опыт в годах, до
  salary?: number;          // зарплата от
  uzbekistan?: boolean;     // организованный набор
  limit?: number;
  offset?: number;
}

export interface TVSearchResult {
  items: TVVacancy[];
  total: number;
  limit: number;
  offset: number;
}

// ── ВСЕ РЕГИОНЫ РФ (85 субъектов) ────────────────────────────────────────
// Коды = двузначные коды субъектов РФ (ОКАТО/Труд Всем)

export const TV_ALL_REGIONS: { code: string; name: string; federal: string }[] = [
  // Центральный федеральный округ
  { code:'77', name:'Москва',                        federal:'ЦФО' },
  { code:'50', name:'Московская область',            federal:'ЦФО' },
  { code:'33', name:'Владимирская область',          federal:'ЦФО' },
  { code:'36', name:'Воронежская область',           federal:'ЦФО' },
  { code:'37', name:'Ивановская область',            federal:'ЦФО' },
  { code:'40', name:'Калужская область',             federal:'ЦФО' },
  { code:'44', name:'Костромская область',           federal:'ЦФО' },
  { code:'46', name:'Курская область',               federal:'ЦФО' },
  { code:'48', name:'Липецкая область',              federal:'ЦФО' },
  { code:'57', name:'Орловская область',             federal:'ЦФО' },
  { code:'62', name:'Рязанская область',             federal:'ЦФО' },
  { code:'67', name:'Смоленская область',            federal:'ЦФО' },
  { code:'68', name:'Тамбовская область',            federal:'ЦФО' },
  { code:'69', name:'Тверская область',              federal:'ЦФО' },
  { code:'71', name:'Тульская область',              federal:'ЦФО' },
  { code:'76', name:'Ярославская область',           federal:'ЦФО' },
  { code:'32', name:'Брянская область',              federal:'ЦФО' },
  { code:'41', name:'Белгородская область',          federal:'ЦФО' },
  // Северо-Западный федеральный округ
  { code:'78', name:'Санкт-Петербург',               federal:'СЗФО' },
  { code:'47', name:'Ленинградская область',         federal:'СЗФО' },
  { code:'29', name:'Архангельская область',         federal:'СЗФО' },
  { code:'35', name:'Вологодская область',           federal:'СЗФО' },
  { code:'39', name:'Калининградская область',       federal:'СЗФО' },
  { code:'10', name:'Республика Карелия',            federal:'СЗФО' },
  { code:'11', name:'Республика Коми',               federal:'СЗФО' },
  { code:'53', name:'Новгородская область',          federal:'СЗФО' },
  { code:'60', name:'Псковская область',             federal:'СЗФО' },
  { code:'83', name:'Ненецкий АО',                   federal:'СЗФО' },
  { code:'51', name:'Мурманская область',            federal:'СЗФО' },
  // Южный федеральный округ
  { code:'23', name:'Краснодарский край',            federal:'ЮФО' },
  { code:'61', name:'Ростовская область',            federal:'ЮФО' },
  { code:'34', name:'Волгоградская область',         federal:'ЮФО' },
  { code:'30', name:'Астраханская область',          federal:'ЮФО' },
  { code:'01', name:'Республика Адыгея',             federal:'ЮФО' },
  { code:'08', name:'Республика Калмыкия',           federal:'ЮФО' },
  { code:'91', name:'Республика Крым',               federal:'ЮФО' },
  { code:'92', name:'Севастополь',                   federal:'ЮФО' },
  // Северо-Кавказский федеральный округ
  { code:'26', name:'Ставропольский край',           federal:'СКФО' },
  { code:'05', name:'Республика Дагестан',           federal:'СКФО' },
  { code:'06', name:'Республика Ингушетия',          federal:'СКФО' },
  { code:'07', name:'Кабардино-Балкарская Республика', federal:'СКФО' },
  { code:'09', name:'Карачаево-Черкесская Республика', federal:'СКФО' },
  { code:'15', name:'Республика Северная Осетия - Алания', federal:'СКФО' },
  { code:'20', name:'Чеченская Республика',          federal:'СКФО' },
  // Приволжский федеральный округ
  { code:'52', name:'Нижегородская область',         federal:'ПФО' },
  { code:'16', name:'Республика Татарстан',          federal:'ПФО' },
  { code:'63', name:'Самарская область',             federal:'ПФО' },
  { code:'02', name:'Республика Башкортостан',       federal:'ПФО' },
  { code:'59', name:'Пермский край',                 federal:'ПФО' },
  { code:'43', name:'Кировская область',             federal:'ПФО' },
  { code:'21', name:'Чувашская Республика',          federal:'ПФО' },
  { code:'13', name:'Республика Мордовия',           federal:'ПФО' },
  { code:'58', name:'Пензенская область',            federal:'ПФО' },
  { code:'64', name:'Саратовская область',           federal:'ПФО' },
  { code:'73', name:'Ульяновская область',           federal:'ПФО' },
  { code:'12', name:'Республика Марий Эл',           federal:'ПФО' },
  { code:'18', name:'Удмуртская Республика',         federal:'ПФО' },
  { code:'56', name:'Оренбургская область',          federal:'ПФО' },
  // Уральский федеральный округ
  { code:'66', name:'Свердловская область (Екатеринбург)', federal:'УФО' },
  { code:'74', name:'Челябинская область',           federal:'УФО' },
  { code:'72', name:'Тюменская область',             federal:'УФО' },
  { code:'45', name:'Курганская область',            federal:'УФО' },
  { code:'86', name:'Ханты-Мансийский АО',           federal:'УФО' },
  { code:'89', name:'Ямало-Ненецкий АО',             federal:'УФО' },
  // Сибирский федеральный округ
  { code:'54', name:'Новосибирская область',         federal:'СФО' },
  { code:'24', name:'Красноярский край',             federal:'СФО' },
  { code:'22', name:'Алтайский край',                federal:'СФО' },
  { code:'55', name:'Омская область',                federal:'СФО' },
  { code:'70', name:'Томская область',               federal:'СФО' },
  { code:'38', name:'Иркутская область',             federal:'СФО' },
  { code:'19', name:'Республика Хакасия',            federal:'СФО' },
  { code:'17', name:'Республика Тыва',               federal:'СФО' },
  { code:'04', name:'Республика Алтай',              federal:'СФО' },
  { code:'42', name:'Кемеровская область',           federal:'СФО' },
  { code:'03', name:'Республика Бурятия',            federal:'СФО' },
  // Дальневосточный федеральный округ
  { code:'27', name:'Хабаровский край',              federal:'ДФО' },
  { code:'25', name:'Приморский край',               federal:'ДФО' },
  { code:'28', name:'Амурская область',              federal:'ДФО' },
  { code:'14', name:'Республика Саха (Якутия)',      federal:'ДФО' },
  { code:'49', name:'Магаданская область',           federal:'ДФО' },
  { code:'79', name:'Еврейская АО',                  federal:'ДФО' },
  { code:'87', name:'Чукотский АО',                  federal:'ДФО' },
  { code:'65', name:'Сахалинская область',           federal:'ДФО' },
  { code:'41', name:'Камчатский край',               federal:'ДФО' },
  { code:'75', name:'Забайкальский край',            federal:'ДФО' },
];

// Сгруппированные по ФО для красивого <select>
export const TV_REGIONS_BY_FO = TV_ALL_REGIONS.reduce((acc, r) => {
  if (!acc[r.federal]) acc[r.federal] = [];
  acc[r.federal].push(r);
  return acc;
}, {} as Record<string, typeof TV_ALL_REGIONS>);

// ── КОНСТАНТЫ ФИЛЬТРОВ ────────────────────────────────────────────────────

export const TV_INDUSTRIES = [
  { value: '', label: 'Все отрасли' },
  { value: '01', label: 'Сельское хозяйство' },
  { value: '02', label: 'Лесное хозяйство' },
  { value: '05', label: 'Добыча угля' },
  { value: '06', label: 'Добыча нефти и газа' },
  { value: '08', label: 'Добыча металлических руд' },
  { value: '10', label: 'Производство пищевых продуктов' },
  { value: '11', label: 'Производство напитков' },
  { value: '13', label: 'Производство текстиля' },
  { value: '16', label: 'Обработка древесины' },
  { value: '17', label: 'Производство бумаги' },
  { value: '19', label: 'Нефтепереработка' },
  { value: '20', label: 'Химическое производство' },
  { value: '22', label: 'Производство резиновых изделий' },
  { value: '23', label: 'Производство строительных материалов' },
  { value: '24', label: 'Металлургия' },
  { value: '25', label: 'Производство металлоконструкций' },
  { value: '26', label: 'Электроника' },
  { value: '27', label: 'Электрооборудование' },
  { value: '28', label: 'Машиностроение' },
  { value: '29', label: 'Автомобилестроение' },
  { value: '33', label: 'Ремонт оборудования' },
  { value: '35', label: 'Электроэнергетика' },
  { value: '36', label: 'Водоснабжение' },
  { value: '38', label: 'Утилизация отходов' },
  { value: '41', label: 'Строительство зданий' },
  { value: '42', label: 'Строительство дорог и сетей' },
  { value: '43', label: 'Специализированное строительство' },
  { value: '45', label: 'Торговля автомобилями' },
  { value: '46', label: 'Оптовая торговля' },
  { value: '47', label: 'Розничная торговля' },
  { value: '49', label: 'Сухопутный транспорт' },
  { value: '50', label: 'Водный транспорт' },
  { value: '51', label: 'Воздушный транспорт' },
  { value: '52', label: 'Складская деятельность' },
  { value: '53', label: 'Почта и курьеры' },
  { value: '55', label: 'Гостиницы' },
  { value: '56', label: 'Общественное питание' },
  { value: '58', label: 'Издательская деятельность' },
  { value: '60', label: 'Телерадиовещание' },
  { value: '61', label: 'Телекоммуникации' },
  { value: '62', label: 'Разработка ПО, IT' },
  { value: '63', label: 'Интернет-сервисы' },
  { value: '64', label: 'Финансовые услуги' },
  { value: '65', label: 'Страхование' },
  { value: '66', label: 'Вспомогательные финансовые услуги' },
  { value: '68', label: 'Операции с недвижимостью' },
  { value: '69', label: 'Юридические услуги' },
  { value: '70', label: 'Управление компаниями' },
  { value: '71', label: 'Архитектура и инжиниринг' },
  { value: '72', label: 'Научные исследования' },
  { value: '73', label: 'Реклама и маркетинг' },
  { value: '74', label: 'Прочие профессиональные услуги' },
  { value: '75', label: 'Государственное управление' },
  { value: '77', label: 'Аренда оборудования' },
  { value: '78', label: 'Кадровые агентства' },
  { value: '79', label: 'Туризм' },
  { value: '80', label: 'Охрана и детективная деятельность' },
  { value: '81', label: 'Обслуживание зданий' },
  { value: '82', label: 'Офисные вспомогательные услуги' },
  { value: '84', label: 'Государственное управление и оборона' },
  { value: '85', label: 'Образование' },
  { value: '86', label: 'Здравоохранение' },
  { value: '87', label: 'Социальные услуги' },
  { value: '88', label: 'Услуги без проживания' },
  { value: '90', label: 'Творчество и искусство' },
  { value: '91', label: 'Библиотеки и музеи' },
  { value: '93', label: 'Спорт и развлечения' },
  { value: '94', label: 'Деятельность общественных организаций' },
  { value: '95', label: 'Ремонт компьютеров и техники' },
  { value: '96', label: 'Прочие персональные услуги' },
  { value: '97', label: 'Домашний персонал' },
];

export const TV_SOCIAL_GROUPS = [
  { value: '', label: 'Все категории' },
  { value: 'disabled', label: 'Инвалиды' },
  { value: 'young', label: 'Молодёжь (до 25 лет)' },
  { value: 'pension', label: 'Предпенсионеры' },
  { value: 'parent', label: 'Многодетные родители' },
  { value: 'vet', label: 'Ветераны' },
  { value: 'refugee', label: 'Беженцы' },
];

export const TV_EXPERIENCE_RANGES = [
  { label: 'Любой опыт', from: undefined, to: undefined },
  { label: 'Без опыта',  from: 0, to: 0 },
  { label: 'До 1 года',  from: 0, to: 1 },
  { label: '1–3 года',   from: 1, to: 3 },
  { label: '3–5 лет',    from: 3, to: 5 },
  { label: '5–10 лет',   from: 5, to: 10 },
  { label: 'Более 10 лет', from: 10, to: undefined },
];

export const TV_EMPLOYMENT_TYPES = [
  { value: '', label: 'Любой тип занятости' },
  { value: 'Полная занятость', label: 'Полная занятость' },
  { value: 'Частичная занятость', label: 'Частичная занятость' },
  { value: 'Временная работа', label: 'Временная работа' },
  { value: 'Сезонная работа', label: 'Сезонная работа' },
  { value: 'Стажировка', label: 'Стажировка' },
];

export const TV_SCHEDULES = [
  { value: '', label: 'Любой график' },
  { value: 'Полный рабочий день', label: 'Полный день' },
  { value: 'Сменный график', label: 'Сменный график' },
  { value: 'Гибкий график', label: 'Гибкий график' },
  { value: 'Удалённая работа', label: 'Удалённая работа' },
  { value: 'Вахтовый метод', label: 'Вахтовый метод' },
];

export const TV_EDUCATION_LEVELS = [
  { value: '', label: 'Любое образование' },
  { value: 'Среднее', label: 'Среднее' },
  { value: 'Среднее специальное', label: 'Среднее специальное' },
  { value: 'Высшее', label: 'Высшее' },
];

// ── ПАРСИНГ ОТВЕТА API ────────────────────────────────────────────────────

function parseSalary(vac: any): { str: string; from?: number; to?: number } {
  // API может вернуть данные в разных форматах
  const from = vac.salary?.salary_min ?? vac.payment_from ?? vac.salary_min;
  const to   = vac.salary?.salary_max ?? vac.payment_to   ?? vac.salary_max;
  if (!from && !to) return { str: 'з/п не указана' };
  const f = from ? Number(from) : undefined;
  const t = to   ? Number(to)   : undefined;
  if (f && t) return { str: `${f.toLocaleString('ru')} — ${t.toLocaleString('ru')} ₽`, from: f, to: t };
  if (f)      return { str: `от ${f.toLocaleString('ru')} ₽`, from: f };
  return       { str: `до ${t!.toLocaleString('ru')} ₽`, to: t };
}

function parseVacancy(raw: any): TVVacancy {
  // Труд Всем возвращает вакансию либо напрямую, либо в { vacancy: {...} }
  const v = raw.vacancy ?? raw;

  const sal = parseSalary(v);

  const contacts = v.contact_list ?? [];
  const emailContact = contacts.find((c: any) => c.contact_type === 'EMAIL') ?? {};
  const phoneContact = contacts.find((c: any) => c.contact_type === 'PHONE') ?? {};

  const address = Array.isArray(v.addresses?.address)
    ? v.addresses.address[0]
    : v.addresses?.address ?? {};

  return {
    id:              String(v.id ?? v['@id'] ?? Math.random()),
    title:           v.job_name ?? v.position ?? v.vacancy_name ?? 'Без названия',
    company:         v.company?.name ?? v.employer?.name ?? v.company_name ?? '',
    salary:          sal.str,
    salaryFrom:      sal.from,
    salaryTo:        sal.to,
    city:            address.location ?? v.region?.name ?? v.addresses?.city ?? '',
    region:          v.region?.name ?? '',
    regionCode:      String(v.region?.region_code ?? v.region_code ?? ''),
    experience:      v.requirement?.experience != null
                       ? `${v.requirement.experience} ${expWord(v.requirement.experience)}`
                       : '',
    employment:      v.employment ?? '',
    education:       v.requirement?.education ?? '',
    schedule:        v.schedule ?? '',
    accommodation:   Boolean(v.business_trip ?? v.accommodation),
    isRemote:        Boolean((v.schedule ?? '').toLowerCase().includes('удал') || (v.employment ?? '').toLowerCase().includes('удал')),
    social_protected:v.social_protected ?? '',
    description:     v.duty ?? v.responsibility ?? v.description ?? '',
    contactName:     v.contact_person ?? emailContact.contact_value ?? '',
    contactEmail:    emailContact.contact_value ?? v.email ?? '',
    contactPhone:    phoneContact.contact_value ?? v.phone ?? '',
    publishedAt:     v.creation_date ?? v.modified_date ?? v.published_at ?? '',
    url:             `https://trudvsem.ru/vacancy/card/${v.id ?? ''}`,
    source:          v.source ?? 'ЦЗН',
  };
}

function expWord(n: number): string {
  if (n === 0) return 'лет (без опыта)';
  if (n === 1) return 'год';
  if (n >= 2 && n <= 4) return 'года';
  return 'лет';
}

// ── ОСНОВНАЯ ФУНКЦИЯ ПОИСКА ───────────────────────────────────────────────

export async function searchTrudVsem(f: TVSearchFilters): Promise<TVSearchResult> {
  const params = new URLSearchParams();
  params.set('limit',  String(Math.min(f.limit  ?? 20, 100)));
  params.set('offset', String(f.offset ?? 0));

  if (f.text)             params.set('text',             f.text);
  if (f.industry)         params.set('industry',         f.industry);
  if (f.source)           params.set('source',           f.source);
  if (f.salary)           params.set('salary',           String(f.salary));
  if (f.accommodation)    params.set('accommodation',    'true');
  if (f.uzbekistan)       params.set('uzbekistan',       'true');
  if (f.social_protected) params.set('social_protected', f.social_protected);
  if (f.experienceFrom != null) params.set('experienceFrom', String(f.experienceFrom));
  if (f.experienceTo   != null) params.set('experienceTo',   String(f.experienceTo));

  // URL: с регионом или без
  const base = f.regionCode
    ? `${TV_BASE}/vacancies/region/${f.regionCode}`
    : `${TV_BASE}/vacancies`;

  const url = `${base}?${params}`;

  const res = await fetch(url, {
    headers: { 'User-Agent': 'ResumeVoice/1.0 (support@resumevoice.ru)' },
    next: { revalidate: 300 },
  });

  if (!res.ok) {
    throw new Error(`Труд Всем API ${res.status}: ${res.statusText}`);
  }

  const json = await res.json();

  // API может вернуть данные в разных обёртках
  const rawList: any[] =
    json.results?.vacancies ??
    json.vacancies ??
    json.items ??
    [];

  const total: number =
    json.results?.total ??
    json.meta?.total ??
    json.total ??
    rawList.length;

  return {
    items: rawList.map(parseVacancy),
    total,
    limit:  f.limit  ?? 20,
    offset: f.offset ?? 0,
  };
}
