/**
 * AI-провайдер — только серверная сторона.
 * Название провайдера не упоминается в клиентском коде.
 */
import crypto from 'crypto';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

let _token: string | null = null;
let _tokenExp = 0;

async function getToken(): Promise<string> {
  if (_token && Date.now() < _tokenExp - 60_000) return _token;

  const creds = Buffer.from(
    `${process.env.AI_CLIENT_ID}:${process.env.AI_CLIENT_SECRET}`
  ).toString('base64');

  const res = await fetch(process.env.AI_AUTH_URL!, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${creds}`,
      RqUID: crypto.randomUUID(),
    },
    body: `scope=${process.env.AI_SCOPE ?? 'GIGACHAT_API_PERS'}`,
  });

  if (!res.ok) throw new Error(`AI auth failed: ${res.status}`);
  const j = await res.json();
  _token    = j.access_token;
  _tokenExp = j.expires_at;
  return _token!;
}

export async function chat(
  messages: ChatMessage[],
  opts?: { temperature?: number; maxTokens?: number }
): Promise<string> {
  const token = await getToken();
  const res = await fetch(process.env.AI_CHAT_URL!, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      model: 'GigaChat',
      messages,
      temperature: opts?.temperature ?? 0.7,
      max_tokens: opts?.maxTokens ?? 2000,
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`AI chat error ${res.status}: ${err}`);
  }
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

// Алиас для обратной совместимости
export const aiChat = (
  messages: { role: 'user' | 'assistant' | 'system'; content: string }[],
  opts?: { temperature?: number; max_tokens?: number }
) => chat(messages, { temperature: opts?.temperature, maxTokens: opts?.max_tokens });
