import crypto from 'crypto';
import type { Plan, PaymentResult } from '@/types';

const PRICES: Record<Plan, number> = { free: 0, pro: 699, premium: 1490 };
const PLAN_NAMES: Record<Plan, string> = {
  free: 'Бесплатный тариф',
  pro: 'Тариф Про — 1 месяц',
  premium: 'Тариф Премиум — 1 месяц',
};

export async function createPayment(opts: {
  plan: Plan; userId: string; email: string; returnUrl: string;
}): Promise<PaymentResult> {
  const { plan, userId, email, returnUrl } = opts;
  const amount = PRICES[plan];
  if (!amount) throw new Error('Этот тариф бесплатный');

  const projectId = process.env.UNITPAY_PROJECT_ID ?? '';
  const secretKey = process.env.UNITPAY_SECRET_KEY ?? '';
  const publicKey = process.env.UNITPAY_PUBLIC_KEY ?? '';

  const orderId  = `${userId}_${plan}_${Date.now()}`;
  const desc     = PLAN_NAMES[plan];
  const currency = 'RUB';
  const sep      = '{up}';

  const signStr  = [amount, currency, desc, orderId, projectId, secretKey].join(sep);
  const signature = crypto.createHash('sha256').update(signStr).digest('hex');

  const params = new URLSearchParams({
    publicKey, sum: String(amount), orderId, currency, desc,
    signature, locale: 'ru', successUrl: returnUrl, backUrl: returnUrl,
    customerEmail: email,
  });

  return { paymentUrl: `https://unitpay.money/pay/${publicKey}?${params}`, paymentId: orderId };
}

// Тип для входящего вебхука UnitPay
interface UnitPayWebhook {
  method?: string;
  params?: {
    account?: string;
    date?: string;
    orderId?: string;
    payerSum?: string;
    payerCurrency?: string;
    projectId?: string;
    signature?: string;
    [key: string]: string | undefined;
  };
  signature?: string;
}

export function verifyWebhook(raw: Record<string, unknown>): boolean {
  const secretKey = process.env.UNITPAY_SECRET_KEY ?? '';
  const body = raw as UnitPayWebhook;
  const p    = body.params ?? {};

  // Подпись может лежать в root.signature или params.signature
  const sign = (body.signature ?? p.signature ?? '') as string;

  const sep = '{up}';
  const str = [
    p.account, p.date, p.orderId,
    p.payerSum, p.payerCurrency, p.projectId,
    secretKey,
  ].join(sep);

  const expected = crypto.createHash('sha256').update(str).digest('hex');
  return expected === sign;
}

export { PRICES };
