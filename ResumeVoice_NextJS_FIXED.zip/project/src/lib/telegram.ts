/**
 * Telegram Bot — отправка уведомлений пользователям.
 * Переменные окружения (в .env.local):
 *   TELEGRAM_BOT_TOKEN=123456:ABC...
 *   TELEGRAM_BOT_USERNAME=ResumeVoiceBot
 *
 * Бот НЕ использует сторонних библиотек — только Telegram Bot API напрямую.
 * Документация: https://core.telegram.org/bots/api
 */

const BOT_TOKEN = () => process.env.TELEGRAM_BOT_TOKEN ?? '';
const TG_BASE   = () => `https://api.telegram.org/bot${BOT_TOKEN()}`;

// ─── Типы ────────────────────────────────────────────────────────────────────

export interface TgMessage {
  message_id: number;
  chat: { id: number; type: string };
  text?: string;
  from?: { id: number; username?: string; first_name?: string };
}

export interface TgUpdate {
  update_id: number;
  message?: TgMessage;
  callback_query?: {
    id: string;
    from: { id: number; username?: string };
    message?: TgMessage;
    data?: string;
  };
}

// ─── Основные методы API ─────────────────────────────────────────────────────

async function tgCall(method: string, body: Record<string, unknown>): Promise<any> {
  if (!BOT_TOKEN()) {
    console.warn('[Telegram] TELEGRAM_BOT_TOKEN не задан');
    return null;
  }
  const res = await fetch(`${TG_BASE()}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Telegram API ${method} error ${res.status}: ${err}`);
  }
  return res.json();
}

/**
 * Отправить текстовое сообщение пользователю.
 * @param chatId  — Telegram chat_id пользователя
 * @param text    — текст (поддерживает MarkdownV2)
 * @param opts    — дополнительные параметры
 */
export async function sendMessage(
  chatId: number | string,
  text: string,
  opts?: {
    parseMode?: 'MarkdownV2' | 'HTML';
    replyMarkup?: Record<string, unknown>;
    disablePreview?: boolean;
  }
): Promise<TgMessage | null> {
  const result = await tgCall('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: opts?.parseMode,
    reply_markup: opts?.replyMarkup,
    disable_web_page_preview: opts?.disablePreview ?? true,
  });
  return result?.result ?? null;
}

/**
 * Ответить на callback_query (убирает «часики» у кнопки).
 */
export async function answerCallbackQuery(
  callbackQueryId: string,
  text?: string
): Promise<void> {
  await tgCall('answerCallbackQuery', { callback_query_id: callbackQueryId, text });
}

/**
 * Установить вебхук (вызывается один раз при деплое).
 * URL: https://your-domain.ru/api/telegram/webhook
 */
export async function setWebhook(webhookUrl: string): Promise<boolean> {
  const result = await tgCall('setWebhook', {
    url: webhookUrl,
    allowed_updates: ['message', 'callback_query'],
    drop_pending_updates: true,
  });
  return result?.result === true;
}

/**
 * Получить информацию о боте (проверка токена).
 */
export async function getMe(): Promise<{ id: number; username: string } | null> {
  const result = await tgCall('getMe', {});
  return result?.result ?? null;
}

// ─── Уведомления о вакансиях ─────────────────────────────────────────────────

export interface VacancyNotification {
  title: string;
  company: string;
  city: string;
  salaryStr: string;
  matchPercent?: number;
  url: string;
}

/**
 * Отправить пользователю утренний дайджест вакансий.
 */
export async function sendVacancyDigest(
  chatId: number | string,
  vacancies: VacancyNotification[],
  userName?: string
): Promise<void> {
  if (!vacancies.length) return;

  const greeting = userName ? `Привет, ${userName}!` : 'Привет!';
  const header   = `🔔 *${greeting}*\nНовые вакансии подобранные специально для вас:\n`;

  const items = vacancies.slice(0, 5).map((v, i) => {
    const match = v.matchPercent ? ` _(совпадение ${v.matchPercent}%)_` : '';
    return [
      `*${i + 1}\\. ${escMd(v.title)}*${match}`,
      `🏢 ${escMd(v.company)} • 📍 ${escMd(v.city)}`,
      `💰 ${escMd(v.salaryStr)}`,
      `[Открыть вакансию](${v.url})`,
    ].join('\n');
  });

  const footer = vacancies.length > 5
    ? `\n_...и ещё ${vacancies.length - 5} вакансий в вашем кабинете_`
    : '';

  const text = header + items.join('\n\n') + footer;

  await sendMessage(chatId, text, {
    parseMode: 'MarkdownV2',
    replyMarkup: {
      inline_keyboard: [[
        { text: '📋 Все вакансии', url: 'https://resumevoice.ru/dashboard/vacancies' },
        { text: '⚙️ Настройки', url: 'https://resumevoice.ru/dashboard/settings' },
      ]],
    },
  });
}

/**
 * Отправить уведомление об успешном создании резюме.
 */
export async function sendResumeCreated(
  chatId: number | string,
  resumeTitle: string,
  resumeId: string
): Promise<void> {
  const text =
    `✅ *Резюме готово\\!*\n\n` +
    `📄 *${escMd(resumeTitle)}*\n\n` +
    `Резюме создано и сохранено\\. Вы можете отредактировать, скачать PDF или отправить работодателю\\.`;

  await sendMessage(chatId, text, {
    parseMode: 'MarkdownV2',
    replyMarkup: {
      inline_keyboard: [[
        { text: '✏️ Редактировать', url: `https://resumevoice.ru/editor?id=${resumeId}` },
        { text: '📥 Скачать PDF', url: `https://resumevoice.ru/api/resume/pdf?id=${resumeId}` },
      ]],
    },
  });
}

/**
 * Отправить приветственное сообщение новому пользователю.
 */
export async function sendWelcome(
  chatId: number | string,
  userName?: string
): Promise<void> {
  const name = userName ? `, ${escMd(userName)}` : '';
  const text =
    `👋 *Привет${name}\\!*\n\n` +
    `Добро пожаловать в *ResumeVoice* — первый российский сервис создания резюме голосом\\.\n\n` +
    `Что умеет этот бот:\n` +
    `🔔 Присылать подходящие вакансии каждое утро\n` +
    `✅ Уведомлять когда резюме готово\n` +
    `📊 Рассказывать о новых функциях\n\n` +
    `Перейдите на сайт чтобы создать первое резюме голосом\\:`;

  await sendMessage(chatId, text, {
    parseMode: 'MarkdownV2',
    replyMarkup: {
      inline_keyboard: [[
        { text: '🎤 Создать резюме', url: 'https://resumevoice.ru/voice' },
        { text: '📋 Мой кабинет', url: 'https://resumevoice.ru/dashboard' },
      ]],
    },
  });
}

// ─── Утилиты ─────────────────────────────────────────────────────────────────

/** Экранирование спецсимволов для MarkdownV2 */
export function escMd(text: string): string {
  return text.replace(/[_*[\]()~`>#+=|{}.!\\-]/g, '\\$&');
}
