export type Plan = 'free' | 'pro' | 'premium';
export type Lang = 'ru' | 'en';

export interface User {
  id: string;
  email?: string;
  phone?: string;
  name?: string;
  plan: Plan;
  planExpiresAt?: string;
  telegramChatId?: string;
  createdAt: string;
}

export interface ResumeData {
  contacts: {
    name: string; role: string; phone: string;
    email: string; city: string; github?: string;
  };
  summary: string;
  skills: { tech: string[]; tools: string[]; languages: string[] };
  experience: {
    period: string; company: string; position: string; achievements: string[];
  }[];
  education: { period: string; institution: string; degree: string }[];
}

export interface Resume {
  id: string; userId: string; title: string;
  data: ResumeData; score: number;
  createdAt: string; updatedAt: string;
}

/** Вакансия (унифицированный формат, Труд Всем) */
export interface Vacancy {
  id: string;
  title: string;
  name: string; // алиас title для совместимости с prompts
  company: string;
  employer: { name: string; logoUrl?: string };
  city: string;
  salary?: { from?: number; to?: number; currency: string };
  salaryStr?: string;
  experience?: string;
  employment?: string;
  description?: string;
  requirement?: string;
  responsibility?: string;
  url: string;
  publishedAt: string;
  matchPercent?: number;
}

export interface VacancyFilters {
  text?: string;
  regionCode?: string;  // код субъекта РФ (77=Москва, 78=СПб)
  salary?: number;
  experienceFrom?: number;
  experienceTo?: number;
  employment?: string;
  industry?: string;
  page?: number;
  perPage?: number;
}

export interface PaymentResult {
  paymentUrl: string;
  paymentId: string;
}

export interface ApiOk<T = unknown> { ok: true; data: T }
export interface ApiErr { ok: false; error: string }
export type ApiResp<T = unknown> = ApiOk<T> | ApiErr;
