'use client';
import { useEffect, useRef } from 'react';

export default function ScrollProgress() {
  const barRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => {
      const el = document.documentElement;
      const pct = el.scrollTop / (el.scrollHeight - el.clientHeight) * 100;
      if (barRef.current) barRef.current.style.width = pct + '%';
      if (btnRef.current) {
        btnRef.current.style.opacity = el.scrollTop > 400 ? '1' : '0';
        btnRef.current.style.visibility = el.scrollTop > 400 ? 'visible' : 'hidden';
        btnRef.current.style.transform = el.scrollTop > 400 ? 'none' : 'translateY(8px)';
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <div
        ref={barRef}
        style={{
          position: 'fixed', top: 0, left: 0, zIndex: 9999,
          height: 3, width: 0,
          background: 'linear-gradient(90deg,#7c3aed,#a78bfa)',
          transition: 'width .08s linear',
          pointerEvents: 'none',
        }}
      />
      <button
        ref={btnRef}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="Наверх"
        style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 400,
          width: 44, height: 44, borderRadius: '50%',
          background: '#7c3aed', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 20px rgba(124,58,237,.4)',
          opacity: 0, visibility: 'hidden',
          transform: 'translateY(8px)',
          transition: 'opacity .25s, visibility .25s, transform .25s',
        }}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
    </>
  );
}
