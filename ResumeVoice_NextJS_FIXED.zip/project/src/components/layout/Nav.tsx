'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';

const NAV_LINKS = [
  { key: 'nav.create',   href: '/voice',    label: 'Создать резюме' },
  { key: 'nav.improve',  href: '/upgrade',  label: 'Улучшить' },
  { key: 'nav.vac',      href: '/vacancies',label: 'Вакансии' },
  { key: 'nav.match',    href: '/matching', label: 'Подбор работы' },
  { key: 'nav.prices',   href: '/#pricing', label: 'Цены' },
  { key: 'nav.blog',     href: '/blog',     label: 'Блог' },
  { key: 'nav.contact',  href: '/contact',  label: 'Контакты' },
];

export default function Nav({ active = '' }: { active?: string }) {
  const { theme, lang, toggleTheme, toggleLang, t } = useTheme();
  const { user, signOut } = useAuth();
  const [mob, setMob] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    setMounted(true);
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isDark = mounted && theme === 'dark';

  const navBg = isDark
    ? scrolled ? 'rgba(36,34,44,.98)' : 'rgba(36,34,44,.92)'
    : scrolled ? 'rgba(255,255,255,.98)' : 'rgba(255,255,255,.92)';
  const borderColor = isDark ? '#44424f' : '#ebebeb';
  const textColor   = isDark ? '#e8e6f5' : '#111';
  const linkColor   = isDark ? '#a09ec0' : '#444';
  const activeBg    = isDark ? '#2a2548' : '#f5f3ff';
  const btnBg       = isDark ? '#1e1c30' : '#fff';
  const btnBorder   = isDark ? '#35324a' : '#e4e4e4';
  const btnColor    = isDark ? '#a09ec0' : '#555';

  const navShadow = scrolled
    ? isDark ? '0 2px 20px rgba(0,0,0,.4)' : '0 2px 20px rgba(0,0,0,.08)'
    : 'none';

  return (
    <>
      <nav style={{
        position: 'sticky', top: 0, zIndex: 300,
        height: 60, display: 'flex', alignItems: 'center',
        background: navBg,
        backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)',
        borderBottom: `1px solid ${borderColor}`,
        padding: '0 28px',
        boxShadow: navShadow,
        transition: 'background .3s, box-shadow .3s',
        gap: 0,
      }}>
        {/* LOGO */}
        <Link href="/" style={{
          display: 'flex', alignItems: 'center', gap: 9,
          textDecoration: 'none', flexShrink: 0, marginRight: 24,
        }}>
          <img
            src="/logo.png"
            alt="ResumeVoice"
            style={{ height: 34, width: 'auto', objectFit: 'contain', display: 'block', flexShrink: 0 }}
          />
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
            <span style={{ fontSize: 15, fontWeight: 800, color: textColor, letterSpacing: '-0.3px', whiteSpace: 'nowrap' }}>
              Resume<span style={{ color: '#7c3aed' }}>Voice</span>
            </span>
            <span style={{ fontSize: 9, color: isDark ? '#6a6888' : '#bbb', whiteSpace: 'nowrap', lineHeight: 1.2 }}>
              Резюме голосом и поиск работы
            </span>
          </div>
        </Link>

        {/* DESKTOP LINKS — занимают всё свободное место */}
        <ul style={{
          display: 'flex', gap: 0, listStyle: 'none',
          flex: 1, margin: 0, padding: 0,
          justifyContent: 'center',
          alignItems: 'center',
          overflow: 'hidden',
        }}>
          {NAV_LINKS.map(l => {
            const isActive = active === l.href;
            return (
              <li key={l.href} style={{ flexShrink: 0 }}>
                <Link
                  href={l.href}
                  style={{
                    display: 'block', padding: '7px 11px', borderRadius: 8,
                    fontSize: 13, fontWeight: isActive ? 600 : 450,
                    textDecoration: 'none', whiteSpace: 'nowrap',
                    transition: 'all .15s',
                    color: isActive ? '#7c3aed' : linkColor,
                    background: isActive ? activeBg : 'transparent',
                    letterSpacing: '-0.1px',
                  }}
                >
                  {t(l.key) || l.label}
                </Link>
              </li>
            );
          })}
          {mounted && user && (
            <li style={{ flexShrink: 0 }}>
              <Link href="/dashboard" style={{
                display: 'block', padding: '7px 11px', borderRadius: 8,
                fontSize: 13, fontWeight: active === '/dashboard' ? 600 : 450,
                textDecoration: 'none', whiteSpace: 'nowrap',
                color: active === '/dashboard' ? '#7c3aed' : linkColor,
                background: active === '/dashboard' ? activeBg : 'transparent',
              }}>
                Кабинет
              </Link>
            </li>
          )}
        </ul>

        {/* RIGHT CONTROLS */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0, marginLeft: 8 }}>
          {/* Lang */}
          <button
            onClick={toggleLang}
            title="Язык / Language"
            style={{
              height: 32, padding: '0 8px', borderRadius: 8,
              border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor,
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
              fontSize: 11, fontWeight: 600, fontFamily: 'inherit', transition: 'all .15s',
              flexShrink: 0,
            }}
          >
            {mounted ? (
              lang === 'ru' ? (
                <svg width="18" height="13" viewBox="0 0 18 13" style={{ borderRadius: 2, flexShrink: 0 }}>
                  <rect width="18" height="4.33" fill="#fff"/>
                  <rect y="4.33" width="18" height="4.33" fill="#0039A6"/>
                  <rect y="8.67" width="18" height="4.33" fill="#D52B1E"/>
                </svg>
              ) : (
                <svg width="18" height="13" viewBox="0 0 60 40" style={{ borderRadius: 2, flexShrink: 0 }}>
                  <rect width="60" height="40" fill="#012169"/>
                  <path d="M0,0 L60,40 M60,0 L0,40" stroke="white" strokeWidth="6"/>
                  <path d="M0,0 L60,40 M60,0 L0,40" stroke="#C8102E" strokeWidth="4"/>
                  <path d="M30,0 V40 M0,20 H60" stroke="white" strokeWidth="10"/>
                  <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" strokeWidth="6"/>
                </svg>
              )
            ) : (
              <span style={{ width: 18, height: 13, background: btnBorder, borderRadius: 2, display: 'inline-block' }} />
            )}
            <span>{mounted ? lang.toUpperCase() : 'RU'}</span>
          </button>

          {/* Theme */}
          <button
            onClick={toggleTheme}
            title="Сменить тему"
            style={{
              width: 32, height: 32, borderRadius: 8,
              border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor,
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, transition: 'all .15s',
            }}
          >
            {mounted && isDark ? (
              <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="5"/>
                <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              </svg>
            )}
          </button>

          {/* Divider */}
          <div style={{ width: 1, height: 22, background: btnBorder, margin: '0 2px' }} />

          {/* Auth */}
          {mounted && user ? (
            <>
              <Link href="/dashboard" style={{
                height: 32, padding: '0 13px', borderRadius: 8,
                border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor,
                display: 'flex', alignItems: 'center', fontSize: 13, textDecoration: 'none',
                fontWeight: 500, flexShrink: 0, transition: 'all .15s', whiteSpace: 'nowrap',
              }}>
                {user.name?.split(' ')[0] || 'Кабинет'}
              </Link>
              <button onClick={signOut} style={{
                height: 32, padding: '0 13px', borderRadius: 8,
                border: '1.5px solid #fecaca', background: '#fef2f2',
                color: '#dc2626', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit',
                display: 'flex', alignItems: 'center', flexShrink: 0, whiteSpace: 'nowrap',
                transition: 'all .15s',
              }}>
                Выйти
              </button>
            </>
          ) : (
            <>
              <Link href="/login" style={{
                height: 32, padding: '0 14px', borderRadius: 8,
                border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor,
                display: 'flex', alignItems: 'center', fontSize: 13, textDecoration: 'none',
                fontWeight: 500, flexShrink: 0, whiteSpace: 'nowrap', transition: 'all .15s',
              }}>
                Войти
              </Link>
              <Link href="/register" style={{
                height: 32, padding: '0 16px', borderRadius: 8,
                background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
                color: '#fff',
                display: 'flex', alignItems: 'center', fontSize: 13, textDecoration: 'none',
                fontWeight: 600, flexShrink: 0, whiteSpace: 'nowrap',
                boxShadow: '0 2px 10px rgba(124,58,237,.35)',
                transition: 'all .2s',
              }}>
                Начать бесплатно
              </Link>
            </>
          )}

          {/* Mobile burger */}
          <button
            onClick={() => setMob(!mob)}
            style={{
              display: 'none', width: 32, height: 32, borderRadius: 8,
              border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor,
              cursor: 'pointer', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, fontSize: 16,
            }}
            className="mob-burger"
          >
            {mob ? '✕' : '☰'}
          </button>
        </div>
      </nav>

      {/* MOBILE MENU */}
      {mob && (
        <div style={{
          background: navBg, borderBottom: `1.5px solid ${borderColor}`,
          padding: '12px 20px', display: 'flex', flexDirection: 'column', gap: 2,
          position: 'sticky', top: 60, zIndex: 299,
          backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)',
        }}>
          {NAV_LINKS.map(l => (
            <Link key={l.href} href={l.href} onClick={() => setMob(false)} style={{
              display: 'block', padding: '10px 12px', borderRadius: 8, fontSize: 14,
              color: linkColor, textDecoration: 'none', transition: 'background .15s',
            }}>
              {t(l.key) || l.label}
            </Link>
          ))}
          {user && (
            <Link href="/dashboard" onClick={() => setMob(false)} style={{
              display: 'block', padding: '10px 12px', borderRadius: 8, fontSize: 14,
              color: '#7c3aed', textDecoration: 'none', fontWeight: 600,
            }}>
              Личный кабинет
            </Link>
          )}
          <div style={{ display: 'flex', gap: 8, padding: '8px 0', marginTop: 4 }}>
            {!user ? (
              <>
                <Link href="/login" onClick={() => setMob(false)} style={{ flex: 1, padding: '10px', borderRadius: 8, border: `1.5px solid ${btnBorder}`, background: btnBg, color: btnColor, textDecoration: 'none', textAlign: 'center', fontSize: 13, fontWeight: 500 }}>Войти</Link>
                <Link href="/register" onClick={() => setMob(false)} style={{ flex: 1, padding: '10px', borderRadius: 8, background: '#7c3aed', color: '#fff', textDecoration: 'none', textAlign: 'center', fontSize: 13, fontWeight: 600 }}>Начать бесплатно</Link>
              </>
            ) : (
              <button onClick={() => { signOut(); setMob(false); }} style={{ flex: 1, padding: '10px', borderRadius: 8, border: '1.5px solid #fecaca', background: '#fef2f2', color: '#dc2626', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}>Выйти</button>
            )}
          </div>
        </div>
      )}

      <style>{`
        @media(max-width:960px){
          nav ul { display: none !important; }
          .mob-burger { display: flex !important; }
        }
        @media(max-width:640px){
          nav { padding: 0 16px !important; }
        }
        nav a:hover, nav button:hover { opacity: .82; }
      `}</style>
    </>
  );
}
