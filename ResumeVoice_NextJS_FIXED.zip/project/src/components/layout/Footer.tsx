import Link from 'next/link';

const cols = [
  { title:'Сервис', links:[['Создать резюме голосом','/voice'],['Улучшить резюме','/upgrade'],['Вакансии','/vacancies'],['Подбор работы','/matching'],['Тренировка собеседования','/interview'],['Карьерные советы','/assistant']] },
  { title:'Компания', links:[['О нас','/about'],['Блог','/blog'],['Обратная связь','/contact'],['Тарифы','/#pricing'],['Личный кабинет','/dashboard'],['Частые вопросы','/about#faq']] },
  { title:'Правовая информация', links:[['Конфиденциальность','/privacy',true],['Условия использования','/terms',true],['Договор оферты','/oferta',true],['Отказ от ответственности','/disclaimer',true]] },
];

export default function Footer() {
  return (
    <footer style={{ background:'var(--bg2)',borderTop:'1.5px solid var(--border)',padding:'56px 48px 0' }}>
      <div style={{ maxWidth:1060,margin:'0 auto' }}>
        <div style={{ display:'grid',gridTemplateColumns:'240px repeat(3,1fr)',gap:32,paddingBottom:40,borderBottom:'1px solid var(--border)',alignItems:'start' }}>
          <div>
            <Link href="/" style={{ display:'flex',alignItems:'center',gap:10,textDecoration:'none',marginBottom:12 }}>
              <img src="/logo.png" alt="ResumeVoice" style={{ width:'auto',height:32,objectFit:'contain',objectPosition:'left center' }} />
              <span style={{ fontSize:16,fontWeight:800,color:'var(--text)' }}>Resume<span style={{ color:'#7c3aed' }}>Voice</span></span>
            </Link>
            <p style={{ fontSize:13,color:'var(--text3)',lineHeight:1.6,maxWidth:200 }}>ResumeVoice - Сервис голосового создания резюме No1 в России</p>
          </div>
          {cols.map(col => (
            <div key={col.title}>
              <h4 style={{ fontSize:13,fontWeight:700,color:'var(--text)',marginBottom:14,textAlign:'left' }}>{col.title}</h4>
              <ul style={{ listStyle:'none' }}>
                {col.links.map(([label,href,blank]) => (
                  <li key={href as string} style={{ marginBottom:8 }}>
                    <Link href={href as string} target={blank?'_blank':undefined} rel={blank?'noopener noreferrer':undefined}
                      style={{ fontSize:13,color:'var(--text3)',textDecoration:'none' }}>
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',padding:'18px 0',flexWrap:'wrap',gap:12 }}>
          <p style={{ fontSize:12,color:'var(--text4)' }}>© 2026 ResumeVoice - Первый сервис голосового создания резюме в России</p>
          <div style={{ display:'flex',gap:16 }}>
            {[['Конфиденциальность','/privacy'],['Условия','/terms'],['Оферта','/oferta']].map(([l,h]) => (
              <Link key={h} href={h} target="_blank" rel="noopener noreferrer" style={{ fontSize:12,color:'var(--text4)',textDecoration:'none' }}>{l}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
