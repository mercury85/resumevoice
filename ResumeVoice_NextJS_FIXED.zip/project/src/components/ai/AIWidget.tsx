'use client';
import { useState, useRef, useEffect } from 'react';

interface Msg { role: 'bot' | 'user'; text: string; }

const KB = [
  { k:['создать резюме','голосом','записать','микрофон'], a:'Нажмите на большой фиолетовый микрофон на главной или перейдите в "Создать резюме". Расскажите о себе 1-2 минуты в свободной форме — резюме готово за 30 секунд.' },
  { k:['тариф','цена','стоит','оплат','подписк'], a:'3 тарифа:\n\nБесплатно (0 руб) — 1 резюме, 1 письмо, без вакансий\n\nПро (699 руб/мес) — безлимит резюме, до 100 вакансий/день, PDF и Word\n\nПремиум (1490 руб/мес) — полный безлимит, 10 направлений, анализ зарплат' },
  { k:['вакансии','работа','hh'], a:'Вакансии подбираются на основе вашего резюме. Перейдите в раздел "Вакансии" или "Подбор работы". Настройте профессии, города и минимальную зарплату.' },
  { k:['уведомлени','telegram','телеграм'], a:'В разделе "Подбор работы" нажмите "Подключить Telegram" — каждое утро будете получать список новых подходящих вакансий прямо в мессенджер.' },
  { k:['войти','вход','логин','аккаунт'], a:'Нажмите "Войти" в правом верхнем углу. Варианты: по телефону с СМС-кодом, через WhatsApp, Telegram или по email и паролю.' },
  { k:['pdf','word','docx','скачать','экспорт'], a:'PDF доступен на всех тарифах. Word (DOCX) — с тарифа Про. Нажмите кнопку "Скачать" в редакторе резюме.' },
  { k:['отправить','мессенджер','whatsapp','поделиться'], a:'В редакторе резюме есть кнопки отправки в Telegram, WhatsApp и ВКонтакте. Скачайте PDF и отправьте работодателю.' },
  { k:['улучшить','загрузить','анализ'], a:'Раздел "Улучшить резюме" — загрузите PDF/DOCX/TXT, сервис проанализирует по 15 критериям и покажет режим "было — стало".' },
  { k:['собеседовани'], a:'Раздел "Тренировка собеседования" — сервис задаёт HR-вопросы, вы отвечаете голосом, затем получаете разбор ответов и конкретные советы.' },
  { k:['возврат','деньги'], a:'Возврат возможен в течение 14 дней с момента оплаты, если вы не использовали платные функции. Напишите через страницу "Обратная связь".' },
];

const QUICK = ['Как создать резюме?', 'Тарифы и цены', 'Как найти вакансии?', 'PDF и Word'];

export default function AIWidget() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([{ role: 'bot', text: 'Привет! Помогу с любыми вопросами о ResumeVoice. Спрашивайте о резюме, тарифах, вакансиях или работе сервиса.' }]);
  const [inp, setInp] = useState('');
  const msgsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [msgs]);

  const findAns = (q: string) => {
    const ql = q.toLowerCase();
    for (const kb of KB) if (kb.k.some(k => ql.includes(k))) return kb.a;
    return 'По этому вопросу лучше написать напрямую — страница "Обратная связь" или Telegram @resumevoice_support. Ответим в течение часа.';
  };

  const send = (text?: string) => {
    const q = (text ?? inp).trim();
    if (!q) return;
    setMsgs(m => [...m, { role: 'user', text: q }]);
    setInp('');
    setTimeout(() => setMsgs(m => [...m, { role: 'bot', text: findAns(q) }]), 500);
  };

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        aria-label="Помощник ResumeVoice"
        style={{ position: 'fixed', bottom: 76, right: 24, zIndex: 400, width: 44, height: 44, borderRadius: '50%', background: 'var(--bg, white)', border: '2px solid #e9e3ff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 16px rgba(0,0,0,.1)', transition: 'all .2s' }}>
        {open
          ? <svg width="18" height="18" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          : <svg width="22" height="22" viewBox="0 0 24 24" stroke="#7c3aed" fill="none" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        }
      </button>

      {open && (
        <div style={{ position: 'fixed', bottom: 132, right: 24, zIndex: 400, width: 320, background: 'var(--bg, white)', border: '1.5px solid #e9e3ff', borderRadius: 20, boxShadow: '0 16px 48px rgba(124,58,237,.15)', display: 'flex', flexDirection: 'column', maxHeight: 460, overflow: 'hidden', fontFamily: 'inherit' }}>
          <div style={{ background: '#f5f3ff', padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #e9e3ff' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#7c3aed,#a78bfa)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text,#111)' }}>Помощник ResumeVoice</div>
              <div style={{ fontSize: 11, color: '#7c3aed' }}>Онлайн — готов помочь</div>
            </div>
            <button onClick={() => setOpen(false)} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', fontSize: 18, lineHeight: 1 }}>×</button>
          </div>

          <div ref={msgsRef} style={{ flex: 1, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {msgs.map((m, i) => (
              <div key={i} style={{ padding: '10px 13px', borderRadius: 14, fontSize: 13, lineHeight: 1.55, maxWidth: '85%', whiteSpace: 'pre-line', alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start', background: m.role === 'user' ? '#7c3aed' : '#f5f3ff', color: m.role === 'user' ? 'white' : '#333', borderBottomRightRadius: m.role === 'user' ? 4 : 14, borderBottomLeftRadius: m.role === 'bot' ? 4 : 14 }}>
                {m.text}
              </div>
            ))}
          </div>

          <div style={{ padding: '0 12px 8px', display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {QUICK.map(q => (
              <button key={q} onClick={() => send(q)} style={{ padding: '4px 9px', borderRadius: 100, fontSize: 11, border: '1px solid #e9e3ff', background: 'white', color: '#7c3aed', cursor: 'pointer', fontFamily: 'inherit' }}>
                {q}
              </button>
            ))}
          </div>

          <div style={{ padding: '10px 12px', borderTop: '1px solid #f0f0f0', display: 'flex', gap: 8 }}>
            <input value={inp} onChange={e => setInp(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()}
              placeholder="Ваш вопрос..."
              style={{ flex: 1, padding: '8px 12px', border: '1.5px solid #e0e0e0', borderRadius: 10, fontSize: 13, outline: 'none', fontFamily: 'inherit', background: 'var(--bg,white)', color: 'var(--text,#111)' }} />
            <button onClick={() => send()} style={{ width: 34, height: 34, borderRadius: 8, background: '#7c3aed', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" stroke="white" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
